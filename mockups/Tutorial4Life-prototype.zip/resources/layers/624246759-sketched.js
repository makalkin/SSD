rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__624246759-layer" class="layer" name="__containerId__pageLayer" data-layer-id="624246759" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-624246759-layer-955217002" style="position: absolute; left: 735px; top: 15px; width: 72px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="955217002" data-review-reference-id="955217002">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Username<br /><br /></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-969214364" style="position: absolute; left: 815px; top: 10px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="969214364" data-review-reference-id="969214364">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:68px;" width="68" height="30">\
               <svg:g width="68" height="30"><svg:path d="M 2.00, 2.00 Q 12.17, 2.30, 22.33, 1.00 Q 32.50, 0.50, 42.67, 0.43 Q 52.83, 0.44, 63.64, 1.36 Q 64.08, 13.14,\
                  63.55, 25.55 Q 53.13, 26.10, 42.82, 26.37 Q 32.58, 26.56, 22.37, 26.36 Q 12.18, 26.43, 1.22, 25.77 Q 2.00, 13.50, 2.00, 2.00"\
                  style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 64.00, 4.00 Q 64.00, 16.00, 64.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 65.00, 5.00 Q 65.00, 17.00, 65.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 66.00, 6.00 Q 66.00, 18.00, 66.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.33, 25.60, 24.67, 25.51 Q 35.00, 25.47, 45.33, 25.43 Q 55.67, 26.00, 66.00, 26.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.33, 29.08, 25.67, 28.40 Q 36.00, 27.95, 46.33, 27.75 Q 56.67, 27.00, 67.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.33, 27.19, 26.67, 27.43 Q 37.00, 27.15, 47.33, 27.31 Q 57.67, 28.00, 68.00, 28.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-624246759-layer-969214364button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-624246759-layer-969214364button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-624246759-layer-969214364button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:64px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Logout<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-624246759-layer-1505384943" style="position: absolute; left: 815px; top: 50px; width: 131px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1505384943" data-review-reference-id="1505384943">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:131px;" width="131" height="30">\
               <svg:g width="131" height="30"><svg:path d="M 2.00, 2.00 Q 12.33, 1.52, 22.67, 1.71 Q 33.00, 1.54, 43.33, 1.50 Q 53.67, 1.30, 64.00, 1.07 Q 74.33, 1.82,\
                  84.67, 0.91 Q 95.00, 1.36, 105.33, 1.34 Q 115.67, 1.08, 126.32, 1.68 Q 125.94, 13.52, 126.03, 25.03 Q 115.75, 25.32, 105.48,\
                  26.31 Q 95.05, 26.00, 84.68, 25.69 Q 74.34, 25.43, 64.00, 25.54 Q 53.67, 25.87, 43.33, 25.61 Q 33.00, 24.95, 22.67, 25.76\
                  Q 12.33, 24.71, 2.11, 24.89 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 127.00, 4.00 Q 127.00, 16.00, 127.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 128.00, 5.00 Q 128.00, 17.00, 128.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 129.00, 6.00 Q 129.00, 18.00, 129.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.42, 24.21, 24.83, 24.04 Q 35.25, 23.96, 45.67, 23.80 Q 56.08, 24.21, 66.50, 24.14 Q 76.92,\
                  23.98, 87.33, 23.94 Q 97.75, 24.26, 108.17, 24.41 Q 118.58, 26.00, 129.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.42, 26.25, 25.83, 26.68 Q 36.25, 27.32, 46.67, 26.89 Q 57.08, 26.82, 67.50, 27.80 Q 77.92,\
                  27.73, 88.33, 27.39 Q 98.75, 26.38, 109.17, 27.21 Q 119.58, 27.00, 130.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.42, 25.86, 26.83, 26.34 Q 37.25, 26.41, 47.67, 27.01 Q 58.08, 27.01, 68.50, 26.96 Q 78.92,\
                  27.03, 89.33, 28.00 Q 99.75, 28.87, 110.17, 28.21 Q 120.58, 28.00, 131.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-624246759-layer-1505384943button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-624246759-layer-1505384943button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-624246759-layer-1505384943button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:127px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Back to main page<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-624246759-layer-550729332" style="position: absolute; left: 20px; top: 25px; width: 143px; height: 24px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="550729332" data-review-reference-id="550729332">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p><span style="font-size: 20px;">Tutorials name<br /></span></p>\
                  <p style="font-size: 14px;"><span style="font-size: 20px;"> </span></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-1621123758" style="position: absolute; left: 235px; top: 90px; width: 450px; height: 250px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1621123758" data-review-reference-id="1621123758">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 250px;width:450px;" width="450" height="250">\
               <svg:g width="450" height="250"><svg:path id="__containerId__-624246759-layer-1621123758_input_svg_border" d="M 2.00, 2.00 Q 12.14, 1.34, 22.27, 1.86 Q 32.41,\
                  1.75, 42.55, 2.62 Q 52.68, 1.56, 62.82, 1.99 Q 72.95, 2.63, 83.09, 3.26 Q 93.23, 2.57, 103.36, 2.62 Q 113.50, 2.79, 123.64,\
                  1.91 Q 133.77, 2.23, 143.91, 2.51 Q 154.05, 2.13, 164.18, 2.57 Q 174.32, 2.38, 184.45, 1.91 Q 194.59, 2.00, 204.73, 3.17 Q\
                  214.86, 2.77, 225.00, 3.22 Q 235.14, 1.42, 245.27, 1.19 Q 255.41, 1.56, 265.55, 1.50 Q 275.68, 0.40, 285.82, 1.35 Q 295.95,\
                  1.42, 306.09, 0.45 Q 316.23, 1.25, 326.36, 1.22 Q 336.50, 1.68, 346.64, 1.14 Q 356.77, 1.32, 366.91, 0.91 Q 377.05, 0.75,\
                  387.18, 1.44 Q 397.32, 1.83, 407.45, 3.84 Q 417.59, 2.24, 427.73, 2.23 Q 437.86, 2.62, 447.48, 2.52 Q 447.98, 12.26, 448.89,\
                  22.37 Q 449.16, 32.67, 449.13, 42.96 Q 448.77, 53.24, 449.79, 63.49 Q 449.25, 73.75, 449.71, 84.00 Q 449.57, 94.25, 449.74,\
                  104.50 Q 449.06, 114.75, 448.49, 125.00 Q 447.52, 135.25, 448.18, 145.50 Q 449.39, 155.75, 449.64, 166.00 Q 448.78, 176.25,\
                  448.73, 186.50 Q 448.92, 196.75, 448.49, 207.00 Q 448.16, 217.25, 448.15, 227.50 Q 448.97, 237.75, 448.86, 248.86 Q 438.21,\
                  249.04, 427.86, 248.95 Q 417.65, 248.89, 407.48, 248.91 Q 397.33, 248.86, 387.19, 249.21 Q 377.05, 248.44, 366.91, 249.05\
                  Q 356.77, 249.36, 346.64, 249.61 Q 336.50, 247.86, 326.36, 246.29 Q 316.23, 247.07, 306.09, 247.71 Q 295.95, 247.25, 285.82,\
                  248.14 Q 275.68, 248.28, 265.55, 248.32 Q 255.41, 248.13, 245.27, 247.49 Q 235.14, 247.46, 225.00, 248.05 Q 214.86, 248.85,\
                  204.73, 248.38 Q 194.59, 248.55, 184.45, 248.62 Q 174.32, 248.81, 164.18, 248.68 Q 154.05, 248.00, 143.91, 248.19 Q 133.77,\
                  248.49, 123.64, 248.80 Q 113.50, 248.67, 103.36, 248.37 Q 93.23, 248.65, 83.09, 249.26 Q 72.95, 249.42, 62.82, 249.05 Q 52.68,\
                  248.75, 42.55, 248.47 Q 32.41, 248.96, 22.27, 249.07 Q 12.14, 249.60, 0.96, 249.04 Q 0.77, 238.16, 0.96, 227.65 Q 0.73, 217.33,\
                  0.61, 207.04 Q 0.46, 196.77, 0.17, 186.51 Q 0.03, 176.26, -0.08, 166.00 Q -0.12, 155.75, -0.20, 145.50 Q -0.39, 135.25, -0.18,\
                  125.00 Q 0.13, 114.75, 0.37, 104.50 Q 0.67, 94.25, 1.12, 84.00 Q 1.23, 73.75, 1.43, 63.50 Q 1.41, 53.25, 1.32, 43.00 Q 1.11,\
                  32.75, 1.09, 22.50 Q 2.00, 12.25, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-624246759-layer-1621123758select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-624246759-layer-1621123758_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-624246759-layer-1621123758_input_svg_border\')" style="width:442px; height:242px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-624246759-layer-523750937" style="position: absolute; left: 250px; top: 105px; width: 96px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="523750937" data-review-reference-id="523750937">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>text of tutorial</p>\
                  <p class="none" style="font-size: 14px;"> </p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-372182856" style="position: absolute; left: 15px; top: 100px; width: 150px; height: 325px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="372182856" data-review-reference-id="372182856">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 325px;width:150px;" width="150" height="325">\
               <svg:g width="150" height="325"><svg:path id="__containerId__-624246759-layer-372182856_input_svg_border" d="M 2.00, 2.00 Q 12.43, -0.30, 22.86, 0.06 Q 33.29,\
                  0.20, 43.71, 0.45 Q 54.14, 0.97, 64.57, 0.41 Q 75.00, 1.57, 85.43, 1.04 Q 95.86, 0.63, 106.29, 0.70 Q 116.71, -0.06, 127.14,\
                  0.03 Q 137.57, 1.67, 147.94, 2.06 Q 148.16, 11.98, 148.67, 21.97 Q 149.92, 31.97, 150.02, 42.06 Q 149.89, 52.13, 150.04, 62.17\
                  Q 150.31, 72.21, 150.40, 82.25 Q 150.19, 92.28, 150.54, 102.31 Q 149.66, 112.34, 149.02, 122.37 Q 148.75, 132.41, 148.88,\
                  142.44 Q 148.94, 152.47, 148.39, 162.50 Q 147.79, 172.53, 148.05, 182.56 Q 148.90, 192.59, 149.40, 202.62 Q 148.87, 212.66,\
                  149.08, 222.69 Q 149.38, 232.72, 149.08, 242.75 Q 149.39, 252.78, 149.40, 262.81 Q 149.45, 272.84, 149.67, 282.88 Q 149.73,\
                  292.91, 149.88, 302.94 Q 149.48, 312.97, 148.74, 323.74 Q 137.97, 324.19, 127.36, 324.54 Q 116.80, 324.35, 106.32, 324.10\
                  Q 95.87, 324.04, 85.44, 324.01 Q 75.00, 324.10, 64.57, 324.27 Q 54.14, 324.69, 43.71, 324.18 Q 33.29, 323.97, 22.86, 323.58\
                  Q 12.43, 323.44, 1.74, 323.26 Q 2.43, 312.83, 2.05, 302.93 Q 1.71, 292.93, 1.46, 282.89 Q 1.47, 272.85, 1.66, 262.82 Q 1.09,\
                  252.78, 1.58, 242.75 Q 2.06, 232.72, 2.47, 222.69 Q 0.84, 212.66, 1.93, 202.63 Q 0.58, 192.59, 1.37, 182.56 Q 1.23, 172.53,\
                  1.08, 162.50 Q 0.69, 152.47, 0.53, 142.44 Q 1.19, 132.41, 0.36, 122.38 Q 1.26, 112.34, 0.50, 102.31 Q 0.60, 92.28, 0.83, 82.25\
                  Q 0.35, 72.22, 0.44, 62.19 Q 0.10, 52.16, -0.13, 42.12 Q -0.20, 32.09, 0.49, 22.06 Q 2.00, 12.03, 2.00, 2.00" style=" fill:white;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-624246759-layer-372182856select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-624246759-layer-372182856_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-624246759-layer-372182856_input_svg_border\')" style="width:142px; height:317px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-624246759-layer-442707659" style="position: absolute; left: 15px; top: 80px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="442707659" data-review-reference-id="442707659">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-280943732" style="position: absolute; left: 775px; top: 105px; width: 168px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="280943732" data-review-reference-id="280943732">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>tutorials from this category<br />\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-2076897963" style="position: absolute; left: 765px; top: 135px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2076897963" data-review-reference-id="2076897963">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 140px;width:150px;" width="150" height="140">\
               <svg:g width="150" height="140"><svg:path id="__containerId__-624246759-layer-2076897963_input_svg_border" d="M 2.00, 2.00 Q 12.43, -0.08, 22.86, 0.37 Q 33.29,\
                  0.16, 43.71, 1.04 Q 54.14, 0.82, 64.57, -0.08 Q 75.00, -0.06, 85.43, 0.47 Q 95.86, 1.71, 106.29, 1.32 Q 116.71, 0.85, 127.14,\
                  0.72 Q 137.57, 0.65, 148.33, 1.67 Q 148.84, 13.05, 149.10, 24.51 Q 149.31, 35.91, 148.84, 47.31 Q 149.02, 58.65, 149.37, 69.99\
                  Q 149.40, 81.33, 149.45, 92.66 Q 148.56, 104.00, 149.27, 115.33 Q 149.43, 126.67, 148.74, 138.74 Q 137.88, 138.94, 127.22,\
                  138.53 Q 116.80, 139.35, 106.31, 138.74 Q 95.88, 139.22, 85.44, 139.11 Q 75.01, 139.36, 64.57, 139.45 Q 54.14, 139.01, 43.71,\
                  138.88 Q 33.29, 138.32, 22.86, 139.09 Q 12.43, 139.37, 1.46, 138.54 Q 1.05, 126.98, 0.89, 115.49 Q 0.73, 104.08, 0.60, 92.71\
                  Q 1.04, 81.35, 2.25, 70.00 Q 1.72, 58.67, 1.29, 47.33 Q 1.17, 36.00, 0.62, 24.67 Q 2.00, 13.33, 2.00, 2.00" style=" fill:white;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-624246759-layer-2076897963select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-624246759-layer-2076897963_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-624246759-layer-2076897963_input_svg_border\')" style="width:142px; height:132px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-624246759-layer-2088071006" style="position: absolute; left: 775px; top: 295px; width: 109px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2088071006" data-review-reference-id="2088071006">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Authors tutorials</p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-2032381200" style="position: absolute; left: 765px; top: 330px; width: 150px; height: 125px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2032381200" data-review-reference-id="2032381200">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 125px;width:150px;" width="150" height="125">\
               <svg:g width="150" height="125"><svg:path id="__containerId__-624246759-layer-2032381200_input_svg_border" d="M 2.00, 2.00 Q 12.43, 2.62, 22.86, 2.57 Q 33.29,\
                  1.40, 43.71, 1.57 Q 54.14, 1.23, 64.57, 0.55 Q 75.00, 1.56, 85.43, 1.26 Q 95.86, 1.40, 106.29, 0.90 Q 116.71, 0.20, 127.14,\
                  -0.16 Q 137.57, 1.64, 148.75, 1.25 Q 148.82, 11.81, 149.88, 21.90 Q 149.37, 32.16, 149.13, 42.30 Q 149.39, 52.39, 148.14,\
                  62.50 Q 148.29, 72.58, 149.17, 82.66 Q 149.84, 92.75, 150.03, 102.83 Q 148.67, 112.92, 148.03, 123.03 Q 137.87, 123.90, 127.28,\
                  123.98 Q 116.76, 123.66, 106.29, 123.25 Q 95.87, 123.81, 85.44, 124.68 Q 75.01, 124.75, 64.57, 124.80 Q 54.15, 125.29, 43.72,\
                  125.28 Q 33.29, 125.46, 22.86, 125.17 Q 12.43, 124.95, 1.38, 123.62 Q 0.47, 113.43, 0.11, 103.10 Q -0.03, 92.89, 0.36, 82.72\
                  Q 0.27, 72.61, 0.31, 62.51 Q 0.22, 52.42, 0.86, 42.34 Q 1.24, 32.25, 2.00, 22.17 Q 2.00, 12.08, 2.00, 2.00" style=" fill:white;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-624246759-layer-2032381200select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-624246759-layer-2032381200_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-624246759-layer-2032381200_input_svg_border\')" style="width:142px; height:117px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-624246759-layer-text312186894" style="position: absolute; left: 215px; top: 30px; width: 52px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text312186894" data-review-reference-id="text312186894">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>Author\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-text490724374" style="position: absolute; left: 215px; top: 55px; width: 127px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text490724374" data-review-reference-id="text490724374">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Category of tutorial</p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-textinput538450841" style="position: absolute; left: 335px; top: 370px; width: 350px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput538450841" data-review-reference-id="textinput538450841">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:350px;" width="350" height="30">\
               <svg:g id="__containerId__-624246759-layer-textinput538450841svg" width="350" height="30"><svg:path id="__containerId__-624246759-layer-textinput538450841_input_svg_border" d="M 2.00, 2.00 Q 12.18, 1.23, 22.35, 2.05\
                  Q 32.53, 2.03, 42.71, 2.88 Q 52.88, 1.89, 63.06, 1.42 Q 73.24, 2.20, 83.41, 2.79 Q 93.59, 2.60, 103.76, 1.85 Q 113.94, 2.31,\
                  124.12, 1.84 Q 134.29, 1.94, 144.47, 1.65 Q 154.65, 1.23, 164.82, 1.81 Q 175.00, 2.02, 185.18, 1.88 Q 195.35, 1.31, 205.53,\
                  1.43 Q 215.71, 0.87, 225.88, 1.23 Q 236.06, 0.87, 246.24, 1.03 Q 256.41, 0.80, 266.59, 1.17 Q 276.76, 1.38, 286.94, 1.64 Q\
                  297.12, 2.14, 307.29, 1.32 Q 317.47, 1.62, 327.65, 1.06 Q 337.82, 0.76, 348.61, 1.39 Q 348.77, 14.74, 348.26, 28.26 Q 338.03,\
                  28.76, 327.70, 28.49 Q 317.52, 29.03, 307.29, 27.66 Q 297.13, 28.83, 286.95, 29.49 Q 276.77, 29.14, 266.59, 29.05 Q 256.41,\
                  29.18, 246.24, 28.85 Q 236.06, 27.98, 225.88, 28.04 Q 215.71, 27.25, 205.53, 28.38 Q 195.35, 29.47, 185.18, 29.04 Q 175.00,\
                  28.67, 164.82, 29.18 Q 154.65, 29.74, 144.47, 28.90 Q 134.29, 28.36, 124.12, 27.90 Q 113.94, 28.86, 103.76, 29.09 Q 93.59,\
                  28.92, 83.41, 28.38 Q 73.24, 28.36, 63.06, 28.90 Q 52.88, 28.13, 42.71, 29.50 Q 32.53, 29.31, 22.35, 29.79 Q 12.18, 29.92,\
                  1.20, 28.80 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput538450841_line1" d="M 3.00, 3.00 Q 13.12, 2.23, 23.24, 2.36 Q 33.35,\
                  2.65, 43.47, 2.76 Q 53.59, 2.43, 63.71, 3.54 Q 73.82, 2.54, 83.94, 3.26 Q 94.06, 2.77, 104.18, 2.72 Q 114.29, 3.12, 124.41,\
                  3.86 Q 134.53, 3.30, 144.65, 1.90 Q 154.76, 3.15, 164.88, 2.86 Q 175.00, 3.80, 185.12, 3.01 Q 195.24, 2.91, 205.35, 3.19 Q\
                  215.47, 3.59, 225.59, 3.28 Q 235.71, 3.20, 245.82, 2.98 Q 255.94, 3.20, 266.06, 2.72 Q 276.18, 0.84, 286.29, 1.80 Q 296.41,\
                  3.34, 306.53, 3.43 Q 316.65, 2.83, 326.76, 1.74 Q 336.88, 3.00, 347.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput538450841_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput538450841_line3" d="M 3.00, 3.00 Q 13.12, 2.40, 23.24, 2.36 Q 33.35,\
                  2.23, 43.47, 2.41 Q 53.59, 2.29, 63.71, 2.25 Q 73.82, 2.92, 83.94, 2.40 Q 94.06, 2.37, 104.18, 2.30 Q 114.29, 2.05, 124.41,\
                  2.21 Q 134.53, 2.66, 144.65, 3.54 Q 154.76, 3.71, 164.88, 2.81 Q 175.00, 2.60, 185.12, 3.39 Q 195.24, 3.40, 205.35, 3.23 Q\
                  215.47, 2.30, 225.59, 2.68 Q 235.71, 2.87, 245.82, 2.12 Q 255.94, 3.41, 266.06, 2.44 Q 276.18, 4.03, 286.29, 4.11 Q 296.41,\
                  3.78, 306.53, 3.98 Q 316.65, 2.81, 326.76, 2.61 Q 336.88, 3.00, 347.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput538450841_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-624246759-layer-textinput538450841input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-624246759-layer-textinput538450841_input_svg_border\',\'__containerId__-624246759-layer-textinput538450841_line1\',\'__containerId__-624246759-layer-textinput538450841_line2\',\'__containerId__-624246759-layer-textinput538450841_line3\',\'__containerId__-624246759-layer-textinput538450841_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-624246759-layer-textinput538450841_input_svg_border\',\'__containerId__-624246759-layer-textinput538450841_line1\',\'__containerId__-624246759-layer-textinput538450841_line2\',\'__containerId__-624246759-layer-textinput538450841_line3\',\'__containerId__-624246759-layer-textinput538450841_line4\'))" value="" style="width:343px;height:28px;padding: 0px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-624246759-layer-button63210799" style="position: absolute; left: 235px; top: 370px; width: 83px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button63210799" data-review-reference-id="button63210799">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:83px;" width="83" height="30">\
               <svg:g width="83" height="30"><svg:path d="M 2.00, 2.00 Q 14.67, 1.19, 27.33, 1.00 Q 40.00, 0.96, 52.67, 0.84 Q 65.33, 1.62, 78.19, 1.81 Q 78.82, 13.23,\
                  78.40, 25.40 Q 65.38, 25.18, 52.65, 24.83 Q 40.03, 25.53, 27.33, 24.88 Q 14.67, 25.60, 1.39, 25.61 Q 2.00, 13.50, 2.00, 2.00"\
                  style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 79.00, 4.00 Q 79.00, 16.00, 79.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 80.00, 5.00 Q 80.00, 17.00, 80.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 81.00, 6.00 Q 81.00, 18.00, 81.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 16.83, 25.28, 29.67, 25.09 Q 42.50, 24.92, 55.33, 24.80 Q 68.17, 26.00, 81.00, 26.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 17.83, 26.83, 30.67, 26.79 Q 43.50, 27.11, 56.33, 26.31 Q 69.17, 27.00, 82.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 18.83, 27.75, 31.67, 26.77 Q 44.50, 26.29, 57.33, 25.44 Q 70.17, 28.00, 83.00, 28.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-624246759-layer-button63210799button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-624246759-layer-button63210799button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-624246759-layer-button63210799button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:79px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Comment<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-624246759-layer-textinput723798342" style="position: absolute; left: 235px; top: 420px; width: 450px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput723798342" data-review-reference-id="textinput723798342">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:450px;" width="450" height="30">\
               <svg:g id="__containerId__-624246759-layer-textinput723798342svg" width="450" height="30"><svg:path id="__containerId__-624246759-layer-textinput723798342_input_svg_border" d="M 2.00, 2.00 Q 12.14, 2.35, 22.27, 1.96\
                  Q 32.41, 1.68, 42.55, 2.23 Q 52.68, 2.07, 62.82, 1.67 Q 72.95, 2.84, 83.09, 2.26 Q 93.23, 1.31, 103.36, 1.55 Q 113.50, 0.92,\
                  123.64, 0.22 Q 133.77, 0.50, 143.91, 2.16 Q 154.05, 2.70, 164.18, 2.99 Q 174.32, 1.10, 184.45, 0.95 Q 194.59, 1.12, 204.73,\
                  1.27 Q 214.86, 1.23, 225.00, 1.09 Q 235.14, 1.89, 245.27, 0.56 Q 255.41, 1.04, 265.55, 0.88 Q 275.68, 1.07, 285.82, 1.20 Q\
                  295.95, 1.36, 306.09, 1.02 Q 316.23, 1.37, 326.36, 2.17 Q 336.50, 1.31, 346.64, 1.20 Q 356.77, 1.34, 366.91, 1.33 Q 377.05,\
                  1.75, 387.18, 1.18 Q 397.32, 0.66, 407.45, 0.90 Q 417.59, 1.07, 427.73, 0.60 Q 437.86, 0.67, 448.91, 1.09 Q 448.75, 14.75,\
                  448.20, 28.20 Q 438.12, 28.95, 427.90, 29.57 Q 417.67, 29.50, 407.46, 28.40 Q 397.33, 29.14, 387.19, 28.87 Q 377.05, 28.33,\
                  366.91, 29.57 Q 356.77, 29.75, 346.64, 30.07 Q 336.50, 29.86, 326.36, 29.29 Q 316.23, 27.85, 306.09, 29.04 Q 295.95, 28.74,\
                  285.82, 28.42 Q 275.68, 28.43, 265.55, 28.24 Q 255.41, 28.66, 245.27, 29.40 Q 235.14, 29.74, 225.00, 29.74 Q 214.86, 29.66,\
                  204.73, 29.26 Q 194.59, 29.14, 184.45, 29.79 Q 174.32, 29.25, 164.18, 28.84 Q 154.05, 29.04, 143.91, 29.46 Q 133.77, 29.41,\
                  123.64, 29.45 Q 113.50, 29.50, 103.36, 28.87 Q 93.23, 30.12, 83.09, 29.08 Q 72.95, 29.69, 62.82, 29.93 Q 52.68, 29.60, 42.55,\
                  29.18 Q 32.41, 29.74, 22.27, 29.72 Q 12.14, 29.97, 0.92, 29.08 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput723798342_line1" d="M 3.00, 3.00 Q 13.09, 1.73, 23.18, 1.64 Q 33.27,\
                  2.11, 43.36, 2.07 Q 53.45, 2.86, 63.55, 2.21 Q 73.64, 2.17, 83.73, 2.92 Q 93.82, 2.55, 103.91, 2.91 Q 114.00, 2.75, 124.09,\
                  1.45 Q 134.18, 2.36, 144.27, 1.68 Q 154.36, 2.31, 164.45, 3.24 Q 174.55, 2.52, 184.64, 2.03 Q 194.73, 2.28, 204.82, 2.46 Q\
                  214.91, 3.15, 225.00, 2.87 Q 235.09, 1.48, 245.18, 0.95 Q 255.27, 1.57, 265.36, 1.93 Q 275.45, 1.31, 285.55, 0.86 Q 295.64,\
                  1.16, 305.73, 1.72 Q 315.82, 3.28, 325.91, 3.57 Q 336.00, 3.00, 346.09, 2.52 Q 356.18, 2.12, 366.27, 1.67 Q 376.36, 2.34,\
                  386.45, 2.24 Q 396.55, 2.29, 406.64, 2.02 Q 416.73, 2.47, 426.82, 1.78 Q 436.91, 3.00, 447.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput723798342_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput723798342_line3" d="M 3.00, 3.00 Q 13.09, 2.29, 23.18, 2.22 Q 33.27,\
                  2.74, 43.36, 2.63 Q 53.45, 2.43, 63.55, 3.14 Q 73.64, 2.48, 83.73, 3.05 Q 93.82, 2.78, 103.91, 2.23 Q 114.00, 4.05, 124.09,\
                  3.38 Q 134.18, 3.43, 144.27, 2.81 Q 154.36, 3.90, 164.45, 3.65 Q 174.55, 3.69, 184.64, 3.39 Q 194.73, 2.32, 204.82, 2.46 Q\
                  214.91, 3.75, 225.00, 3.87 Q 235.09, 2.54, 245.18, 2.62 Q 255.27, 2.95, 265.36, 3.49 Q 275.45, 2.66, 285.55, 2.34 Q 295.64,\
                  3.17, 305.73, 3.41 Q 315.82, 3.51, 325.91, 2.70 Q 336.00, 3.52, 346.09, 4.05 Q 356.18, 3.71, 366.27, 4.50 Q 376.36, 4.38,\
                  386.45, 3.11 Q 396.55, 2.39, 406.64, 2.83 Q 416.73, 2.66, 426.82, 4.43 Q 436.91, 3.00, 447.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-textinput723798342_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-624246759-layer-textinput723798342input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-624246759-layer-textinput723798342_input_svg_border\',\'__containerId__-624246759-layer-textinput723798342_line1\',\'__containerId__-624246759-layer-textinput723798342_line2\',\'__containerId__-624246759-layer-textinput723798342_line3\',\'__containerId__-624246759-layer-textinput723798342_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-624246759-layer-textinput723798342_input_svg_border\',\'__containerId__-624246759-layer-textinput723798342_line1\',\'__containerId__-624246759-layer-textinput723798342_line2\',\'__containerId__-624246759-layer-textinput723798342_line3\',\'__containerId__-624246759-layer-textinput723798342_line4\'))" value="comment1" style="width:443px;height:28px;padding: 0px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-624246759-layer-1759758224" style="position: absolute; left: 235px; top: 460px; width: 450px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1759758224" data-review-reference-id="1759758224">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:450px;" width="450" height="30">\
               <svg:g id="__containerId__-624246759-layer-1759758224svg" width="450" height="30"><svg:path id="__containerId__-624246759-layer-1759758224_input_svg_border" d="M 2.00, 2.00 Q 12.14, -0.10, 22.27, -0.28 Q\
                  32.41, 0.00, 42.55, 0.04 Q 52.68, 0.03, 62.82, 0.36 Q 72.95, 0.36, 83.09, 0.32 Q 93.23, 0.91, 103.36, 0.79 Q 113.50, 0.78,\
                  123.64, 0.94 Q 133.77, 1.23, 143.91, 1.00 Q 154.05, 0.96, 164.18, 0.90 Q 174.32, 1.58, 184.45, 1.65 Q 194.59, 1.93, 204.73,\
                  1.78 Q 214.86, 1.34, 225.00, 1.40 Q 235.14, 1.12, 245.27, 0.75 Q 255.41, 1.07, 265.55, 1.39 Q 275.68, 1.46, 285.82, 1.24 Q\
                  295.95, 1.35, 306.09, 1.03 Q 316.23, 0.89, 326.36, 0.39 Q 336.50, 0.84, 346.64, 1.28 Q 356.77, 2.07, 366.91, 2.24 Q 377.05,\
                  2.38, 387.18, 2.40 Q 397.32, 2.66, 407.45, 1.94 Q 417.59, 1.70, 427.73, 1.13 Q 437.86, 1.35, 448.23, 1.77 Q 448.02, 14.99,\
                  448.07, 28.07 Q 437.97, 28.37, 427.81, 28.76 Q 417.61, 28.38, 407.48, 29.07 Q 397.32, 28.53, 387.19, 28.81 Q 377.05, 28.42,\
                  366.91, 27.65 Q 356.77, 28.60, 346.64, 28.73 Q 336.50, 28.61, 326.36, 28.02 Q 316.23, 29.03, 306.09, 28.26 Q 295.95, 28.32,\
                  285.82, 28.64 Q 275.68, 29.00, 265.55, 29.77 Q 255.41, 29.32, 245.27, 29.46 Q 235.14, 28.77, 225.00, 29.26 Q 214.86, 28.29,\
                  204.73, 29.52 Q 194.59, 29.30, 184.45, 29.21 Q 174.32, 29.33, 164.18, 28.63 Q 154.05, 28.40, 143.91, 28.46 Q 133.77, 27.91,\
                  123.64, 27.47 Q 113.50, 28.08, 103.36, 29.21 Q 93.23, 28.70, 83.09, 28.95 Q 72.95, 28.88, 62.82, 29.25 Q 52.68, 28.47, 42.55,\
                  29.04 Q 32.41, 28.59, 22.27, 29.10 Q 12.14, 28.69, 1.78, 28.22 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-1759758224_line1" d="M 3.00, 3.00 Q 13.09, 0.77, 23.18, 1.38 Q 33.27, 1.86,\
                  43.36, 2.52 Q 53.45, 2.66, 63.55, 2.92 Q 73.64, 1.74, 83.73, 3.40 Q 93.82, 2.80, 103.91, 3.72 Q 114.00, 4.40, 124.09, 4.85\
                  Q 134.18, 3.77, 144.27, 2.11 Q 154.36, 3.40, 164.45, 3.37 Q 174.55, 3.52, 184.64, 2.00 Q 194.73, 2.55, 204.82, 3.42 Q 214.91,\
                  3.61, 225.00, 3.60 Q 235.09, 3.64, 245.18, 4.09 Q 255.27, 3.57, 265.36, 3.73 Q 275.45, 2.31, 285.55, 2.08 Q 295.64, 2.63,\
                  305.73, 2.50 Q 315.82, 2.06, 325.91, 1.64 Q 336.00, 1.81, 346.09, 2.48 Q 356.18, 1.85, 366.27, 0.96 Q 376.36, 0.80, 386.45,\
                  1.46 Q 396.55, 2.19, 406.64, 2.19 Q 416.73, 2.35, 426.82, 2.34 Q 436.91, 3.00, 447.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-1759758224_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                  class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-1759758224_line3" d="M 3.00, 3.00 Q 13.09, 1.60, 23.18, 1.93 Q 33.27, 2.01,\
                  43.36, 2.20 Q 53.45, 3.01, 63.55, 2.92 Q 73.64, 2.58, 83.73, 3.41 Q 93.82, 4.28, 103.91, 3.48 Q 114.00, 3.62, 124.09, 2.43\
                  Q 134.18, 1.88, 144.27, 1.72 Q 154.36, 2.06, 164.45, 2.37 Q 174.55, 2.35, 184.64, 3.81 Q 194.73, 2.74, 204.82, 2.96 Q 214.91,\
                  2.51, 225.00, 3.50 Q 235.09, 2.63, 245.18, 2.59 Q 255.27, 3.23, 265.36, 2.46 Q 275.45, 2.92, 285.55, 2.99 Q 295.64, 2.78,\
                  305.73, 2.28 Q 315.82, 2.50, 325.91, 2.41 Q 336.00, 2.26, 346.09, 1.96 Q 356.18, 2.21, 366.27, 3.84 Q 376.36, 2.65, 386.45,\
                  2.32 Q 396.55, 1.38, 406.64, 2.87 Q 416.73, 3.22, 426.82, 1.82 Q 436.91, 3.00, 447.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-624246759-layer-1759758224_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-624246759-layer-1759758224input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-624246759-layer-1759758224_input_svg_border\',\'__containerId__-624246759-layer-1759758224_line1\',\'__containerId__-624246759-layer-1759758224_line2\',\'__containerId__-624246759-layer-1759758224_line3\',\'__containerId__-624246759-layer-1759758224_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-624246759-layer-1759758224_input_svg_border\',\'__containerId__-624246759-layer-1759758224_line1\',\'__containerId__-624246759-layer-1759758224_line2\',\'__containerId__-624246759-layer-1759758224_line3\',\'__containerId__-624246759-layer-1759758224_line4\'))" value="comment2" style="width:443px;height:28px;padding: 0px;" type="text" /></div>\
         </div>\
      </div>\
   </div>\
</div>');