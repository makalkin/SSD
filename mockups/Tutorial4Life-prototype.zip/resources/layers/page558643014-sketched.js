rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page558643014-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page558643014" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page558643014-layer-text878174480" style="position: absolute; left: 735px; top: 15px; width: 72px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text878174480" data-review-reference-id="text878174480">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Username<br /><br /></p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-button831158747" style="position: absolute; left: 815px; top: 10px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button831158747" data-review-reference-id="button831158747">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:68px;" width="68" height="30">\
               <svg:g width="68" height="30"><svg:path d="M 2.00, 2.00 Q 12.17, 2.60, 22.33, 2.58 Q 32.50, 2.34, 42.67, 2.54 Q 52.83, 2.51, 62.96, 2.04 Q 62.32, 13.73,\
                  63.12, 25.12 Q 52.83, 24.99, 42.74, 25.62 Q 32.55, 25.95, 22.36, 26.22 Q 12.18, 25.78, 1.96, 25.04 Q 2.00, 13.50, 2.00, 2.00"\
                  style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 64.00, 4.00 Q 64.00, 16.00, 64.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 65.00, 5.00 Q 65.00, 17.00, 65.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 66.00, 6.00 Q 66.00, 18.00, 66.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.33, 25.07, 24.67, 24.76 Q 35.00, 25.08, 45.33, 24.82 Q 55.67, 26.00, 66.00, 26.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.33, 25.95, 25.67, 26.10 Q 36.00, 26.25, 46.33, 25.96 Q 56.67, 27.00, 67.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.33, 26.76, 26.67, 27.14 Q 37.00, 27.46, 47.33, 26.93 Q 57.67, 28.00, 68.00, 28.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page558643014-layer-button831158747button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page558643014-layer-button831158747button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page558643014-layer-button831158747button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:64px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Logout<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-button68202122" style="position: absolute; left: 815px; top: 50px; width: 131px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button68202122" data-review-reference-id="button68202122">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:131px;" width="131" height="30">\
               <svg:g width="131" height="30"><svg:path d="M 2.00, 2.00 Q 12.33, 0.87, 22.67, 1.58 Q 33.00, 2.56, 43.33, 2.59 Q 53.67, 2.72, 64.00, 3.66 Q 74.33, 3.09,\
                  84.67, 3.29 Q 95.00, 2.91, 105.33, 3.36 Q 115.67, 2.93, 125.10, 2.90 Q 125.29, 13.74, 125.94, 24.94 Q 115.60, 24.75, 105.28,\
                  24.56 Q 95.00, 24.96, 84.67, 25.20 Q 74.33, 24.43, 64.00, 24.16 Q 53.67, 25.49, 43.33, 24.92 Q 33.00, 25.17, 22.67, 24.19\
                  Q 12.33, 24.43, 2.06, 24.94 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 127.00, 4.00 Q 127.00, 16.00, 127.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 128.00, 5.00 Q 128.00, 17.00, 128.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 129.00, 6.00 Q 129.00, 18.00, 129.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.42, 26.29, 24.83, 25.98 Q 35.25, 26.17, 45.67, 25.46 Q 56.08, 26.30, 66.50, 25.72 Q 76.92,\
                  26.06, 87.33, 24.48 Q 97.75, 25.39, 108.17, 26.03 Q 118.58, 26.00, 129.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.42, 26.69, 25.83, 26.65 Q 36.25, 26.86, 46.67, 26.63 Q 57.08, 26.53, 67.50, 27.40 Q 77.92,\
                  27.18, 88.33, 26.26 Q 98.75, 25.95, 109.17, 26.72 Q 119.58, 27.00, 130.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.42, 27.03, 26.83, 26.79 Q 37.25, 27.08, 47.67, 27.05 Q 58.08, 27.00, 68.50, 27.56 Q 78.92,\
                  27.48, 89.33, 27.03 Q 99.75, 28.08, 110.17, 26.97 Q 120.58, 28.00, 131.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page558643014-layer-button68202122button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page558643014-layer-button68202122button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page558643014-layer-button68202122button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:127px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Back to main page<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text431207104" style="position: absolute; left: 20px; top: 25px; width: 141px; height: 24px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text431207104" data-review-reference-id="text431207104">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p><span style="font-size: 20px;">Some category</span></p>\
                  <p style="font-size: 14px;"><span style="font-size: 20px;"> </span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-listview301687306" style="position: absolute; left: 235px; top: 310px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview301687306" data-review-reference-id="listview301687306">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 65px;width:450px;" width="450" height="65">\
               <svg:g width="450" height="65"><svg:path id="__containerId__-page558643014-layer-listview301687306_input_svg_border" d="M 2.00, 2.00 Q 12.14, 1.82, 22.27,\
                  1.77 Q 32.41, 1.49, 42.55, 1.38 Q 52.68, 1.32, 62.82, 1.56 Q 72.95, 1.82, 83.09, 1.32 Q 93.23, 1.99, 103.36, 0.82 Q 113.50,\
                  1.15, 123.64, 1.39 Q 133.77, 1.76, 143.91, 1.50 Q 154.05, 0.13, 164.18, 0.68 Q 174.32, 1.82, 184.45, 2.27 Q 194.59, 1.17,\
                  204.73, 0.81 Q 214.86, 1.29, 225.00, 1.62 Q 235.14, 1.63, 245.27, 1.63 Q 255.41, 2.84, 265.55, 1.82 Q 275.68, 1.94, 285.82,\
                  0.94 Q 295.95, 0.18, 306.09, -0.03 Q 316.23, 0.50, 326.36, 0.67 Q 336.50, 1.48, 346.64, 1.57 Q 356.77, 0.94, 366.91, 1.36\
                  Q 377.05, 0.66, 387.18, 0.30 Q 397.32, 0.32, 407.45, 0.52 Q 417.59, 0.82, 427.73, 0.55 Q 437.86, 1.06, 448.72, 1.28 Q 448.01,\
                  12.16, 448.85, 22.21 Q 449.41, 32.41, 449.01, 42.63 Q 447.64, 52.84, 448.00, 63.00 Q 438.11, 63.74, 427.91, 64.30 Q 417.70,\
                  64.64, 407.48, 63.94 Q 397.35, 64.81, 387.20, 64.98 Q 377.05, 65.01, 366.91, 65.04 Q 356.77, 65.33, 346.64, 65.33 Q 336.50,\
                  65.49, 326.36, 65.69 Q 316.23, 65.18, 306.09, 65.25 Q 295.95, 64.78, 285.82, 63.62 Q 275.68, 62.81, 265.55, 63.27 Q 255.41,\
                  63.76, 245.27, 64.07 Q 235.14, 63.97, 225.00, 63.94 Q 214.86, 64.15, 204.73, 64.22 Q 194.59, 63.86, 184.45, 63.86 Q 174.32,\
                  63.34, 164.18, 63.77 Q 154.05, 64.74, 143.91, 63.94 Q 133.77, 64.05, 123.64, 63.95 Q 113.50, 64.78, 103.36, 64.59 Q 93.23,\
                  63.23, 83.09, 63.33 Q 72.95, 64.45, 62.82, 64.53 Q 52.68, 63.63, 42.55, 62.75 Q 32.41, 62.49, 22.27, 63.13 Q 12.14, 63.90,\
                  1.76, 63.24 Q 1.08, 53.14, 1.64, 42.72 Q 1.74, 32.52, 1.93, 22.34 Q 2.00, 12.17, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page558643014-layer-listview301687306select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page558643014-layer-listview301687306_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page558643014-layer-listview301687306_input_svg_border\')" style="width:442px; height:57px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page558643014-layer-listview311859739" style="position: absolute; left: 235px; top: 225px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview311859739" data-review-reference-id="listview311859739">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 65px;width:450px;" width="450" height="65">\
               <svg:g width="450" height="65"><svg:path id="__containerId__-page558643014-layer-listview311859739_input_svg_border" d="M 2.00, 2.00 Q 12.14, 0.13, 22.27,\
                  -0.04 Q 32.41, -0.13, 42.55, -0.08 Q 52.68, 0.26, 62.82, 0.06 Q 72.95, -0.12, 83.09, -0.01 Q 93.23, 0.45, 103.36, 0.41 Q 113.50,\
                  0.85, 123.64, 0.67 Q 133.77, 0.49, 143.91, 0.34 Q 154.05, 0.39, 164.18, 0.65 Q 174.32, 1.10, 184.45, 1.13 Q 194.59, 1.15,\
                  204.73, 0.84 Q 214.86, 0.76, 225.00, 1.46 Q 235.14, 1.49, 245.27, 1.21 Q 255.41, 1.45, 265.55, 1.37 Q 275.68, 1.17, 285.82,\
                  1.09 Q 295.95, 0.68, 306.09, 1.67 Q 316.23, 1.42, 326.36, 1.49 Q 336.50, 1.56, 346.64, 1.43 Q 356.77, 1.29, 366.91, 1.50 Q\
                  377.05, 2.14, 387.18, 1.65 Q 397.32, 1.27, 407.45, 0.89 Q 417.59, 0.45, 427.73, 0.63 Q 437.86, 1.47, 448.17, 1.83 Q 448.63,\
                  11.96, 447.77, 22.37 Q 447.58, 32.53, 448.69, 42.64 Q 448.14, 52.83, 448.11, 63.11 Q 437.88, 63.06, 427.74, 63.13 Q 417.62,\
                  63.47, 407.46, 63.15 Q 397.32, 63.13, 387.19, 64.02 Q 377.05, 64.16, 366.91, 64.62 Q 356.77, 64.31, 346.64, 62.50 Q 336.50,\
                  62.13, 326.36, 63.18 Q 316.23, 62.63, 306.09, 63.01 Q 295.95, 61.69, 285.82, 63.09 Q 275.68, 62.65, 265.55, 62.84 Q 255.41,\
                  62.91, 245.27, 62.97 Q 235.14, 63.87, 225.00, 63.34 Q 214.86, 63.32, 204.73, 62.66 Q 194.59, 63.43, 184.45, 63.49 Q 174.32,\
                  64.57, 164.18, 63.87 Q 154.05, 63.46, 143.91, 63.91 Q 133.77, 63.69, 123.64, 64.16 Q 113.50, 64.36, 103.36, 64.33 Q 93.23,\
                  63.32, 83.09, 63.91 Q 72.95, 64.26, 62.82, 64.46 Q 52.68, 64.63, 42.55, 64.70 Q 32.41, 64.64, 22.27, 63.53 Q 12.14, 63.96,\
                  1.58, 63.42 Q 1.34, 53.05, 0.57, 42.87 Q 1.83, 32.51, 2.01, 22.33 Q 2.00, 12.17, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page558643014-layer-listview311859739select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page558643014-layer-listview311859739_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page558643014-layer-listview311859739_input_svg_border\')" style="width:442px; height:57px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page558643014-layer-1757430935" style="position: absolute; left: 235px; top: 135px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1757430935" data-review-reference-id="1757430935">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 65px;width:450px;" width="450" height="65">\
               <svg:g width="450" height="65"><svg:path id="__containerId__-page558643014-layer-1757430935_input_svg_border" d="M 2.00, 2.00 Q 12.14, 0.20, 22.27, 0.13\
                  Q 32.41, 0.48, 42.55, 0.43 Q 52.68, 0.53, 62.82, 0.83 Q 72.95, 0.75, 83.09, 0.98 Q 93.23, 0.40, 103.36, 0.91 Q 113.50, 1.17,\
                  123.64, 1.55 Q 133.77, 1.49, 143.91, 1.40 Q 154.05, 1.55, 164.18, 1.58 Q 174.32, 0.67, 184.45, 0.93 Q 194.59, 0.85, 204.73,\
                  1.30 Q 214.86, 1.09, 225.00, 1.16 Q 235.14, 1.95, 245.27, 1.59 Q 255.41, 1.83, 265.55, 1.52 Q 275.68, 1.17, 285.82, 0.91 Q\
                  295.95, 0.98, 306.09, 1.36 Q 316.23, 1.86, 326.36, 2.03 Q 336.50, 0.96, 346.64, 0.49 Q 356.77, 0.48, 366.91, 0.69 Q 377.05,\
                  -0.22, 387.18, 0.67 Q 397.32, 0.96, 407.45, 1.09 Q 417.59, 1.88, 427.73, 1.30 Q 437.86, 1.03, 448.28, 1.72 Q 447.97, 12.18,\
                  447.89, 22.35 Q 447.83, 32.51, 448.25, 42.66 Q 448.33, 52.83, 448.10, 63.10 Q 438.03, 63.50, 427.80, 63.50 Q 417.70, 64.60,\
                  407.47, 63.56 Q 397.34, 64.30, 387.19, 64.07 Q 377.05, 64.41, 366.91, 63.98 Q 356.77, 63.98, 346.64, 64.27 Q 336.50, 63.73,\
                  326.36, 63.52 Q 316.23, 63.13, 306.09, 63.40 Q 295.95, 63.52, 285.82, 63.85 Q 275.68, 64.01, 265.55, 64.18 Q 255.41, 64.75,\
                  245.27, 63.78 Q 235.14, 64.13, 225.00, 63.59 Q 214.86, 64.87, 204.73, 65.09 Q 194.59, 64.62, 184.45, 64.32 Q 174.32, 64.33,\
                  164.18, 64.08 Q 154.05, 63.59, 143.91, 63.89 Q 133.77, 63.07, 123.64, 63.02 Q 113.50, 62.99, 103.36, 63.29 Q 93.23, 63.14,\
                  83.09, 62.83 Q 72.95, 63.38, 62.82, 63.11 Q 52.68, 64.19, 42.55, 63.86 Q 32.41, 63.27, 22.27, 63.45 Q 12.14, 63.39, 2.23,\
                  62.77 Q 2.46, 52.68, 1.89, 42.68 Q 1.69, 32.52, 1.20, 22.36 Q 2.00, 12.17, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page558643014-layer-1757430935select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page558643014-layer-1757430935_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page558643014-layer-1757430935_input_svg_border\')" style="width:442px; height:57px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page558643014-layer-502087180" style="position: absolute; left: 235px; top: 400px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="502087180" data-review-reference-id="502087180">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 65px;width:450px;" width="450" height="65">\
               <svg:g width="450" height="65"><svg:path id="__containerId__-page558643014-layer-502087180_input_svg_border" d="M 2.00, 2.00 Q 12.14, -0.48, 22.27, 0.01\
                  Q 32.41, 0.39, 42.55, 0.53 Q 52.68, 0.79, 62.82, 0.96 Q 72.95, 0.82, 83.09, 0.67 Q 93.23, 1.00, 103.36, 0.51 Q 113.50, 1.50,\
                  123.64, 0.72 Q 133.77, 0.41, 143.91, 0.36 Q 154.05, 0.18, 164.18, 0.08 Q 174.32, 0.68, 184.45, 0.94 Q 194.59, 0.46, 204.73,\
                  0.34 Q 214.86, 0.80, 225.00, 2.46 Q 235.14, 1.26, 245.27, 0.81 Q 255.41, 0.55, 265.55, 0.29 Q 275.68, 0.19, 285.82, 0.10 Q\
                  295.95, 0.04, 306.09, -0.11 Q 316.23, -0.32, 326.36, 0.33 Q 336.50, 0.51, 346.64, 0.85 Q 356.77, 1.24, 366.91, 1.16 Q 377.05,\
                  1.12, 387.18, 1.02 Q 397.32, 0.12, 407.45, 1.10 Q 417.59, 0.74, 427.73, 1.36 Q 437.86, 2.60, 447.18, 2.82 Q 447.18, 12.44,\
                  447.94, 22.34 Q 449.65, 32.39, 448.16, 42.66 Q 447.71, 52.84, 448.09, 63.09 Q 438.06, 63.58, 427.84, 63.78 Q 417.64, 63.82,\
                  407.49, 64.06 Q 397.33, 63.81, 387.19, 63.81 Q 377.05, 64.19, 366.91, 63.96 Q 356.77, 64.83, 346.64, 64.48 Q 336.50, 64.41,\
                  326.36, 64.54 Q 316.23, 64.91, 306.09, 64.11 Q 295.95, 63.72, 285.82, 63.96 Q 275.68, 63.81, 265.55, 62.71 Q 255.41, 63.70,\
                  245.27, 63.14 Q 235.14, 63.29, 225.00, 63.59 Q 214.86, 64.01, 204.73, 63.77 Q 194.59, 63.68, 184.45, 62.82 Q 174.32, 63.86,\
                  164.18, 64.09 Q 154.05, 63.66, 143.91, 62.97 Q 133.77, 63.40, 123.64, 63.97 Q 113.50, 64.37, 103.36, 63.47 Q 93.23, 62.90,\
                  83.09, 63.11 Q 72.95, 63.03, 62.82, 62.24 Q 52.68, 61.48, 42.55, 61.74 Q 32.41, 61.61, 22.27, 62.24 Q 12.14, 64.11, 1.03,\
                  63.97 Q 1.62, 52.96, 2.50, 42.60 Q 2.65, 32.46, 3.67, 22.28 Q 2.00, 12.17, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page558643014-layer-502087180select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page558643014-layer-502087180_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page558643014-layer-502087180_input_svg_border\')" style="width:442px; height:57px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text200033302" style="position: absolute; left: 235px; top: 100px; width: 178px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text200033302" data-review-reference-id="text200033302">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>Tutorials from this category<br />\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-listview167521364" style="position: absolute; left: 15px; top: 135px; width: 150px; height: 330px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview167521364" data-review-reference-id="listview167521364">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 330px;width:150px;" width="150" height="330">\
               <svg:g width="150" height="330"><svg:path id="__containerId__-page558643014-layer-listview167521364_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.57, 22.86,\
                  1.38 Q 33.29, 1.29, 43.71, 1.13 Q 54.14, 0.95, 64.57, 0.88 Q 75.00, 0.70, 85.43, 0.77 Q 95.86, 0.33, 106.29, 0.69 Q 116.71,\
                  0.65, 127.14, 0.51 Q 137.57, 0.40, 148.89, 1.11 Q 149.10, 11.82, 149.07, 22.22 Q 148.98, 32.50, 149.79, 42.69 Q 149.85, 52.91,\
                  149.73, 63.11 Q 149.21, 73.31, 149.37, 83.50 Q 149.55, 93.69, 149.20, 103.87 Q 149.63, 114.06, 149.65, 124.25 Q 149.80, 134.44,\
                  149.98, 144.62 Q 149.95, 154.81, 149.47, 165.00 Q 149.55, 175.19, 148.74, 185.38 Q 148.52, 195.56, 148.67, 205.75 Q 149.27,\
                  215.94, 149.85, 226.12 Q 148.99, 236.31, 149.66, 246.50 Q 149.15, 256.69, 149.28, 266.88 Q 149.18, 277.06, 148.40, 287.25\
                  Q 147.92, 297.44, 148.77, 307.62 Q 149.50, 317.81, 148.57, 328.57 Q 137.55, 327.93, 127.20, 328.37 Q 116.75, 328.48, 106.30,\
                  328.57 Q 95.87, 328.99, 85.43, 328.77 Q 75.00, 328.62, 64.57, 329.36 Q 54.14, 329.23, 43.72, 329.75 Q 33.29, 329.72, 22.86,\
                  329.62 Q 12.43, 328.68, 1.81, 328.19 Q 1.21, 318.08, 1.17, 307.74 Q 1.95, 297.44, 1.74, 287.26 Q 1.42, 277.07, 1.35, 266.88\
                  Q 1.48, 256.69, 2.04, 246.50 Q 1.62, 236.31, 1.72, 226.13 Q 1.44, 215.94, 0.70, 205.75 Q 1.25, 195.56, 1.78, 185.38 Q 0.85,\
                  175.19, 0.62, 165.00 Q 0.72, 154.81, 1.03, 144.62 Q 1.54, 134.44, 0.42, 124.25 Q -0.07, 114.06, 0.75, 103.88 Q 0.99, 93.69,\
                  1.90, 83.50 Q 3.14, 73.31, 2.62, 63.12 Q 1.56, 52.94, 1.25, 42.75 Q 1.80, 32.56, 0.19, 22.38 Q 2.00, 12.19, 2.00, 2.00" style="\
                  fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page558643014-layer-listview167521364select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page558643014-layer-listview167521364_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page558643014-layer-listview167521364_input_svg_border\')" style="width:142px; height:322px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text827134341" style="position: absolute; left: 20px; top: 100px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text827134341" data-review-reference-id="text827134341">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-414675866" style="position: absolute; left: 775px; top: 105px; width: 107px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="414675866" data-review-reference-id="414675866">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Popular authors</p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-14089559" style="position: absolute; left: 765px; top: 135px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="14089559" data-review-reference-id="14089559">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 140px;width:150px;" width="150" height="140">\
               <svg:g width="150" height="140"><svg:path id="__containerId__-page558643014-layer-14089559_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.41, 22.86, 0.98 Q\
                  33.29, 0.74, 43.71, 0.66 Q 54.14, 1.36, 64.57, 0.79 Q 75.00, 0.50, 85.43, 0.79 Q 95.86, 1.16, 106.29, 1.65 Q 116.71, 1.30,\
                  127.14, 0.50 Q 137.57, 0.25, 148.90, 1.10 Q 148.71, 13.10, 149.00, 24.52 Q 149.09, 35.93, 149.17, 47.30 Q 149.39, 58.64, 149.45,\
                  69.99 Q 149.65, 81.33, 149.80, 92.66 Q 149.81, 104.00, 149.64, 115.33 Q 149.51, 126.67, 148.76, 138.76 Q 138.06, 139.48, 127.36,\
                  139.50 Q 116.74, 138.44, 106.29, 138.24 Q 95.87, 138.65, 85.44, 138.92 Q 75.00, 137.76, 64.57, 138.95 Q 54.14, 137.91, 43.71,\
                  138.48 Q 33.29, 138.79, 22.86, 138.60 Q 12.43, 139.01, 1.66, 138.34 Q 1.61, 126.80, 1.03, 115.47 Q 0.87, 104.08, 0.28, 92.72\
                  Q 0.93, 81.35, 0.98, 70.01 Q 1.11, 58.67, 1.18, 47.33 Q 1.23, 36.00, 0.90, 24.67 Q 2.00, 13.33, 2.00, 2.00" style=" fill:white;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page558643014-layer-14089559select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page558643014-layer-14089559_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page558643014-layer-14089559_input_svg_border\')" style="width:142px; height:132px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text584423363" style="position: absolute; left: 775px; top: 295px; width: 91px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text584423363" data-review-reference-id="text584423363">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Latest guides</p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-654226594" style="position: absolute; left: 765px; top: 330px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="654226594" data-review-reference-id="654226594">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 140px;width:150px;" width="150" height="140">\
               <svg:g width="150" height="140"><svg:path id="__containerId__-page558643014-layer-654226594_input_svg_border" d="M 2.00, 2.00 Q 12.43, 0.77, 22.86, 0.51 Q\
                  33.29, 0.39, 43.71, 0.10 Q 54.14, -0.01, 64.57, 0.46 Q 75.00, 0.06, 85.43, -0.02 Q 95.86, -0.26, 106.29, -0.34 Q 116.71, -0.16,\
                  127.14, 0.36 Q 137.57, 0.11, 148.90, 1.10 Q 149.31, 12.90, 149.51, 24.45 Q 149.62, 35.89, 150.20, 47.26 Q 150.17, 58.63, 150.26,\
                  69.98 Q 149.71, 81.33, 149.52, 92.66 Q 149.28, 104.00, 149.04, 115.33 Q 148.92, 126.67, 148.68, 138.68 Q 137.95, 139.15, 127.29,\
                  139.06 Q 116.77, 138.82, 106.31, 138.78 Q 95.87, 138.76, 85.44, 138.90 Q 75.00, 138.60, 64.57, 138.81 Q 54.14, 139.47, 43.72,\
                  139.98 Q 33.29, 139.60, 22.86, 139.77 Q 12.43, 138.89, 1.41, 138.59 Q 1.82, 126.73, 1.64, 115.38 Q 1.30, 104.05, 1.11, 92.70\
                  Q 0.46, 81.36, 0.90, 70.01 Q 0.66, 58.67, 0.60, 47.34 Q 1.53, 36.00, 1.68, 24.67 Q 2.00, 13.33, 2.00, 2.00" style=" fill:white;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page558643014-layer-654226594select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page558643014-layer-654226594_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page558643014-layer-654226594_input_svg_border\')" style="width:142px; height:132px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
   </div>\
</div>');