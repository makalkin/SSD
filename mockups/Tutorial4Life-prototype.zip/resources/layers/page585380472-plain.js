rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page585380472-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page585380472" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page585380472-layer-iphoneButton522756103" style="position: absolute; left: 900px; top: 5px; width: 54px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton522756103" data-review-reference-id="iphoneButton522756103">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:54px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="54" height="30" viewBox="0 0 54 30">\
               <svg:a>\
                  <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 44,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                  <svg:text x="27" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Вийти</svg:text>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-iphoneListBackground52355221" style="position: absolute; left: 735px; top: 55px; width: 205px; height: 300px" data-interactive-element-type="static.iphoneListBackground" class="iphoneListBackground stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneListBackground52355221" data-review-reference-id="iphoneListBackground52355221">\
         <div title="" style="height: 300px; width:205px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="205" height="300" viewBox="0 0 205 300">\
               <svg:rect x="1" y="1" width="203" rx="10" height="298" style="stroke-width:1;fill:white;;stroke:black;"></svg:rect>\
               <svg:line x1="1" y1="40" x2="203" y2="40" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="80" x2="203" y2="80" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="120" x2="203" y2="120" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="160" x2="203" y2="160" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="200" x2="203" y2="200" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="240" x2="203" y2="240" style="stroke-width:1;stroke:black;"></svg:line>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button19245637" style="position: absolute; left: 735px; top: 15px; width: 120px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button19245637" data-review-reference-id="button19245637">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:120px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Обране<br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button821046572" style="position: absolute; left: 490px; top: 15px; width: 228px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button821046572" data-review-reference-id="button821046572">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:228px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Поправки залишені користувачами<br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button154936559" style="position: absolute; left: 370px; top: 15px; width: 96px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button154936559" data-review-reference-id="button154936559">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:96px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Нові відгуки<br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button701267870" style="position: absolute; left: 260px; top: 15px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button701267870" data-review-reference-id="button701267870">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:68px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Пошта<br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-textinput56959620" style="position: absolute; left: 15px; top: 70px; width: 210px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput56959620" data-review-reference-id="textinput56959620">\
         <div title=""><input id="__containerId__-page585380472-layer-textinput56959620input" value="Назва статті" style="width:208px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button501595982" style="position: absolute; left: 35px; top: 15px; width: 175px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button501595982" data-review-reference-id="button501595982">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:175px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Основні вимоги до статті<br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button304101873" style="position: absolute; left: 755px; top: 455px; width: 174px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button304101873" data-review-reference-id="button304101873">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:174px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Відправити статтю адміну<br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button334392168" style="position: absolute; left: 515px; top: 455px; width: 226px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button334392168" data-review-reference-id="button334392168">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:226px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Перевірити на граматичні помилки<br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-iframe65868827" style="position: absolute; left: 250px; top: 75px; width: 445px; height: 335px" data-interactive-element-type="default.iframe" class="iframe stencil mobile-interaction-potential-trigger " data-stencil-id="iframe65868827" data-review-reference-id="iframe65868827">\
         <div iclass="renderEmptyPage" style="width:443px;height:333px;overflow:auto;border:1px solid black;background-color:white;">Frame without target</div>\
      </div>\
      <div id="__containerId__-page585380472-layer-combobox462708196" style="position: absolute; left: 15px; top: 115px; width: 210px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox462708196" data-review-reference-id="combobox462708196">\
         <div title=""><select id="__containerId__-page585380472-layer-combobox462708196select" style="width:210px;height:30px;" title="">\
               <option title="">Тематика</option>\
               <option title="">статті</option></select></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button222799341" style="position: absolute; left: 355px; top: 455px; width: 118px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button222799341" data-review-reference-id="button222799341">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:118px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Зберегти зміни <br /></button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-combobox576400449" style="position: absolute; left: 15px; top: 165px; width: 210px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox576400449" data-review-reference-id="combobox576400449">\
         <div title=""><select id="__containerId__-page585380472-layer-combobox576400449select" style="width:210px;height:30px;" title="">\
               <option title="">Жанр</option>\
               <option title="">статті</option></select></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-combobox792497376" style="position: absolute; left: 15px; top: 215px; width: 210px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox792497376" data-review-reference-id="combobox792497376">\
         <div title=""><select id="__containerId__-page585380472-layer-combobox792497376select" style="width:210px;height:30px;" title="">\
               <option title="">Співавтори</option>\
               <option title="">статті</option></select></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-text330417925" style="position: absolute; left: 285px; top: 120px; width: 280px; height: 240px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text330417925" data-review-reference-id="text330417925">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, ased diam nonumy eirmod tempor invidunt\
                  ut labore et adolore magna aliquyam erat, sed diam voluptua. At avero eos et accusam et justo duo dolores et ea rebum. aStet\
                  clita kasd gubergren, no sea takimata sanctus est aLorem ipsum dolor sit amet. Lorem ipsum dolor sit aamet, consetetur sadipscing\
                  elitr, sed diam nonumy aeirmod tempor invidunt ut labore et dolore magna aaliquyam erat, sed diam voluptua. At vero eos et\
                  aaccusam et justo duo dolores et ea rebum. Stet clita akasd gubergren, no sea takimata sanctus est Lorem aipsum dolor sit\
                  amet.</p></span></span></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-comment726409066" style="position: absolute; left: 15px; top: 435px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment726409066" data-review-reference-id="comment726409066">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 40px;width:200px;" width="200" height="40" viewBox="0 0 200 40">\
               <svg:g width="200" height="40" style="opacity: 0.9;">\
                  <svg:path style="fill:#FFFFCC; stroke: black; stroke-width: 0.8;" d="M 1 1 L 180 0 L 199 20 L 199 39 L 1 39 Z M 180 1 L 199 20 L 180 20 Z"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 12px; top: 3px; height: 40px;width:200px;font-size:1em;line-height:1.2em;" xml:space="preserve">Звертання автора<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-checkbox42302449" style="position: absolute; left: 730px; top: 380px; width: 225px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox42302449" data-review-reference-id="checkbox42302449">\
         <div style="font-size:1.17em;" xml:space="preserve" title="">\
            			\
            <nobr><label><input id="__containerId__-page585380472-layer-checkbox42302449input" style="padding-right:9px" type="checkbox" checked="true" />Дозволити коментувати статтю</label></nobr>\
            		\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-checkbox990487334" style="position: absolute; left: 730px; top: 405px; width: 188px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox990487334" data-review-reference-id="checkbox990487334">\
         <div style="font-size:1.17em;" xml:space="preserve" title="">\
            			\
            <nobr><label><input id="__containerId__-page585380472-layer-checkbox990487334input" style="padding-right:9px" type="checkbox" checked="true" />Дозволити зміни читачам</label></nobr>\
            		\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-iframe498176699" style="position: absolute; left: 15px; top: 300px; width: 210px; height: 100px" data-interactive-element-type="default.iframe" class="iframe stencil mobile-interaction-potential-trigger " data-stencil-id="iframe498176699" data-review-reference-id="iframe498176699">\
         <div iclass="renderEmptyPage" style="width:208px;height:98px;overflow:auto;border:1px solid black;background-color:white;">Frame without target</div>\
      </div>\
      <div id="__containerId__-page585380472-layer-text360507682" style="position: absolute; left: 15px; top: 275px; width: 90px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text360507682" data-review-reference-id="text360507682">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;">Сюжет статті</p></span></span></div>\
      </div>\
   </div>\
</div>');