rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page558643014-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page558643014" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page558643014-layer-text878174480" style="position: absolute; left: 735px; top: 15px; width: 72px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text878174480" data-review-reference-id="text878174480">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Username<br /><br /></p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-button831158747" style="position: absolute; left: 815px; top: 10px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button831158747" data-review-reference-id="button831158747">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:68px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Logout<br /></button></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-button68202122" style="position: absolute; left: 815px; top: 50px; width: 131px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button68202122" data-review-reference-id="button68202122">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:131px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Back to main page<br /></button></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text431207104" style="position: absolute; left: 20px; top: 25px; width: 141px; height: 24px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text431207104" data-review-reference-id="text431207104">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p><span style="font-size: 20px;">Some category</span></p>\
                  <p style="font-size: 14px;"><span style="font-size: 20px;"> </span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-listview301687306" style="position: absolute; left: 235px; top: 310px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview301687306" data-review-reference-id="listview301687306">\
         <div title=""><select id="__containerId__-page558643014-layer-listview301687306select" style="width:450px; height:65px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-listview311859739" style="position: absolute; left: 235px; top: 225px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview311859739" data-review-reference-id="listview311859739">\
         <div title=""><select id="__containerId__-page558643014-layer-listview311859739select" style="width:450px; height:65px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-1757430935" style="position: absolute; left: 235px; top: 135px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1757430935" data-review-reference-id="1757430935">\
         <div title=""><select id="__containerId__-page558643014-layer-1757430935select" style="width:450px; height:65px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-502087180" style="position: absolute; left: 235px; top: 400px; width: 450px; height: 65px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="502087180" data-review-reference-id="502087180">\
         <div title=""><select id="__containerId__-page558643014-layer-502087180select" style="width:450px; height:65px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">Author        Name of Tutorial         Category            Rating</option></select></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text200033302" style="position: absolute; left: 235px; top: 100px; width: 178px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text200033302" data-review-reference-id="text200033302">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>Tutorials from this category<br />\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-listview167521364" style="position: absolute; left: 15px; top: 135px; width: 150px; height: 330px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview167521364" data-review-reference-id="listview167521364">\
         <div title=""><select id="__containerId__-page558643014-layer-listview167521364select" style="width:150px; height:330px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text827134341" style="position: absolute; left: 20px; top: 100px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text827134341" data-review-reference-id="text827134341">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-414675866" style="position: absolute; left: 775px; top: 105px; width: 107px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="414675866" data-review-reference-id="414675866">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Popular authors</p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-14089559" style="position: absolute; left: 765px; top: 135px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="14089559" data-review-reference-id="14089559">\
         <div title=""><select id="__containerId__-page558643014-layer-14089559select" style="width:150px; height:140px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-text584423363" style="position: absolute; left: 775px; top: 295px; width: 91px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text584423363" data-review-reference-id="text584423363">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Latest guides</p></span></span></div>\
      </div>\
      <div id="__containerId__-page558643014-layer-654226594" style="position: absolute; left: 765px; top: 330px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="654226594" data-review-reference-id="654226594">\
         <div title=""><select id="__containerId__-page558643014-layer-654226594select" style="width:150px; height:140px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
   </div>\
</div>');