rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page747205133-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page747205133" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page747205133-layer-button743693020" style="position: absolute; left: 450px; top: 345px; width: 60px; height: 30px" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button743693020" data-review-reference-id="button743693020">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:60px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">login<br /></button></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page747205133-layer-button743693020\', \'interaction951594094\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action90189671\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction197171365\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'page120515866\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page747205133-layer-textinput692052303" style="position: absolute; left: 330px; top: 280px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput692052303" data-review-reference-id="textinput692052303">\
         <div title=""><input id="__containerId__-page747205133-layer-textinput692052303input" value="Login" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
      <div id="__containerId__-page747205133-layer-textinput814149634" style="position: absolute; left: 490px; top: 280px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput814149634" data-review-reference-id="textinput814149634">\
         <div title=""><input id="__containerId__-page747205133-layer-textinput814149634input" value="Password" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
      <div id="__containerId__-page747205133-layer-text903285278" style="position: absolute; left: 55px; top: 30px; width: 198px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text903285278" data-review-reference-id="text903285278">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Tutorials4Life</span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page747205133-layer-comment281153414" style="position: absolute; left: 325px; top: 195px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment281153414" data-review-reference-id="comment281153414">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 40px;width:200px;" width="200" height="40" viewBox="0 0 200 40">\
               <svg:g width="200" height="40" style="opacity: 0.9;">\
                  <svg:path style="fill:#FFFFCC; stroke: black; stroke-width: 0.8;" d="M 1 1 L 180 0 L 199 20 L 199 39 L 1 39 Z M 180 1 L 199 20 L 180 20 Z"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 12px; top: 3px; height: 40px;width:200px;font-size:1em;line-height:1.2em;" xml:space="preserve">Simple as it is<br /></div>\
         </div>\
      </div>\
   </div>\
</div>');