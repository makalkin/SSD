rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page942102924-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page942102924" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page942102924-layer-iphoneButton675232336" style="position: absolute; left: 895px; top: 10px; width: 54px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton675232336" data-review-reference-id="iphoneButton675232336">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:54px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="54" height="30" viewBox="0 0 54 30">\
               <svg:a>\
                  <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 44,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                  <svg:text x="27" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Вийти</svg:text>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text63815973" style="position: absolute; left: 55px; top: 225px; width: 80px; height: 18px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text63815973" data-review-reference-id="text63815973">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;">Користувач</p></span></span></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-image169066345" style="position: absolute; left: 20px; top: 40px; width: 145px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image169066345" data-review-reference-id="image169066345">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 145px;width:145px;" width="145" height="145" viewBox="0 0 145 145">\
               <svg:g width="145" height="145">\
                  <svg:rect x="0" y="0" width="145" height="145" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                  <svg:line x1="0" y1="0" x2="145" y2="145" style="stroke:black; stroke-width:0.5;"></svg:line>\
                  <svg:line x1="0" y1="145" x2="145" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-clickArea333403901" style="position: absolute; left: 180px; top: 60px; width: 525px; height: 290px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="clickArea333403901" data-review-reference-id="clickArea333403901">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 290px; width:525px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 290px;width:525px;" width="525" height="290" viewBox="0 0 525 290">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="525" height="290" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button974177568" style="position: absolute; left: 185px; top: 10px; width: 121px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button974177568" data-review-reference-id="button974177568">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:121px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Пошта<br /></button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button780440806" style="position: absolute; left: 350px; top: 10px; width: 115px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button780440806" data-review-reference-id="button780440806">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:115px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Нові відгуки<br /></button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button659945242" style="position: absolute; left: 505px; top: 10px; width: 197px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button659945242" data-review-reference-id="button659945242">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:197px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Поправки залишені читачами<br /></button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-iphoneListBackground166385015" style="position: absolute; left: 725px; top: 55px; width: 185px; height: 290px" data-interactive-element-type="static.iphoneListBackground" class="iphoneListBackground stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneListBackground166385015" data-review-reference-id="iphoneListBackground166385015">\
         <div title="" style="height: 290px; width:185px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="185" height="290" viewBox="0 0 185 290">\
               <svg:rect x="1" y="1" width="183" rx="10" height="288" style="stroke-width:1;fill:white;;stroke:black;"></svg:rect>\
               <svg:line x1="1" y1="40" x2="183" y2="40" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="80" x2="183" y2="80" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="120" x2="183" y2="120" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="160" x2="183" y2="160" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="200" x2="183" y2="200" style="stroke-width:1;stroke:black;"></svg:line>\
               <svg:line x1="1" y1="240" x2="183" y2="240" style="stroke-width:1;stroke:black;"></svg:line>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-iphoneButton94330194" style="position: absolute; left: 5px; top: 380px; width: 173px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton94330194" data-review-reference-id="iphoneButton94330194">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:173px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="173" height="30" viewBox="0 0 173 30">\
               <svg:a>\
                  <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 163,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                  <svg:text x="86.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Підписники користувача 15</svg:text>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button611283533" style="position: absolute; left: 740px; top: 10px; width: 125px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button611283533" data-review-reference-id="button611283533">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:125px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Обране<br /></button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-clickArea349640040" style="position: absolute; left: 235px; top: 395px; width: 425px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="clickArea349640040" data-review-reference-id="clickArea349640040">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:425px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:425px;" width="425" height="60" viewBox="0 0 425 60">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="425" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text181747783" style="position: absolute; left: 225px; top: 475px; width: 63px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text181747783" data-review-reference-id="text181747783">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;">Реклама</p></span></span></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text519160798" style="position: absolute; left: 375px; top: 475px; width: 160px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text519160798" data-review-reference-id="text519160798">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;">Головна сторінка сайта</p></span></span></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text298919711" style="position: absolute; left: 620px; top: 475px; width: 70px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text298919711" data-review-reference-id="text298919711">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Допомога</span></p></span></span></div>\
      </div>\
   </div>\
</div>');