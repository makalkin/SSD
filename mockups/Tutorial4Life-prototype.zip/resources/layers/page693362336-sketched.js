rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page693362336-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page693362336" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page693362336-layer-488633189" style="position: absolute; left: 735px; top: 15px; width: 72px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="488633189" data-review-reference-id="488633189">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Username<br /><br /></p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1435246561" style="position: absolute; left: 815px; top: 10px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1435246561" data-review-reference-id="1435246561">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:68px;" width="68" height="30">\
               <svg:g width="68" height="30"><svg:path d="M 2.00, 2.00 Q 12.17, 1.17, 22.33, 1.13 Q 32.50, 1.13, 42.67, 0.93 Q 52.83, 1.57, 63.27, 1.73 Q 63.56, 13.31,\
                  63.23, 25.23 Q 52.82, 24.96, 42.67, 25.03 Q 32.51, 25.27, 22.34, 25.25 Q 12.18, 25.72, 1.84, 25.16 Q 2.00, 13.50, 2.00, 2.00"\
                  style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 64.00, 4.00 Q 64.00, 16.00, 64.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 65.00, 5.00 Q 65.00, 17.00, 65.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 66.00, 6.00 Q 66.00, 18.00, 66.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.33, 24.49, 24.67, 24.41 Q 35.00, 24.31, 45.33, 24.15 Q 55.67, 26.00, 66.00, 26.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.33, 27.51, 25.67, 27.72 Q 36.00, 27.82, 46.33, 27.24 Q 56.67, 27.00, 67.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.33, 26.24, 26.67, 26.33 Q 37.00, 26.26, 47.33, 26.36 Q 57.67, 28.00, 68.00, 28.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page693362336-layer-1435246561button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page693362336-layer-1435246561button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page693362336-layer-1435246561button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:64px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Logout<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1759028085" style="position: absolute; left: 815px; top: 50px; width: 131px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1759028085" data-review-reference-id="1759028085">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:131px;" width="131" height="30">\
               <svg:g width="131" height="30"><svg:path d="M 2.00, 2.00 Q 12.33, 2.29, 22.67, 1.57 Q 33.00, 1.06, 43.33, 0.91 Q 53.67, 0.41, 64.00, 0.14 Q 74.33, 0.62,\
                  84.67, 0.48 Q 95.00, 0.41, 105.33, 0.27 Q 115.67, 0.08, 126.83, 1.17 Q 126.83, 13.22, 126.52, 25.52 Q 115.90, 25.86, 105.45,\
                  26.03 Q 95.08, 26.64, 84.70, 26.57 Q 74.35, 26.56, 64.01, 25.96 Q 53.67, 26.39, 43.34, 26.84 Q 33.00, 26.44, 22.67, 26.56\
                  Q 12.33, 26.61, 1.53, 25.47 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 127.00, 4.00 Q 127.00, 16.00, 127.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 128.00, 5.00 Q 128.00, 17.00, 128.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 129.00, 6.00 Q 129.00, 18.00, 129.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.42, 26.52, 24.83, 26.38 Q 35.25, 26.55, 45.67, 25.27 Q 56.08, 25.69, 66.50, 25.61 Q 76.92,\
                  25.03, 87.33, 24.87 Q 97.75, 25.05, 108.17, 25.20 Q 118.58, 26.00, 129.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.42, 25.23, 25.83, 25.14 Q 36.25, 25.39, 46.67, 25.51 Q 57.08, 25.49, 67.50, 25.73 Q 77.92,\
                  25.77, 88.33, 25.55 Q 98.75, 26.08, 109.17, 26.09 Q 119.58, 27.00, 130.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.42, 26.10, 26.83, 26.28 Q 37.25, 26.30, 47.67, 26.66 Q 58.08, 26.78, 68.50, 26.71 Q 78.92,\
                  27.37, 89.33, 27.44 Q 99.75, 27.66, 110.17, 27.71 Q 120.58, 28.00, 131.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page693362336-layer-1759028085button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page693362336-layer-1759028085button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page693362336-layer-1759028085button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:127px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Back to main page<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1996741608" style="position: absolute; left: 15px; top: 10px; width: 71px; height: 24px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1996741608" data-review-reference-id="1996741608">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p><span style="font-size: 20px;">Author</span></p>\
                  <p style="font-size: 14px;"><span style="font-size: 20px;"> </span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-211637790" style="position: absolute; left: 240px; top: 135px; width: 450px; height: 330px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="211637790" data-review-reference-id="211637790">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 330px;width:450px;" width="450" height="330">\
               <svg:g width="450" height="330"><svg:path id="__containerId__-page693362336-layer-211637790_input_svg_border" d="M 2.00, 2.00 Q 12.14, -0.06, 22.27, 0.43\
                  Q 32.41, 0.81, 42.55, 0.96 Q 52.68, 1.23, 62.82, 1.40 Q 72.95, 1.25, 83.09, 1.11 Q 93.23, 1.04, 103.36, 0.87 Q 113.50, 0.79,\
                  123.64, 1.16 Q 133.77, 0.85, 143.91, 0.80 Q 154.05, 0.61, 164.18, 0.51 Q 174.32, 0.43, 184.45, 0.81 Q 194.59, 0.91, 204.73,\
                  0.66 Q 214.86, 0.47, 225.00, 0.53 Q 235.14, 1.18, 245.27, 1.51 Q 255.41, 0.49, 265.55, 1.22 Q 275.68, 0.64, 285.82, 0.54 Q\
                  295.95, 0.48, 306.09, 0.33 Q 316.23, 0.11, 326.36, 0.32 Q 336.50, 0.48, 346.64, 0.76 Q 356.77, -0.04, 366.91, 0.78 Q 377.05,\
                  0.72, 387.18, 0.75 Q 397.32, 1.08, 407.45, 0.65 Q 417.59, 0.67, 427.73, 0.95 Q 437.86, 0.05, 448.85, 1.15 Q 448.97, 11.86,\
                  448.84, 22.25 Q 448.17, 32.55, 447.95, 42.75 Q 448.49, 52.93, 449.21, 63.12 Q 448.72, 73.31, 448.02, 83.50 Q 448.53, 93.69,\
                  448.84, 103.87 Q 448.64, 114.06, 448.55, 124.25 Q 449.05, 134.44, 448.38, 144.62 Q 449.31, 154.81, 449.22, 165.00 Q 449.23,\
                  175.19, 449.28, 185.38 Q 449.12, 195.56, 449.04, 205.75 Q 448.82, 215.94, 449.14, 226.12 Q 448.59, 236.31, 447.92, 246.50\
                  Q 449.29, 256.69, 449.45, 266.88 Q 448.77, 277.06, 448.34, 287.25 Q 448.03, 297.44, 447.82, 307.62 Q 448.45, 317.81, 448.14,\
                  328.14 Q 437.88, 328.06, 427.77, 328.27 Q 417.66, 329.05, 407.48, 328.87 Q 397.32, 328.10, 387.18, 328.18 Q 377.05, 328.21,\
                  366.91, 327.99 Q 356.77, 328.45, 346.64, 329.46 Q 336.50, 328.98, 326.36, 329.20 Q 316.23, 328.30, 306.09, 328.51 Q 295.95,\
                  328.55, 285.82, 328.38 Q 275.68, 328.75, 265.55, 328.11 Q 255.41, 328.10, 245.27, 327.94 Q 235.14, 328.32, 225.00, 328.79\
                  Q 214.86, 328.71, 204.73, 329.42 Q 194.59, 329.27, 184.45, 328.64 Q 174.32, 328.13, 164.18, 327.57 Q 154.05, 327.00, 143.91,\
                  328.06 Q 133.77, 328.70, 123.64, 328.62 Q 113.50, 328.70, 103.36, 328.53 Q 93.23, 328.46, 83.09, 328.35 Q 72.95, 328.92, 62.82,\
                  328.67 Q 52.68, 328.46, 42.55, 327.74 Q 32.41, 328.85, 22.27, 329.25 Q 12.14, 328.94, 1.59, 328.41 Q 1.93, 317.84, 1.24, 307.73\
                  Q 0.76, 297.52, 1.11, 287.28 Q 1.43, 277.07, 1.77, 266.88 Q 1.28, 256.69, 1.97, 246.50 Q 2.01, 236.31, 1.38, 226.13 Q 1.86,\
                  215.94, 0.67, 205.75 Q 1.56, 195.56, 1.68, 185.38 Q 2.28, 175.19, 3.73, 165.00 Q 3.99, 154.81, 1.87, 144.62 Q 0.84, 134.44,\
                  1.12, 124.25 Q 1.67, 114.06, 1.17, 103.88 Q 1.27, 93.69, 1.87, 83.50 Q 1.28, 73.31, 2.06, 63.12 Q 1.68, 52.94, 1.85, 42.75\
                  Q 1.21, 32.56, 0.37, 22.38 Q 2.00, 12.19, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page693362336-layer-211637790select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page693362336-layer-211637790_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page693362336-layer-211637790_input_svg_border\')" style="width:442px; height:322px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1165929171" style="position: absolute; left: 270px; top: 150px; width: 161px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1165929171" data-review-reference-id="1165929171">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>something about author</p>\
                  <p class="none" style="font-size: 14px;"> </p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-2011053116" style="position: absolute; left: 15px; top: 135px; width: 150px; height: 330px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2011053116" data-review-reference-id="2011053116">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 330px;width:150px;" width="150" height="330">\
               <svg:g width="150" height="330"><svg:path id="__containerId__-page693362336-layer-2011053116_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.67, 22.86, 1.57\
                  Q 33.29, 1.48, 43.71, 1.30 Q 54.14, 1.01, 64.57, 1.00 Q 75.00, 0.91, 85.43, 0.81 Q 95.86, 0.60, 106.29, 0.66 Q 116.71, 0.80,\
                  127.14, 0.68 Q 137.57, 0.55, 148.80, 1.20 Q 148.79, 11.92, 149.35, 22.18 Q 149.26, 32.48, 149.52, 42.70 Q 149.80, 52.91, 149.51,\
                  63.11 Q 148.58, 73.31, 148.75, 83.50 Q 148.69, 93.69, 149.08, 103.87 Q 149.60, 114.06, 149.57, 124.25 Q 149.63, 134.44, 149.81,\
                  144.62 Q 149.93, 154.81, 149.01, 165.00 Q 148.27, 175.19, 149.11, 185.38 Q 148.83, 195.56, 149.48, 205.75 Q 149.44, 215.94,\
                  149.66, 226.12 Q 149.41, 236.31, 149.50, 246.50 Q 148.76, 256.69, 148.40, 266.88 Q 148.16, 277.06, 147.21, 287.25 Q 147.95,\
                  297.44, 147.96, 307.62 Q 147.87, 317.81, 147.99, 327.99 Q 137.56, 327.97, 127.13, 327.91 Q 116.69, 327.68, 106.30, 328.42\
                  Q 95.86, 328.23, 85.44, 328.83 Q 75.00, 328.86, 64.57, 329.08 Q 54.14, 329.00, 43.71, 329.45 Q 33.29, 329.65, 22.86, 329.77\
                  Q 12.43, 328.69, 2.38, 327.62 Q 2.45, 317.66, 2.84, 307.50 Q 1.96, 297.44, 1.58, 287.26 Q 1.56, 277.07, 1.96, 266.88 Q 2.66,\
                  256.68, 1.96, 246.50 Q 1.74, 236.31, 2.06, 226.12 Q 2.02, 215.94, 1.00, 205.75 Q 1.06, 195.56, 1.19, 185.38 Q 1.36, 175.19,\
                  0.98, 165.00 Q 1.39, 154.81, 2.09, 144.62 Q 1.48, 134.44, 1.99, 124.25 Q 1.79, 114.06, 2.38, 103.88 Q 1.98, 93.69, 3.62, 83.50\
                  Q 3.32, 73.31, 2.44, 63.12 Q 2.02, 52.94, 2.25, 42.75 Q 2.70, 32.56, 2.46, 22.38 Q 2.00, 12.19, 2.00, 2.00" style=" fill:white;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page693362336-layer-2011053116select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page693362336-layer-2011053116_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page693362336-layer-2011053116_input_svg_border\')" style="width:142px; height:322px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page693362336-layer-89624771" style="position: absolute; left: 20px; top: 100px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="89624771" data-review-reference-id="89624771">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1686848533" style="position: absolute; left: 775px; top: 105px; width: 107px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1686848533" data-review-reference-id="1686848533">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Popular authors</p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-315426403" style="position: absolute; left: 765px; top: 135px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="315426403" data-review-reference-id="315426403">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 140px;width:150px;" width="150" height="140">\
               <svg:g width="150" height="140"><svg:path id="__containerId__-page693362336-layer-315426403_input_svg_border" d="M 2.00, 2.00 Q 12.43, 0.61, 22.86, 0.67 Q\
                  33.29, 0.52, 43.71, 0.50 Q 54.14, 0.52, 64.57, 0.66 Q 75.00, 0.59, 85.43, 0.46 Q 95.86, 0.40, 106.29, 0.54 Q 116.71, 1.11,\
                  127.14, 0.95 Q 137.57, 1.18, 148.31, 1.69 Q 148.52, 13.16, 149.22, 24.49 Q 149.37, 35.91, 149.54, 47.28 Q 149.58, 58.64, 149.37,\
                  69.99 Q 148.18, 81.33, 148.01, 92.67 Q 148.11, 104.00, 148.34, 115.33 Q 148.21, 126.67, 147.73, 137.73 Q 137.69, 138.36, 127.10,\
                  137.73 Q 116.74, 138.45, 106.28, 137.93 Q 95.86, 138.24, 85.43, 138.57 Q 75.00, 139.16, 64.57, 138.72 Q 54.14, 139.22, 43.71,\
                  138.55 Q 33.29, 138.87, 22.86, 139.16 Q 12.43, 139.06, 1.52, 138.48 Q 1.77, 126.74, 2.66, 115.24 Q 1.75, 104.02, 2.68, 92.64\
                  Q 1.23, 81.35, 2.04, 70.00 Q 1.32, 58.67, 1.57, 47.33 Q 1.69, 36.00, 2.00, 24.67 Q 2.00, 13.33, 2.00, 2.00" style=" fill:white;"\
                  class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page693362336-layer-315426403select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page693362336-layer-315426403_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page693362336-layer-315426403_input_svg_border\')" style="width:142px; height:132px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page693362336-layer-733764211" style="position: absolute; left: 775px; top: 295px; width: 109px; height: 18px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="733764211" data-review-reference-id="733764211">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Authors tutorials</p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-2011923044" style="position: absolute; left: 765px; top: 330px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2011923044" data-review-reference-id="2011923044">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 140px;width:150px;" width="150" height="140">\
               <svg:g width="150" height="140"><svg:path id="__containerId__-page693362336-layer-2011923044_input_svg_border" d="M 2.00, 2.00 Q 12.43, 0.13, 22.86, 0.03\
                  Q 33.29, -0.06, 43.71, -0.24 Q 54.14, 0.24, 64.57, 0.36 Q 75.00, 0.06, 85.43, -0.24 Q 95.86, -0.25, 106.29, 0.34 Q 116.71,\
                  0.56, 127.14, 0.43 Q 137.57, 0.48, 148.71, 1.29 Q 148.91, 13.03, 149.84, 24.40 Q 149.24, 35.92, 150.05, 47.27 Q 149.86, 58.64,\
                  149.16, 69.99 Q 148.50, 81.33, 148.61, 92.67 Q 148.75, 104.00, 148.94, 115.33 Q 149.08, 126.67, 148.51, 138.51 Q 137.88, 138.92,\
                  127.25, 138.78 Q 116.74, 138.39, 106.30, 138.56 Q 95.87, 138.72, 85.44, 139.52 Q 75.01, 139.42, 64.57, 138.50 Q 54.14, 138.91,\
                  43.72, 139.54 Q 33.29, 139.50, 22.86, 139.71 Q 12.43, 139.79, 1.11, 138.89 Q 1.31, 126.90, 1.31, 115.43 Q 0.91, 104.07, 0.63,\
                  92.71 Q 0.64, 81.35, 0.40, 70.01 Q 0.39, 58.67, 0.30, 47.34 Q 0.27, 36.00, 0.21, 24.67 Q 2.00, 13.33, 2.00, 2.00" style="\
                  fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page693362336-layer-2011923044select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page693362336-layer-2011923044_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page693362336-layer-2011923044_input_svg_border\')" style="width:142px; height:132px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page693362336-layer-image592200965" style="position: absolute; left: 90px; top: 10px; width: 80px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image592200965" data-review-reference-id="image592200965">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 70px;width:80px;" width="80" height="70">\
               <svg:g width="80" height="70"><svg:path id="id" d="M 2.00, 2.00 Q 14.67, 1.49, 27.33, 0.71 Q 40.00, 0.07, 52.67, -0.27 Q 65.33, 0.53, 79.06, 0.94 Q 78.73,\
                  12.76, 79.74, 23.75 Q 80.03, 34.86, 78.98, 45.97 Q 79.13, 56.98, 78.77, 68.77 Q 65.60, 68.81, 52.67, 68.02 Q 40.01, 68.15,\
                  27.38, 69.37 Q 14.70, 70.22, 1.12, 68.88 Q 1.42, 57.19, 1.74, 46.04 Q 1.67, 35.02, 1.87, 24.00 Q 2.00, 13.00, 2.00, 2.00"\
                  style="fill:white;stroke-width:1.5;" class="svg_unselected_element"/><svg:path d="M 2.00, 2.00 Q 10.17, 7.94, 17.46, 14.90 Q 25.27, 21.26, 32.36, 28.44 Q 40.51, 34.41, 48.22, 40.89 Q 55.63, 47.71,\
                  62.65, 54.98 Q 70.40, 61.40, 78.00, 68.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 2.00, 68.00 Q 9.03, 60.49, 16.72, 53.76 Q 24.33, 46.94, 32.07, 40.27 Q 39.69, 33.46, 47.33, 26.66 Q 55.43,\
                  20.42, 63.15, 13.72 Q 72.20, 8.60, 80.00, 2.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
   </div>\
</div>');