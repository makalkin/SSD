rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page450165395-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page450165395" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page450165395-layer-text956347032" style="position: absolute; left: 755px; top: 10px; width: 76px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text956347032" data-review-reference-id="text956347032">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>Username\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-button852994665" style="position: absolute; left: 825px; top: 10px; width: 67px; height: 25px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button852994665" data-review-reference-id="button852994665">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:67px;height:25px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">log out<br /></button></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-button191508125" style="position: absolute; left: 825px; top: 45px; width: 126px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button191508125" data-review-reference-id="button191508125">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:126px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Make new tutorial<br /></button></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-listview670951094" style="position: absolute; left: 15px; top: 120px; width: 150px; height: 360px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview670951094" data-review-reference-id="listview670951094">\
         <div title=""><select id="__containerId__-page450165395-layer-listview670951094select" style="width:150px; height:360px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text54270945" style="position: absolute; left: 20px; top: 80px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text54270945" data-review-reference-id="text54270945">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-textinput156794697" style="position: absolute; left: 195px; top: 145px; width: 515px; height: 80px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput156794697" data-review-reference-id="textinput156794697">\
         <div title=""><textarea id="__containerId__-page450165395-layer-textinput156794697input" rows="" cols="" style="width:513px;height:76px;padding: 0px;border-width:1px;">Author             Name of Tutorial       Category     Rating      </textarea></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-1246753648" style="position: absolute; left: 195px; top: 250px; width: 515px; height: 80px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1246753648" data-review-reference-id="1246753648">\
         <div title=""><textarea id="__containerId__-page450165395-layer-1246753648input" rows="" cols="" style="width:513px;height:76px;padding: 0px;border-width:1px;">Author             Name of Tutorial       Category     Rating      </textarea></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-1252734470" style="position: absolute; left: 195px; top: 355px; width: 515px; height: 80px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1252734470" data-review-reference-id="1252734470">\
         <div title=""><textarea id="__containerId__-page450165395-layer-1252734470input" rows="" cols="" style="width:513px;height:76px;padding: 0px;border-width:1px;">Author             Name of Tutorial       Category     Rating      </textarea></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text855970511" style="position: absolute; left: 195px; top: 105px; width: 109px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text855970511" data-review-reference-id="text855970511">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;">Popular tutorials </p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text768123400" style="position: absolute; left: 805px; top: 105px; width: 107px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text768123400" data-review-reference-id="text768123400">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Popular authors</p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-listview852930950" style="position: absolute; left: 775px; top: 140px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview852930950" data-review-reference-id="listview852930950">\
         <div title=""><select id="__containerId__-page450165395-layer-listview852930950select" style="width:150px; height:140px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text967979" style="position: absolute; left: 805px; top: 300px; width: 91px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text967979" data-review-reference-id="text967979">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Latest guides</p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-listview564704621" style="position: absolute; left: 775px; top: 325px; width: 150px; height: 105px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview564704621" data-review-reference-id="listview564704621">\
         <div title=""><select id="__containerId__-page450165395-layer-listview564704621select" style="width:150px; height:105px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-comment173302838" style="position: absolute; left: 575px; top: 40px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment173302838" data-review-reference-id="comment173302838">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 40px;width:200px;" width="200" height="40" viewBox="0 0 200 40">\
               <svg:g width="200" height="40" style="opacity: 0.9;">\
                  <svg:path style="fill:#FFFFCC; stroke: black; stroke-width: 0.8;" d="M 1 1 L 180 0 L 199 20 L 199 39 L 1 39 Z M 180 1 L 199 20 L 180 20 Z"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 12px; top: 3px; height: 40px;width:200px;font-size:1em;line-height:1.2em;" xml:space="preserve">Username leads to profile page<br /></div>\
         </div>\
      </div>\
   </div>\
</div>');