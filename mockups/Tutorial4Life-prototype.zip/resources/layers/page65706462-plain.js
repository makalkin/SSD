rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page65706462-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page65706462" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page65706462-layer-331903705" style="position: absolute; left: 795px; top: 45px; width: 57px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="331903705" data-review-reference-id="331903705">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Admin<br /></span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page65706462-layer-593071587" style="position: absolute; left: 55px; top: 30px; width: 198px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="593071587" data-review-reference-id="593071587">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Tutorials4Life</span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page65706462-layer-listview106094482" style="position: absolute; left: 60px; top: 100px; width: 880px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview106094482" data-review-reference-id="listview106094482">\
         <div title=""><select id="__containerId__-page65706462-layer-listview106094482select" style="width:880px; height:140px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener></select></div>\
      </div>\
      <div id="__containerId__-page65706462-layer-table570388746" style="position: absolute; left: 60px; top: 100px; width: 866px; height: 144px" data-interactive-element-type="default.table" class="table pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="table570388746" data-review-reference-id="table570388746">\
         <div title=""><table width=\'856.0\' height=\'144.0\' cellspacing=\'0\' class=\'tableStyle\'><tr style=\'height: 36px\'><td style=\'width:49px;\' class=\'tableCells\'><span\
            style=\'\'>ID</span><br /></td><td style=\'width:311px;\' class=\'tableCells\'><span style=\'\'>Name</span><br /></td><td style=\'width:117px;\'\
            class=\'tableCells\'><span style=\'\'>Ordering</span><br /></td><td style=\'width:269px;\' class=\'tableCells\'><span style=\'\'>Other orderings...(date)|</span><br\
            /></td></tr><tr style=\'height: 36px\'><td style=\'width:49px;\' class=\'tableCells\'><span style=\'\'>3</span><br /></td><td style=\'width:311px;\'\
            class=\'tableCells\'><span style=\'\'>How to eat fugu</span><br /></td><td style=\'width:117px;\' class=\'tableCells\'><span style=\'\'>1</span><br\
            /></td><td style=\'width:269px;\' class=\'tableCells\'><span style=\'\'>21.01.15|</span><br /></td></tr><tr style=\'height: 36px\'><td\
            style=\'width:49px;\' class=\'tableCells\'><span style=\'\'>1</span><br /></td><td style=\'width:311px;\' class=\'tableCells\'><span\
            style=\'\'>Making a snowman</span><br /></td><td style=\'width:117px;\' class=\'tableCells\'><span style=\'\'>2</span><br /></td><td\
            style=\'width:269px;\' class=\'tableCells\'><span style=\'\'>23.01.13</span><br /></td></tr><tr style=\'height: 36px\'><td style=\'width:49px;\'\
            class=\'tableCells\'><span style=\'\'>2</span><br /></td><td style=\'width:311px;\' class=\'tableCells\'><span style=\'\'>Feasting upon human souls</span><br\
            /></td><td style=\'width:117px;\' class=\'tableCells\'><span style=\'\'>3</span><br /></td><td style=\'width:269px;\' class=\'tableCells\'><span\
            style=\'\'>01.01.01</span><br /></td></tr></table>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page65706462-layer-table570388746\', \'interaction57752118\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action103890187\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction5392219\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page338958609\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page65706462-layer-text566790746" style="position: absolute; left: 145px; top: 70px; width: 75px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text566790746" data-review-reference-id="text566790746">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Tutorials</span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page65706462-layer-1066435984" style="position: absolute; left: 870px; top: 35px; width: 64px; height: 30px" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1066435984" data-review-reference-id="1066435984">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:64px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">logout<br /></button></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page65706462-layer-1066435984\', \'1641389581\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'81425165\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'770525770\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page747205133\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page65706462-layer-text838640801" style="position: absolute; left: 60px; top: 70px; width: 59px; height: 21px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text838640801" data-review-reference-id="text838640801">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Home </p></span></span></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page65706462-layer-text838640801\', \'interaction546999241\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action445716392\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction287880006\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page120515866\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page65706462-layer-icon915798319" style="position: absolute; left: 110px; top: 65px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon915798319" data-review-reference-id="icon915798319">\
         <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">\
               <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e212"></use>\
            </svg>\
         </div>\
      </div>\
   </div>\
</div>');