rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page120515866-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page120515866" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page120515866-layer-text431978013" style="position: absolute; left: 55px; top: 115px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text431978013" data-review-reference-id="text431978013">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Categories<br /></span></p></span></span></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-text431978013\', \'interaction420288059\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action557512670\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction50578135\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page65706462\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page120515866-layer-1553122038" style="position: absolute; left: 55px; top: 140px; width: 61px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1553122038" data-review-reference-id="1553122038">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Tutorials</span></p></span></span></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-1553122038\', \'interaction46720627\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action557512670\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction50578135\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page65706462\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page120515866-layer-1905495757" style="position: absolute; left: 55px; top: 165px; width: 43px; height: 32px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1905495757" data-review-reference-id="1905495757">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Users<br /><br /></span></p></span></span></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-1905495757\', \'interaction503415199\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action557512670\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction50578135\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page65706462\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page120515866-layer-comment710961335" style="position: absolute; left: 260px; top: 150px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment710961335" data-review-reference-id="comment710961335">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 40px;width:200px;" width="200" height="40" viewBox="0 0 200 40">\
               <svg:g width="200" height="40" style="opacity: 0.9;">\
                  <svg:path style="fill:#FFFFCC; stroke: black; stroke-width: 0.8;" d="M 1 1 L 180 0 L 199 20 L 199 39 L 1 39 Z M 180 1 L 199 20 L 180 20 Z"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 12px; top: 3px; height: 40px;width:200px;font-size:1em;line-height:1.2em;" xml:space="preserve">Each link opens list of selected <br />objects.<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page120515866-layer-text993419917" style="position: absolute; left: 795px; top: 45px; width: 57px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text993419917" data-review-reference-id="text993419917">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Admin<br /></span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page120515866-layer-1351938763" style="position: absolute; left: 55px; top: 30px; width: 198px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1351938763" data-review-reference-id="1351938763">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Tutorials4Life</span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page120515866-layer-928104831" style="position: absolute; left: 870px; top: 40px; width: 64px; height: 30px" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="928104831" data-review-reference-id="928104831">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:64px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">logout<br /></button></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-928104831\', \'1592489561\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'1795252231\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'1659251157\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page747205133\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');