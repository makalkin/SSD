rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page450165395-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page450165395" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page450165395-layer-text956347032" style="position: absolute; left: 755px; top: 10px; width: 76px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text956347032" data-review-reference-id="text956347032">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>Username\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-button852994665" style="position: absolute; left: 825px; top: 10px; width: 67px; height: 25px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button852994665" data-review-reference-id="button852994665">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 25px;width:67px;" width="67" height="25">\
               <svg:g width="67" height="25"><svg:path d="M 2.00, 2.00 Q 12.00, -0.46, 22.00, -0.45 Q 32.00, -0.19, 42.00, -0.21 Q 52.00, 0.14, 62.93, 1.07 Q 63.43, 10.52,\
                  62.45, 20.45 Q 52.19, 20.70, 42.10, 20.89 Q 32.04, 20.83, 22.02, 20.98 Q 12.02, 21.26, 1.33, 20.67 Q 2.00, 11.00, 2.00, 2.00"\
                  style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 63.00, 4.00 Q 63.00, 13.50, 63.00, 23.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 64.00, 5.00 Q 64.00, 14.50, 64.00, 24.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 65.00, 6.00 Q 65.00, 15.50, 65.00, 25.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 21.00 Q 14.17, 20.54, 24.33, 20.40 Q 34.50, 20.56, 44.67, 20.40 Q 54.83, 21.00, 65.00, 21.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 22.00 Q 15.17, 22.16, 25.33, 21.14 Q 35.50, 20.52, 45.67, 20.16 Q 55.83, 22.00, 66.00, 22.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 23.00 Q 16.17, 22.65, 26.33, 22.58 Q 36.50, 22.59, 46.67, 22.32 Q 56.83, 23.00, 67.00, 23.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page450165395-layer-button852994665button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page450165395-layer-button852994665button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page450165395-layer-button852994665button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:63px;height:21px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				log out<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-button191508125" style="position: absolute; left: 825px; top: 45px; width: 126px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button191508125" data-review-reference-id="button191508125">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:126px;" width="126" height="30">\
               <svg:g width="126" height="30"><svg:path d="M 2.00, 2.00 Q 13.90, 1.20, 25.80, 1.12 Q 37.70, 1.04, 49.60, 0.73 Q 61.50, 0.53, 73.40, 0.58 Q 85.30, 0.50,\
                  97.20, 0.26 Q 109.10, 0.52, 121.84, 1.16 Q 122.24, 13.09, 121.64, 25.64 Q 109.44, 26.26, 97.34, 26.29 Q 85.38, 26.53, 73.44,\
                  26.78 Q 61.52, 26.78, 49.61, 26.46 Q 37.70, 26.64, 25.80, 26.27 Q 13.90, 26.32, 1.44, 25.56 Q 2.00, 13.50, 2.00, 2.00" style="\
                  fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 122.00, 4.00 Q 122.00, 16.00, 122.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 123.00, 5.00 Q 123.00, 17.00, 123.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 124.00, 6.00 Q 124.00, 18.00, 124.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.00, 23.57, 24.00, 24.10 Q 34.00, 24.31, 44.00, 24.96 Q 54.00, 23.71, 64.00, 24.81 Q 74.00,\
                  25.31, 84.00, 25.73 Q 94.00, 24.77, 104.00, 24.29 Q 114.00, 26.00, 124.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.00, 27.63, 25.00, 28.32 Q 35.00, 27.75, 45.00, 28.25 Q 55.00, 27.61, 65.00, 26.52 Q 75.00,\
                  26.51, 85.00, 27.30 Q 95.00, 27.03, 105.00, 26.41 Q 115.00, 27.00, 125.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.00, 27.39, 26.00, 28.14 Q 36.00, 29.16, 46.00, 29.24 Q 56.00, 27.00, 66.00, 29.66 Q 76.00,\
                  29.76, 86.00, 29.33 Q 96.00, 27.16, 106.00, 26.00 Q 116.00, 28.00, 126.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page450165395-layer-button191508125button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page450165395-layer-button191508125button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page450165395-layer-button191508125button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:122px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Make new tutorial<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-listview670951094" style="position: absolute; left: 15px; top: 120px; width: 150px; height: 360px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview670951094" data-review-reference-id="listview670951094">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 360px;width:150px;" width="150" height="360">\
               <svg:g width="150" height="360"><svg:path id="__containerId__-page450165395-layer-listview670951094_input_svg_border" d="M 2.00, 2.00 Q 12.43, 0.34, 22.86,\
                  0.38 Q 33.29, 0.63, 43.71, 0.79 Q 54.14, 0.67, 64.57, 1.07 Q 75.00, 1.50, 85.43, 1.17 Q 95.86, 0.76, 106.29, 0.80 Q 116.71,\
                  1.66, 127.14, 1.81 Q 137.57, 1.54, 147.96, 2.04 Q 148.02, 12.46, 148.64, 22.85 Q 148.02, 33.41, 149.08, 43.85 Q 148.48, 54.35,\
                  149.04, 64.82 Q 148.67, 75.29, 148.67, 85.76 Q 148.16, 96.24, 148.17, 106.71 Q 148.11, 117.18, 148.74, 127.65 Q 148.54, 138.12,\
                  148.06, 148.59 Q 147.61, 159.06, 148.10, 169.53 Q 148.50, 180.00, 148.69, 190.47 Q 147.95, 200.94, 147.76, 211.41 Q 147.87,\
                  221.88, 149.78, 232.35 Q 148.73, 242.82, 148.77, 253.29 Q 148.92, 263.76, 149.16, 274.24 Q 148.77, 284.71, 148.48, 295.18\
                  Q 149.24, 305.65, 148.54, 316.12 Q 149.29, 326.59, 148.08, 337.06 Q 148.05, 347.53, 147.98, 357.98 Q 137.61, 358.12, 127.16,\
                  358.09 Q 116.74, 358.35, 106.32, 359.12 Q 95.86, 357.95, 85.44, 358.90 Q 75.00, 358.52, 64.57, 359.19 Q 54.14, 359.02, 43.71,\
                  358.51 Q 33.29, 359.03, 22.86, 359.24 Q 12.43, 359.30, 2.07, 357.93 Q 1.28, 347.77, 1.67, 337.11 Q 1.09, 326.65, 1.50, 316.13\
                  Q 1.47, 305.66, 1.53, 295.18 Q 1.92, 284.71, 2.45, 274.23 Q 1.46, 263.77, 0.16, 253.29 Q 0.88, 242.82, 0.94, 232.35 Q 0.67,\
                  221.88, 0.31, 211.41 Q 0.43, 200.94, 0.73, 190.47 Q 1.29, 180.00, 1.46, 169.53 Q 1.09, 159.06, 1.96, 148.59 Q 1.81, 138.12,\
                  2.28, 127.65 Q 1.82, 117.18, 1.41, 106.71 Q 0.91, 96.24, 1.84, 85.76 Q 0.84, 75.29, 1.07, 64.82 Q 2.79, 54.35, 2.32, 43.88\
                  Q 2.21, 33.41, 1.96, 22.94 Q 2.00, 12.47, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page450165395-layer-listview670951094select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page450165395-layer-listview670951094_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page450165395-layer-listview670951094_input_svg_border\')" style="width:142px; height:352px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text54270945" style="position: absolute; left: 20px; top: 80px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text54270945" data-review-reference-id="text54270945">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-textinput156794697" style="position: absolute; left: 195px; top: 145px; width: 515px; height: 80px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput156794697" data-review-reference-id="textinput156794697">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:515px;" width="515" height="80">\
               <svg:g id="__containerId__-page450165395-layer-textinput156794697svg" width="515" height="80"><svg:path id="__containerId__-page450165395-layer-textinput156794697_input_svg_border" d="M 2.00, 2.00 Q 12.22, 1.70, 22.44,\
                  1.05 Q 32.66, -0.11, 42.88, 0.86 Q 53.10, 0.93, 63.32, 0.07 Q 73.54, 0.50, 83.76, 1.78 Q 93.98, 2.32, 104.20, 1.70 Q 114.42,\
                  2.46, 124.64, 0.93 Q 134.86, 0.64, 145.08, 0.56 Q 155.30, 0.92, 165.52, 0.73 Q 175.74, 0.53, 185.96, 0.71 Q 196.18, 0.99,\
                  206.40, 1.36 Q 216.62, 1.37, 226.84, 2.46 Q 237.06, 1.30, 247.28, 0.63 Q 257.50, 0.86, 267.72, 0.75 Q 277.94, 0.92, 288.16,\
                  0.63 Q 298.38, 1.18, 308.60, 0.84 Q 318.82, 1.33, 329.04, 0.33 Q 339.26, -0.14, 349.48, -0.28 Q 359.70, -0.43, 369.92, -0.40\
                  Q 380.14, 0.39, 390.36, 0.25 Q 400.58, -0.29, 410.80, 0.88 Q 421.02, 0.79, 431.24, 0.81 Q 441.46, 0.95, 451.68, 2.00 Q 461.90,\
                  2.27, 472.12, 1.38 Q 482.34, 0.59, 492.56, 0.84 Q 502.78, 1.82, 513.18, 1.82 Q 513.39, 14.54, 514.00, 27.19 Q 513.70, 39.95,\
                  513.82, 52.64 Q 514.06, 65.32, 513.62, 78.62 Q 502.91, 78.40, 492.56, 77.99 Q 482.35, 78.17, 472.14, 78.60 Q 461.91, 78.60,\
                  451.68, 77.78 Q 441.46, 77.95, 431.24, 79.15 Q 421.02, 79.73, 410.80, 79.84 Q 400.58, 79.70, 390.36, 80.41 Q 380.14, 80.35,\
                  369.92, 80.58 Q 359.70, 80.27, 349.48, 79.87 Q 339.26, 79.61, 329.04, 79.00 Q 318.82, 78.46, 308.60, 79.20 Q 298.38, 79.81,\
                  288.16, 79.35 Q 277.94, 79.59, 267.72, 78.09 Q 257.50, 77.56, 247.28, 78.09 Q 237.06, 78.05, 226.84, 78.22 Q 216.62, 79.19,\
                  206.40, 79.28 Q 196.18, 79.04, 185.96, 79.41 Q 175.74, 79.04, 165.52, 78.70 Q 155.30, 78.52, 145.08, 78.68 Q 134.86, 78.76,\
                  124.64, 79.10 Q 114.42, 79.30, 104.20, 79.65 Q 93.98, 79.26, 83.76, 79.03 Q 73.54, 78.82, 63.32, 78.66 Q 53.10, 78.34, 42.88,\
                  78.51 Q 32.66, 79.86, 22.44, 79.86 Q 12.22, 79.42, 1.36, 78.64 Q 1.15, 65.62, 1.43, 52.75 Q 0.98, 40.07, 0.77, 27.37 Q 2.00,\
                  14.67, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-textinput156794697_line1" d="M 3.00, 3.00 Q 13.18, 0.26, 23.36, 0.78 Q 33.54,\
                  1.09, 43.72, 1.58 Q 53.90, 1.73, 64.08, 2.51 Q 74.26, 3.27, 84.44, 2.20 Q 94.62, 2.13, 104.80, 2.74 Q 114.98, 2.70, 125.16,\
                  3.43 Q 135.34, 2.98, 145.52, 3.49 Q 155.70, 2.55, 165.88, 1.60 Q 176.06, 1.00, 186.24, 2.00 Q 196.42, 3.39, 206.60, 3.49 Q\
                  216.78, 3.29, 226.96, 2.81 Q 237.14, 3.16, 247.32, 3.25 Q 257.50, 2.93, 267.68, 3.46 Q 277.86, 3.19, 288.04, 3.52 Q 298.22,\
                  2.65, 308.40, 1.54 Q 318.58, 0.95, 328.76, 0.73 Q 338.94, 0.52, 349.12, 0.85 Q 359.30, 0.85, 369.48, 1.59 Q 379.66, 2.63,\
                  389.84, 2.25 Q 400.02, 2.45, 410.20, 2.30 Q 420.38, 2.45, 430.56, 2.52 Q 440.74, 2.63, 450.92, 2.45 Q 461.10, 2.30, 471.28,\
                  2.15 Q 481.46, 1.80, 491.64, 1.66 Q 501.82, 3.00, 512.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-textinput156794697_line2" d="M 3.00, 3.00 Q 2.98, 15.33, 2.76, 27.67 Q 1.95,\
                  40.00, 2.47, 52.33 Q 3.00, 64.67, 3.00, 77.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-textinput156794697_line3" d="M 3.00, 3.00 Q 13.18, 1.61, 23.36, 1.51 Q 33.54,\
                  1.42, 43.72, 1.84 Q 53.90, 1.54, 64.08, 1.54 Q 74.26, 1.96, 84.44, 2.21 Q 94.62, 1.85, 104.80, 1.52 Q 114.98, 1.85, 125.16,\
                  2.09 Q 135.34, 2.18, 145.52, 2.42 Q 155.70, 2.61, 165.88, 2.78 Q 176.06, 3.19, 186.24, 2.26 Q 196.42, 2.42, 206.60, 1.70 Q\
                  216.78, 2.28, 226.96, 2.66 Q 237.14, 2.01, 247.32, 3.11 Q 257.50, 2.20, 267.68, 2.46 Q 277.86, 2.45, 288.04, 2.31 Q 298.22,\
                  2.02, 308.40, 2.33 Q 318.58, 2.40, 328.76, 2.48 Q 338.94, 2.74, 349.12, 2.89 Q 359.30, 2.86, 369.48, 1.50 Q 379.66, 1.65,\
                  389.84, 1.80 Q 400.02, 0.87, 410.20, 1.45 Q 420.38, 1.49, 430.56, 2.40 Q 440.74, 2.32, 450.92, 2.51 Q 461.10, 1.63, 471.28,\
                  1.69 Q 481.46, 1.95, 491.64, 3.51 Q 501.82, 3.00, 512.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-textinput156794697_line4" d="M 3.00, 3.00 Q 5.56, 15.33, 5.60, 27.67 Q 5.26,\
                  40.00, 5.35, 52.33 Q 3.00, 64.67, 3.00, 77.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page450165395-layer-textinput156794697input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page450165395-layer-textinput156794697_input_svg_border\',\'__containerId__-page450165395-layer-textinput156794697_line1\',\'__containerId__-page450165395-layer-textinput156794697_line2\',\'__containerId__-page450165395-layer-textinput156794697_line3\',\'__containerId__-page450165395-layer-textinput156794697_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page450165395-layer-textinput156794697_input_svg_border\',\'__containerId__-page450165395-layer-textinput156794697_line1\',\'__containerId__-page450165395-layer-textinput156794697_line2\',\'__containerId__-page450165395-layer-textinput156794697_line3\',\'__containerId__-page450165395-layer-textinput156794697_line4\'))" rows="" cols="" style="width:508px;height:74px;">Author             Name of Tutorial       Category     Rating      </textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page450165395-layer-1246753648" style="position: absolute; left: 195px; top: 250px; width: 515px; height: 80px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1246753648" data-review-reference-id="1246753648">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:515px;" width="515" height="80">\
               <svg:g id="__containerId__-page450165395-layer-1246753648svg" width="515" height="80"><svg:path id="__containerId__-page450165395-layer-1246753648_input_svg_border" d="M 2.00, 2.00 Q 12.22, 2.97, 22.44, 1.54\
                  Q 32.66, 0.60, 42.88, 0.22 Q 53.10, 1.12, 63.32, 0.36 Q 73.54, 0.72, 83.76, 0.40 Q 93.98, 1.78, 104.20, 1.80 Q 114.42, 1.33,\
                  124.64, 0.75 Q 134.86, 0.85, 145.08, 1.22 Q 155.30, 0.74, 165.52, 0.65 Q 175.74, 0.87, 185.96, 1.75 Q 196.18, 1.30, 206.40,\
                  1.02 Q 216.62, 0.36, 226.84, 0.08 Q 237.06, 0.03, 247.28, -0.02 Q 257.50, -0.08, 267.72, 0.13 Q 277.94, 0.05, 288.16, 0.02\
                  Q 298.38, -0.09, 308.60, -0.17 Q 318.82, 0.30, 329.04, 0.76 Q 339.26, 0.87, 349.48, 0.55 Q 359.70, 0.91, 369.92, 1.64 Q 380.14,\
                  1.02, 390.36, 0.93 Q 400.58, 0.75, 410.80, 1.00 Q 421.02, 0.90, 431.24, 0.75 Q 441.46, 0.73, 451.68, 0.58 Q 461.90, 0.56,\
                  472.12, 0.40 Q 482.34, 0.32, 492.56, 0.52 Q 502.78, 0.41, 513.63, 1.37 Q 513.74, 14.42, 513.64, 27.24 Q 513.77, 39.95, 513.76,\
                  52.64 Q 514.32, 65.31, 513.55, 78.55 Q 503.26, 79.46, 492.71, 79.07 Q 482.41, 79.14, 472.15, 78.82 Q 461.91, 78.85, 451.69,\
                  78.66 Q 441.46, 77.61, 431.24, 78.06 Q 421.02, 77.93, 410.80, 77.97 Q 400.58, 78.12, 390.36, 78.21 Q 380.14, 78.62, 369.92,\
                  78.44 Q 359.70, 78.54, 349.48, 78.10 Q 339.26, 78.62, 329.04, 78.25 Q 318.82, 78.22, 308.60, 78.08 Q 298.38, 78.62, 288.16,\
                  79.15 Q 277.94, 78.00, 267.72, 78.32 Q 257.50, 78.30, 247.28, 78.55 Q 237.06, 78.63, 226.84, 78.72 Q 216.62, 78.88, 206.40,\
                  78.77 Q 196.18, 79.52, 185.96, 79.25 Q 175.74, 79.22, 165.52, 79.24 Q 155.30, 79.14, 145.08, 79.09 Q 134.86, 80.08, 124.64,\
                  79.96 Q 114.42, 78.85, 104.20, 79.66 Q 93.98, 79.11, 83.76, 79.61 Q 73.54, 78.92, 63.32, 79.29 Q 53.10, 79.34, 42.88, 78.89\
                  Q 32.66, 77.58, 22.44, 77.57 Q 12.22, 77.87, 1.93, 78.07 Q 1.77, 65.41, 1.62, 52.72 Q 0.78, 40.08, 0.73, 27.37 Q 2.00, 14.67,\
                  2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1246753648_line1" d="M 3.00, 3.00 Q 13.18, 3.18, 23.36, 3.38 Q 33.54, 3.71,\
                  43.72, 3.59 Q 53.90, 2.75, 64.08, 3.16 Q 74.26, 2.31, 84.44, 3.17 Q 94.62, 1.87, 104.80, 2.87 Q 114.98, 3.45, 125.16, 3.72\
                  Q 135.34, 2.32, 145.52, 1.65 Q 155.70, 2.50, 165.88, 2.73 Q 176.06, 2.81, 186.24, 1.45 Q 196.42, 2.86, 206.60, 3.78 Q 216.78,\
                  3.86, 226.96, 3.62 Q 237.14, 2.19, 247.32, 2.70 Q 257.50, 1.71, 267.68, 1.63 Q 277.86, 1.19, 288.04, 1.86 Q 298.22, 1.64,\
                  308.40, 2.16 Q 318.58, 1.82, 328.76, 1.38 Q 338.94, 1.60, 349.12, 1.98 Q 359.30, 1.20, 369.48, 1.20 Q 379.66, 2.53, 389.84,\
                  3.75 Q 400.02, 4.10, 410.20, 4.19 Q 420.38, 3.35, 430.56, 3.61 Q 440.74, 3.05, 450.92, 3.89 Q 461.10, 2.93, 471.28, 2.28 Q\
                  481.46, 2.54, 491.64, 2.90 Q 501.82, 3.00, 512.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1246753648_line2" d="M 3.00, 3.00 Q 3.48, 15.33, 3.47, 27.67 Q 3.12, 40.00,\
                  2.92, 52.33 Q 3.00, 64.67, 3.00, 77.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1246753648_line3" d="M 3.00, 3.00 Q 13.18, 2.51, 23.36, 2.41 Q 33.54, 2.27,\
                  43.72, 2.39 Q 53.90, 2.78, 64.08, 2.67 Q 74.26, 2.57, 84.44, 2.67 Q 94.62, 2.39, 104.80, 2.85 Q 114.98, 2.09, 125.16, 2.70\
                  Q 135.34, 2.67, 145.52, 2.66 Q 155.70, 3.38, 165.88, 3.18 Q 176.06, 3.57, 186.24, 2.54 Q 196.42, 2.66, 206.60, 3.36 Q 216.78,\
                  3.03, 226.96, 2.26 Q 237.14, 2.65, 247.32, 3.67 Q 257.50, 4.06, 267.68, 3.77 Q 277.86, 2.63, 288.04, 3.31 Q 298.22, 3.26,\
                  308.40, 4.02 Q 318.58, 3.56, 328.76, 3.73 Q 338.94, 4.79, 349.12, 4.20 Q 359.30, 3.84, 369.48, 3.32 Q 379.66, 2.36, 389.84,\
                  2.52 Q 400.02, 3.00, 410.20, 2.63 Q 420.38, 2.28, 430.56, 2.86 Q 440.74, 2.43, 450.92, 2.17 Q 461.10, 1.86, 471.28, 2.26 Q\
                  481.46, 1.53, 491.64, 2.32 Q 501.82, 3.00, 512.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1246753648_line4" d="M 3.00, 3.00 Q 3.21, 15.33, 2.81, 27.67 Q 3.23, 40.00,\
                  2.22, 52.33 Q 3.00, 64.67, 3.00, 77.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page450165395-layer-1246753648input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page450165395-layer-1246753648_input_svg_border\',\'__containerId__-page450165395-layer-1246753648_line1\',\'__containerId__-page450165395-layer-1246753648_line2\',\'__containerId__-page450165395-layer-1246753648_line3\',\'__containerId__-page450165395-layer-1246753648_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page450165395-layer-1246753648_input_svg_border\',\'__containerId__-page450165395-layer-1246753648_line1\',\'__containerId__-page450165395-layer-1246753648_line2\',\'__containerId__-page450165395-layer-1246753648_line3\',\'__containerId__-page450165395-layer-1246753648_line4\'))" rows="" cols="" style="width:508px;height:74px;">Author             Name of Tutorial       Category     Rating      </textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page450165395-layer-1252734470" style="position: absolute; left: 195px; top: 355px; width: 515px; height: 80px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1252734470" data-review-reference-id="1252734470">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:515px;" width="515" height="80">\
               <svg:g id="__containerId__-page450165395-layer-1252734470svg" width="515" height="80"><svg:path id="__containerId__-page450165395-layer-1252734470_input_svg_border" d="M 2.00, 2.00 Q 12.22, 2.61, 22.44, 2.30\
                  Q 32.66, 2.08, 42.88, 1.50 Q 53.10, 1.69, 63.32, 1.90 Q 73.54, 1.72, 83.76, 1.45 Q 93.98, 1.20, 104.20, 1.14 Q 114.42, 1.16,\
                  124.64, 0.98 Q 134.86, 0.80, 145.08, 0.80 Q 155.30, 1.38, 165.52, 1.58 Q 175.74, 1.47, 185.96, 1.54 Q 196.18, 0.88, 206.40,\
                  1.25 Q 216.62, 1.04, 226.84, 1.06 Q 237.06, 0.90, 247.28, 0.66 Q 257.50, 0.68, 267.72, 1.04 Q 277.94, 0.86, 288.16, 1.06 Q\
                  298.38, 2.09, 308.60, 1.33 Q 318.82, 2.20, 329.04, 1.74 Q 339.26, 1.81, 349.48, 1.72 Q 359.70, 2.55, 369.92, 2.31 Q 380.14,\
                  1.21, 390.36, 0.88 Q 400.58, 0.55, 410.80, 1.35 Q 421.02, 1.04, 431.24, 0.86 Q 441.46, 1.06, 451.68, 1.66 Q 461.90, 1.59,\
                  472.12, 1.32 Q 482.34, 1.80, 492.56, 0.59 Q 502.78, 1.27, 513.71, 1.29 Q 513.76, 14.41, 513.53, 27.26 Q 513.06, 40.00, 513.92,\
                  52.64 Q 515.00, 65.30, 513.53, 78.53 Q 502.96, 78.53, 492.57, 78.10 Q 482.41, 78.99, 472.16, 79.28 Q 461.91, 78.59, 451.68,\
                  78.15 Q 441.46, 78.30, 431.24, 78.55 Q 421.02, 77.79, 410.80, 78.10 Q 400.58, 78.49, 390.36, 78.64 Q 380.14, 77.91, 369.92,\
                  77.66 Q 359.70, 77.46, 349.48, 77.81 Q 339.26, 78.20, 329.04, 77.63 Q 318.82, 78.17, 308.60, 78.34 Q 298.38, 79.05, 288.16,\
                  79.64 Q 277.94, 79.15, 267.72, 78.25 Q 257.50, 79.45, 247.28, 78.79 Q 237.06, 79.82, 226.84, 79.61 Q 216.62, 79.66, 206.40,\
                  79.30 Q 196.18, 78.90, 185.96, 78.47 Q 175.74, 77.49, 165.52, 78.03 Q 155.30, 78.36, 145.08, 78.29 Q 134.86, 78.37, 124.64,\
                  77.98 Q 114.42, 79.32, 104.20, 79.52 Q 93.98, 78.64, 83.76, 78.32 Q 73.54, 79.26, 63.32, 78.78 Q 53.10, 79.29, 42.88, 78.06\
                  Q 32.66, 78.04, 22.44, 78.34 Q 12.22, 77.22, 1.99, 78.01 Q 1.94, 65.35, 2.09, 52.65 Q 1.27, 40.05, 1.06, 27.36 Q 2.00, 14.67,\
                  2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1252734470_line1" d="M 3.00, 3.00 Q 13.18, 3.72, 23.36, 3.20 Q 33.54, 2.83,\
                  43.72, 3.09 Q 53.90, 3.32, 64.08, 2.08 Q 74.26, 2.79, 84.44, 2.47 Q 94.62, 2.91, 104.80, 2.27 Q 114.98, 1.58, 125.16, 1.57\
                  Q 135.34, 2.64, 145.52, 2.91 Q 155.70, 2.95, 165.88, 2.89 Q 176.06, 3.05, 186.24, 3.41 Q 196.42, 3.39, 206.60, 2.22 Q 216.78,\
                  1.45, 226.96, 0.80 Q 237.14, 0.94, 247.32, 0.74 Q 257.50, 2.03, 267.68, 2.14 Q 277.86, 1.85, 288.04, 2.28 Q 298.22, 2.85,\
                  308.40, 2.87 Q 318.58, 3.63, 328.76, 3.49 Q 338.94, 3.10, 349.12, 3.00 Q 359.30, 2.72, 369.48, 1.91 Q 379.66, 2.39, 389.84,\
                  2.34 Q 400.02, 2.18, 410.20, 1.71 Q 420.38, 1.14, 430.56, 1.13 Q 440.74, 1.07, 450.92, 0.99 Q 461.10, 1.06, 471.28, 2.28 Q\
                  481.46, 1.39, 491.64, 1.29 Q 501.82, 3.00, 512.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1252734470_line2" d="M 3.00, 3.00 Q 5.37, 15.33, 5.46, 27.67 Q 5.01, 40.00,\
                  5.45, 52.33 Q 3.00, 64.67, 3.00, 77.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1252734470_line3" d="M 3.00, 3.00 Q 13.18, 1.41, 23.36, 1.26 Q 33.54, 1.22,\
                  43.72, 1.15 Q 53.90, 1.18, 64.08, 1.43 Q 74.26, 1.26, 84.44, 1.16 Q 94.62, 1.10, 104.80, 1.10 Q 114.98, 1.61, 125.16, 1.84\
                  Q 135.34, 2.17, 145.52, 1.48 Q 155.70, 1.73, 165.88, 1.12 Q 176.06, 1.98, 186.24, 1.44 Q 196.42, 1.36, 206.60, 1.57 Q 216.78,\
                  1.48, 226.96, 2.36 Q 237.14, 2.60, 247.32, 2.62 Q 257.50, 2.79, 267.68, 2.73 Q 277.86, 2.42, 288.04, 2.24 Q 298.22, 2.60,\
                  308.40, 2.61 Q 318.58, 2.45, 328.76, 1.40 Q 338.94, 2.14, 349.12, 2.58 Q 359.30, 3.57, 369.48, 2.31 Q 379.66, 1.21, 389.84,\
                  2.46 Q 400.02, 2.93, 410.20, 2.59 Q 420.38, 1.92, 430.56, 1.79 Q 440.74, 3.14, 450.92, 2.81 Q 461.10, 2.66, 471.28, 2.90 Q\
                  481.46, 2.82, 491.64, 2.96 Q 501.82, 3.00, 512.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page450165395-layer-1252734470_line4" d="M 3.00, 3.00 Q 2.45, 15.33, 3.08, 27.67 Q 2.94, 40.00,\
                  4.11, 52.33 Q 3.00, 64.67, 3.00, 77.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page450165395-layer-1252734470input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page450165395-layer-1252734470_input_svg_border\',\'__containerId__-page450165395-layer-1252734470_line1\',\'__containerId__-page450165395-layer-1252734470_line2\',\'__containerId__-page450165395-layer-1252734470_line3\',\'__containerId__-page450165395-layer-1252734470_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page450165395-layer-1252734470_input_svg_border\',\'__containerId__-page450165395-layer-1252734470_line1\',\'__containerId__-page450165395-layer-1252734470_line2\',\'__containerId__-page450165395-layer-1252734470_line3\',\'__containerId__-page450165395-layer-1252734470_line4\'))" rows="" cols="" style="width:508px;height:74px;">Author             Name of Tutorial       Category     Rating      </textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text855970511" style="position: absolute; left: 195px; top: 105px; width: 109px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text855970511" data-review-reference-id="text855970511">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;">Popular tutorials </p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text768123400" style="position: absolute; left: 805px; top: 105px; width: 107px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text768123400" data-review-reference-id="text768123400">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Popular authors</p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-listview852930950" style="position: absolute; left: 775px; top: 140px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview852930950" data-review-reference-id="listview852930950">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 140px;width:150px;" width="150" height="140">\
               <svg:g width="150" height="140"><svg:path id="__containerId__-page450165395-layer-listview852930950_input_svg_border" d="M 2.00, 2.00 Q 12.43, 2.96, 22.86,\
                  2.59 Q 33.29, 2.19, 43.71, 1.79 Q 54.14, 1.83, 64.57, 2.19 Q 75.00, 2.72, 85.43, 1.60 Q 95.86, 2.38, 106.29, 1.83 Q 116.71,\
                  1.61, 127.14, 1.96 Q 137.57, 1.85, 147.80, 2.20 Q 147.14, 13.62, 148.80, 24.55 Q 148.26, 35.98, 147.94, 47.34 Q 147.46, 58.68,\
                  148.16, 70.00 Q 148.85, 81.33, 148.33, 92.67 Q 147.86, 104.00, 148.29, 115.33 Q 147.25, 126.67, 148.17, 138.17 Q 137.53, 137.87,\
                  127.14, 138.01 Q 116.65, 137.05, 106.25, 136.89 Q 95.87, 139.02, 85.44, 139.99 Q 75.00, 138.79, 64.57, 138.72 Q 54.14, 138.11,\
                  43.71, 137.63 Q 33.29, 137.00, 22.86, 137.36 Q 12.43, 137.52, 1.85, 138.15 Q 1.03, 126.99, 1.43, 115.41 Q 2.04, 104.00, 2.56,\
                  92.65 Q 2.49, 81.33, 2.29, 70.00 Q 1.31, 58.67, 0.90, 47.34 Q 1.92, 36.00, 3.29, 24.67 Q 2.00, 13.33, 2.00, 2.00" style="\
                  fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page450165395-layer-listview852930950select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page450165395-layer-listview852930950_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page450165395-layer-listview852930950_input_svg_border\')" style="width:142px; height:132px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page450165395-layer-text967979" style="position: absolute; left: 805px; top: 300px; width: 91px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text967979" data-review-reference-id="text967979">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Latest guides</p></span></span></div>\
      </div>\
      <div id="__containerId__-page450165395-layer-listview564704621" style="position: absolute; left: 775px; top: 325px; width: 150px; height: 105px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview564704621" data-review-reference-id="listview564704621">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 105px;width:150px;" width="150" height="105">\
               <svg:g width="150" height="105"><svg:path id="__containerId__-page450165395-layer-listview564704621_input_svg_border" d="M 2.00, 2.00 Q 12.43, 2.42, 22.86,\
                  2.06 Q 33.29, 1.98, 43.71, 1.65 Q 54.14, 1.77, 64.57, 1.39 Q 75.00, 1.98, 85.43, 2.50 Q 95.86, 1.35, 106.29, 2.47 Q 116.71,\
                  1.63, 127.14, 1.04 Q 137.57, 1.25, 148.03, 1.97 Q 147.40, 12.30, 147.47, 22.28 Q 149.01, 32.23, 149.99, 42.34 Q 149.24, 52.48,\
                  148.29, 62.60 Q 148.65, 72.70, 149.15, 82.80 Q 149.76, 92.90, 148.90, 103.90 Q 137.92, 104.03, 127.32, 104.22 Q 116.83, 104.69,\
                  106.30, 103.40 Q 95.86, 103.47, 85.43, 102.57 Q 75.00, 102.02, 64.57, 102.10 Q 54.14, 103.70, 43.71, 104.21 Q 33.29, 104.60,\
                  22.86, 105.35 Q 12.43, 104.63, 1.25, 103.75 Q 1.63, 93.02, 1.81, 82.83 Q 2.43, 72.67, 1.74, 62.61 Q 1.72, 52.50, 1.91, 42.40\
                  Q 1.34, 32.30, 1.15, 22.20 Q 2.00, 12.10, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page450165395-layer-listview564704621select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page450165395-layer-listview564704621_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page450165395-layer-listview564704621_input_svg_border\')" style="width:142px; height:97px;" title="" multiple="multiple">\
                  <addScrollListener></addScrollListener>\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page450165395-layer-comment173302838" style="position: absolute; left: 575px; top: 40px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment173302838" data-review-reference-id="comment173302838">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 41px;width:200px;" width="200" height="41">\
               <svg:g width="200" height="40"><svg:path d="M 2.00, 2.00 Q 12.06, 1.01, 22.11, 0.96 Q 32.17, 1.48, 42.22, 1.31 Q 52.28, 2.36, 62.33, 1.99 Q 72.39, 1.93,\
                  82.44, 1.48 Q 92.50, 2.66, 102.56, 3.05 Q 112.61, 2.35, 122.67, 2.94 Q 132.72, 2.55, 142.78, 2.64 Q 152.83, 1.96, 162.89,\
                  1.67 Q 172.94, 1.60, 182.94, 2.13 Q 190.20, 10.42, 197.98, 18.01 Q 197.85, 28.03, 198.16, 38.15 Q 186.98, 37.58, 176.16, 37.52\
                  Q 165.31, 37.63, 154.45, 38.28 Q 143.56, 38.26, 132.67, 38.41 Q 121.78, 38.95, 110.89, 39.23 Q 100.00, 38.87, 89.11, 38.43\
                  Q 78.22, 38.35, 67.33, 38.61 Q 56.44, 39.20, 45.56, 38.65 Q 34.67, 37.99, 23.78, 38.53 Q 12.89, 38.37, 1.89, 38.11 Q 2.00,\
                  19.50, 2.00, 1.00" style=" fill:#FFFFCC;" class="svg_unselected_element"/><svg:path d="M 182.00, 2.00 Q 184.55, 9.50, 183.29, 15.71 Q 189.50, 17.00, 197.00, 17.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 4px; top: 2px; height: 36px;width:196px;font-size:1em;line-height:1.2em;" xml:space="preserve">Username leads to profile page<br /></div>\
         </div>\
      </div>\
   </div>\
</div>');