rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page120515866-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page120515866" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page120515866-layer-text431978013" style="position: absolute; left: 55px; top: 115px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text431978013" data-review-reference-id="text431978013">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Categories<br /></span></p></span></span></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-text431978013\', \'interaction420288059\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action557512670\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction50578135\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page65706462\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page120515866-layer-1553122038" style="position: absolute; left: 55px; top: 140px; width: 61px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1553122038" data-review-reference-id="1553122038">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Tutorials</span></p></span></span></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-1553122038\', \'interaction46720627\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action557512670\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction50578135\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page65706462\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page120515866-layer-1905495757" style="position: absolute; left: 55px; top: 165px; width: 43px; height: 32px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1905495757" data-review-reference-id="1905495757">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Users<br /><br /></span></p></span></span></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-1905495757\', \'interaction503415199\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action557512670\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction50578135\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page65706462\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page120515866-layer-comment710961335" style="position: absolute; left: 260px; top: 150px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment710961335" data-review-reference-id="comment710961335">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 41px;width:200px;" width="200" height="41">\
               <svg:g width="200" height="40"><svg:path d="M 2.00, 2.00 Q 12.06, -0.31, 22.11, 0.00 Q 32.17, 0.09, 42.22, 0.52 Q 52.28, 0.51, 62.33, 0.56 Q 72.39, 0.73,\
                  82.44, 0.91 Q 92.50, 0.86, 102.56, 0.82 Q 112.61, 1.31, 122.67, 0.86 Q 132.72, 0.85, 142.78, 0.57 Q 152.83, 0.55, 162.89,\
                  0.37 Q 172.94, 0.58, 183.42, 1.03 Q 191.29, 8.90, 199.16, 17.43 Q 199.20, 27.74, 198.29, 38.26 Q 187.41, 38.95, 176.38, 39.18\
                  Q 165.41, 39.29, 154.48, 39.12 Q 143.57, 39.23, 132.68, 39.62 Q 121.78, 39.76, 110.89, 39.82 Q 100.00, 39.84, 89.11, 40.07\
                  Q 78.22, 40.29, 67.33, 39.67 Q 56.44, 39.15, 45.56, 38.94 Q 34.67, 39.36, 23.78, 38.98 Q 12.89, 39.19, 1.40, 38.60 Q 2.00,\
                  19.50, 2.00, 1.00" style=" fill:#FFFFCC;" class="svg_unselected_element"/><svg:path d="M 182.00, 2.00 Q 183.52, 9.50, 182.48, 16.52 Q 189.50, 17.00, 197.00, 17.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 4px; top: 2px; height: 36px;width:196px;font-size:1em;line-height:1.2em;" xml:space="preserve">Each link opens list of selected <br />objects.<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page120515866-layer-text993419917" style="position: absolute; left: 795px; top: 45px; width: 57px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text993419917" data-review-reference-id="text993419917">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Admin<br /></span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page120515866-layer-1351938763" style="position: absolute; left: 55px; top: 30px; width: 198px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1351938763" data-review-reference-id="1351938763">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Tutorials4Life</span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page120515866-layer-928104831" style="position: absolute; left: 870px; top: 40px; width: 64px; height: 30px" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="928104831" data-review-reference-id="928104831">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:64px;" width="64" height="30">\
               <svg:g width="64" height="30"><svg:path d="M 2.00, 2.00 Q 16.25, 0.97, 30.50, 0.87 Q 44.75, 1.12, 59.43, 1.57 Q 59.73, 13.26, 59.21, 25.21 Q 44.94, 25.68,\
                  30.55, 25.47 Q 16.28, 25.58, 1.58, 25.40 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 60.00, 4.00 Q 60.00, 16.00, 60.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 61.00, 5.00 Q 61.00, 17.00, 61.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 62.00, 6.00 Q 62.00, 18.00, 62.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 18.50, 23.69, 33.00, 23.52 Q 47.50, 26.00, 62.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 19.50, 26.67, 34.00, 26.52 Q 48.50, 27.00, 63.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 20.50, 26.56, 35.00, 27.33 Q 49.50, 28.00, 64.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page120515866-layer-928104831button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page120515866-layer-928104831button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page120515866-layer-928104831button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:60px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				logout<br />  \
               			</button></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page120515866-layer-928104831\', \'1592489561\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'1795252231\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'1659251157\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page747205133\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');