rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page747205133-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page747205133" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page747205133-layer-button743693020" style="position: absolute; left: 450px; top: 345px; width: 60px; height: 30px" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button743693020" data-review-reference-id="button743693020">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:60px;" width="60" height="30">\
               <svg:g width="60" height="30"><svg:path d="M 2.00, 2.00 Q 15.25, 0.32, 28.50, 0.26 Q 41.75, 0.59, 55.68, 1.32 Q 56.02, 13.16, 55.40, 25.40 Q 41.95, 25.72,\
                  28.62, 26.10 Q 15.32, 26.34, 1.41, 25.57 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 56.00, 4.00 Q 56.00, 16.00, 56.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 57.00, 5.00 Q 57.00, 17.00, 57.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 58.00, 6.00 Q 58.00, 18.00, 58.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 17.50, 23.84, 31.00, 24.37 Q 44.50, 26.00, 58.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 18.50, 27.50, 32.00, 27.36 Q 45.50, 27.00, 59.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 19.50, 30.42, 33.00, 29.90 Q 46.50, 28.00, 60.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page747205133-layer-button743693020button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page747205133-layer-button743693020button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page747205133-layer-button743693020button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:56px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				login<br />  \
               			</button></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page747205133-layer-button743693020\', \'interaction951594094\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action90189671\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction197171365\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'page120515866\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page747205133-layer-textinput692052303" style="position: absolute; left: 330px; top: 280px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput692052303" data-review-reference-id="textinput692052303">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
               <svg:g id="__containerId__-page747205133-layer-textinput692052303svg" width="150" height="30"><svg:path id="__containerId__-page747205133-layer-textinput692052303_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.38, 22.86,\
                  1.21 Q 33.29, 1.12, 43.71, 1.17 Q 54.14, 0.96, 64.57, 0.68 Q 75.00, 1.03, 85.43, 1.35 Q 95.86, 1.42, 106.29, 1.18 Q 116.71,\
                  1.78, 127.14, 0.68 Q 137.57, 0.72, 148.61, 1.39 Q 148.86, 14.71, 148.24, 28.24 Q 137.58, 28.05, 127.13, 27.87 Q 116.73, 28.32,\
                  106.30, 28.72 Q 95.86, 28.40, 85.43, 27.93 Q 75.00, 28.89, 64.57, 29.48 Q 54.14, 28.92, 43.71, 28.85 Q 33.29, 28.06, 22.86,\
                  28.98 Q 12.43, 28.76, 1.34, 28.66 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput692052303_line1" d="M 3.00, 3.00 Q 13.29, 1.77, 23.57, 1.49 Q 33.86,\
                  1.35, 44.14, 1.31 Q 54.43, 1.39, 64.71, 1.53 Q 75.00, 1.43, 85.29, 1.31 Q 95.57, 1.30, 105.86, 1.41 Q 116.14, 2.33, 126.43,\
                  2.25 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput692052303_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput692052303_line3" d="M 3.00, 3.00 Q 13.29, 2.15, 23.57, 1.93 Q 33.86,\
                  1.93, 44.14, 2.34 Q 54.43, 2.61, 64.71, 2.29 Q 75.00, 1.73, 85.29, 2.73 Q 95.57, 3.34, 105.86, 2.13 Q 116.14, 2.87, 126.43,\
                  2.40 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput692052303_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page747205133-layer-textinput692052303input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page747205133-layer-textinput692052303_input_svg_border\',\'__containerId__-page747205133-layer-textinput692052303_line1\',\'__containerId__-page747205133-layer-textinput692052303_line2\',\'__containerId__-page747205133-layer-textinput692052303_line3\',\'__containerId__-page747205133-layer-textinput692052303_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page747205133-layer-textinput692052303_input_svg_border\',\'__containerId__-page747205133-layer-textinput692052303_line1\',\'__containerId__-page747205133-layer-textinput692052303_line2\',\'__containerId__-page747205133-layer-textinput692052303_line3\',\'__containerId__-page747205133-layer-textinput692052303_line4\'))" value="Login" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page747205133-layer-textinput814149634" style="position: absolute; left: 490px; top: 280px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput814149634" data-review-reference-id="textinput814149634">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
               <svg:g id="__containerId__-page747205133-layer-textinput814149634svg" width="150" height="30"><svg:path id="__containerId__-page747205133-layer-textinput814149634_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.16, 22.86,\
                  0.23 Q 33.29, -0.17, 43.71, 0.17 Q 54.14, 0.54, 64.57, 0.81 Q 75.00, 1.24, 85.43, 0.96 Q 95.86, 0.52, 106.29, -0.02 Q 116.71,\
                  0.40, 127.14, 0.41 Q 137.57, 0.83, 148.07, 1.93 Q 147.97, 15.01, 148.00, 28.00 Q 137.72, 28.54, 127.19, 28.43 Q 116.77, 29.01,\
                  106.33, 29.96 Q 95.88, 29.94, 85.43, 28.98 Q 75.00, 28.30, 64.57, 28.42 Q 54.14, 29.28, 43.71, 29.01 Q 33.29, 28.03, 22.86,\
                  28.49 Q 12.43, 28.14, 2.20, 27.80 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput814149634_line1" d="M 3.00, 3.00 Q 13.29, 1.93, 23.57, 1.60 Q 33.86,\
                  1.38, 44.14, 1.17 Q 54.43, 1.02, 64.71, 1.42 Q 75.00, 1.44, 85.29, 1.34 Q 95.57, 1.14, 105.86, 0.96 Q 116.14, 1.28, 126.43,\
                  1.35 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput814149634_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput814149634_line3" d="M 3.00, 3.00 Q 13.29, 2.15, 23.57, 2.05 Q 33.86,\
                  1.96, 44.14, 2.55 Q 54.43, 2.28, 64.71, 2.00 Q 75.00, 2.62, 85.29, 3.00 Q 95.57, 1.91, 105.86, 2.51 Q 116.14, 2.26, 126.43,\
                  2.77 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page747205133-layer-textinput814149634_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page747205133-layer-textinput814149634input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page747205133-layer-textinput814149634_input_svg_border\',\'__containerId__-page747205133-layer-textinput814149634_line1\',\'__containerId__-page747205133-layer-textinput814149634_line2\',\'__containerId__-page747205133-layer-textinput814149634_line3\',\'__containerId__-page747205133-layer-textinput814149634_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page747205133-layer-textinput814149634_input_svg_border\',\'__containerId__-page747205133-layer-textinput814149634_line1\',\'__containerId__-page747205133-layer-textinput814149634_line2\',\'__containerId__-page747205133-layer-textinput814149634_line3\',\'__containerId__-page747205133-layer-textinput814149634_line4\'))" value="Password" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page747205133-layer-text903285278" style="position: absolute; left: 55px; top: 30px; width: 198px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text903285278" data-review-reference-id="text903285278">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Tutorials4Life</span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page747205133-layer-comment281153414" style="position: absolute; left: 325px; top: 195px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment281153414" data-review-reference-id="comment281153414">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 41px;width:200px;" width="200" height="41">\
               <svg:g width="200" height="40"><svg:path d="M 2.00, 2.00 Q 12.06, 1.67, 22.11, 2.50 Q 32.17, 2.36, 42.22, 3.43 Q 52.28, 1.65, 62.33, 1.66 Q 72.39, 2.77,\
                  82.44, 3.50 Q 92.50, 3.02, 102.56, 2.29 Q 112.61, 2.29, 122.67, 1.55 Q 132.72, 2.33, 142.78, 1.87 Q 152.83, 2.00, 162.89,\
                  2.63 Q 172.94, 2.68, 182.93, 2.16 Q 190.86, 9.50, 198.23, 17.89 Q 198.75, 27.84, 198.31, 38.29 Q 187.27, 38.51, 176.38, 39.18\
                  Q 165.40, 39.08, 154.47, 38.80 Q 143.57, 39.22, 132.68, 39.74 Q 121.78, 39.90, 110.89, 39.86 Q 100.00, 38.84, 89.11, 38.56\
                  Q 78.22, 38.59, 67.33, 38.56 Q 56.44, 38.43, 45.56, 38.47 Q 34.67, 38.80, 23.78, 39.10 Q 12.89, 38.21, 2.02, 37.98 Q 2.00,\
                  19.50, 2.00, 1.00" style=" fill:#FFFFCC;" class="svg_unselected_element"/><svg:path d="M 182.00, 2.00 Q 181.74, 9.50, 182.12, 16.88 Q 189.50, 17.00, 197.00, 17.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 4px; top: 2px; height: 36px;width:196px;font-size:1em;line-height:1.2em;" xml:space="preserve">Simple as it is<br /></div>\
         </div>\
      </div>\
   </div>\
</div>');