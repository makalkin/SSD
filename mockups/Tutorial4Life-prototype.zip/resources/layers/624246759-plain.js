rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__624246759-layer" class="layer" name="__containerId__pageLayer" data-layer-id="624246759" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-624246759-layer-955217002" style="position: absolute; left: 735px; top: 15px; width: 72px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="955217002" data-review-reference-id="955217002">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Username<br /><br /></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-969214364" style="position: absolute; left: 815px; top: 10px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="969214364" data-review-reference-id="969214364">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:68px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Logout<br /></button></div>\
      </div>\
      <div id="__containerId__-624246759-layer-1505384943" style="position: absolute; left: 815px; top: 50px; width: 131px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1505384943" data-review-reference-id="1505384943">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:131px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Back to main page<br /></button></div>\
      </div>\
      <div id="__containerId__-624246759-layer-550729332" style="position: absolute; left: 20px; top: 25px; width: 143px; height: 24px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="550729332" data-review-reference-id="550729332">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p><span style="font-size: 20px;">Tutorials name<br /></span></p>\
                  <p style="font-size: 14px;"><span style="font-size: 20px;"> </span></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-1621123758" style="position: absolute; left: 235px; top: 90px; width: 450px; height: 250px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1621123758" data-review-reference-id="1621123758">\
         <div title=""><select id="__containerId__-624246759-layer-1621123758select" style="width:450px; height:250px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener></select></div>\
      </div>\
      <div id="__containerId__-624246759-layer-523750937" style="position: absolute; left: 250px; top: 105px; width: 96px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="523750937" data-review-reference-id="523750937">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>text of tutorial</p>\
                  <p class="none" style="font-size: 14px;"> </p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-372182856" style="position: absolute; left: 15px; top: 100px; width: 150px; height: 325px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="372182856" data-review-reference-id="372182856">\
         <div title=""><select id="__containerId__-624246759-layer-372182856select" style="width:150px; height:325px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-624246759-layer-442707659" style="position: absolute; left: 15px; top: 80px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="442707659" data-review-reference-id="442707659">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-280943732" style="position: absolute; left: 775px; top: 105px; width: 168px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="280943732" data-review-reference-id="280943732">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>tutorials from this category<br />\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-2076897963" style="position: absolute; left: 765px; top: 135px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2076897963" data-review-reference-id="2076897963">\
         <div title=""><select id="__containerId__-624246759-layer-2076897963select" style="width:150px; height:140px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-624246759-layer-2088071006" style="position: absolute; left: 775px; top: 295px; width: 109px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2088071006" data-review-reference-id="2088071006">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Authors tutorials</p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-2032381200" style="position: absolute; left: 765px; top: 330px; width: 150px; height: 125px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2032381200" data-review-reference-id="2032381200">\
         <div title=""><select id="__containerId__-624246759-layer-2032381200select" style="width:150px; height:125px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-624246759-layer-text312186894" style="position: absolute; left: 215px; top: 30px; width: 52px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text312186894" data-review-reference-id="text312186894">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>Author\
                  <p class="none" style="font-size: 14px;"> </p></p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-text490724374" style="position: absolute; left: 215px; top: 55px; width: 127px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text490724374" data-review-reference-id="text490724374">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Category of tutorial</p></span></span></div>\
      </div>\
      <div id="__containerId__-624246759-layer-textinput538450841" style="position: absolute; left: 335px; top: 370px; width: 350px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput538450841" data-review-reference-id="textinput538450841">\
         <div title=""><input id="__containerId__-624246759-layer-textinput538450841input" value="" style="width:348px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
      <div id="__containerId__-624246759-layer-button63210799" style="position: absolute; left: 235px; top: 370px; width: 83px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button63210799" data-review-reference-id="button63210799">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:83px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Comment<br /></button></div>\
      </div>\
      <div id="__containerId__-624246759-layer-textinput723798342" style="position: absolute; left: 235px; top: 420px; width: 450px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput723798342" data-review-reference-id="textinput723798342">\
         <div title=""><input id="__containerId__-624246759-layer-textinput723798342input" value="comment1" style="width:448px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
      <div id="__containerId__-624246759-layer-1759758224" style="position: absolute; left: 235px; top: 460px; width: 450px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1759758224" data-review-reference-id="1759758224">\
         <div title=""><input id="__containerId__-624246759-layer-1759758224input" value="comment2" style="width:448px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
   </div>\
</div>');