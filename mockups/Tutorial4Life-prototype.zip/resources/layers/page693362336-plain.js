rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page693362336-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page693362336" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page693362336-layer-488633189" style="position: absolute; left: 735px; top: 15px; width: 72px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="488633189" data-review-reference-id="488633189">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Username<br /><br /></p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1435246561" style="position: absolute; left: 815px; top: 10px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1435246561" data-review-reference-id="1435246561">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:68px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Logout<br /></button></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1759028085" style="position: absolute; left: 815px; top: 50px; width: 131px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1759028085" data-review-reference-id="1759028085">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:131px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Back to main page<br /></button></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1996741608" style="position: absolute; left: 15px; top: 10px; width: 71px; height: 24px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1996741608" data-review-reference-id="1996741608">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p><span style="font-size: 20px;">Author</span></p>\
                  <p style="font-size: 14px;"><span style="font-size: 20px;"> </span></p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-211637790" style="position: absolute; left: 240px; top: 135px; width: 450px; height: 330px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="211637790" data-review-reference-id="211637790">\
         <div title=""><select id="__containerId__-page693362336-layer-211637790select" style="width:450px; height:330px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener></select></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1165929171" style="position: absolute; left: 270px; top: 150px; width: 161px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1165929171" data-review-reference-id="1165929171">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p>something about author</p>\
                  <p class="none" style="font-size: 14px;"> </p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-2011053116" style="position: absolute; left: 15px; top: 135px; width: 150px; height: 330px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2011053116" data-review-reference-id="2011053116">\
         <div title=""><select id="__containerId__-page693362336-layer-2011053116select" style="width:150px; height:330px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-89624771" style="position: absolute; left: 20px; top: 100px; width: 75px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="89624771" data-review-reference-id="89624771">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Categories</p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-1686848533" style="position: absolute; left: 775px; top: 105px; width: 107px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1686848533" data-review-reference-id="1686848533">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Popular authors</p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-315426403" style="position: absolute; left: 765px; top: 135px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="315426403" data-review-reference-id="315426403">\
         <div title=""><select id="__containerId__-page693362336-layer-315426403select" style="width:150px; height:140px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-733764211" style="position: absolute; left: 775px; top: 295px; width: 109px; height: 18px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="733764211" data-review-reference-id="733764211">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Authors tutorials</p></span></span></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-2011923044" style="position: absolute; left: 765px; top: 330px; width: 150px; height: 140px" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="2011923044" data-review-reference-id="2011923044">\
         <div title=""><select id="__containerId__-page693362336-layer-2011923044select" style="width:150px; height:140px;" size="2" title="" multiple="multiple">\
               <addScrollListener></addScrollListener>\
               <option title="">First entry</option>\
               <option title="">Second entry</option>\
               <option title="">Third entry</option></select></div>\
      </div>\
      <div id="__containerId__-page693362336-layer-image592200965" style="position: absolute; left: 90px; top: 10px; width: 80px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image592200965" data-review-reference-id="image592200965">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 70px;width:80px;" width="80" height="70" viewBox="0 0 80 70">\
               <svg:g width="80" height="70">\
                  <svg:rect x="0" y="0" width="80" height="70" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                  <svg:line x1="0" y1="0" x2="80" y2="70" style="stroke:black; stroke-width:0.5;"></svg:line>\
                  <svg:line x1="0" y1="70" x2="80" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
   </div>\
</div>');