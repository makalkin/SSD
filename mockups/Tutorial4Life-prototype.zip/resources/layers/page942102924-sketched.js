rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page942102924-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page942102924" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page942102924-layer-iphoneButton675232336" style="position: absolute; left: 895px; top: 10px; width: 54px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton675232336" data-review-reference-id="iphoneButton675232336">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:58px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="58" height="34" viewBox="-2 -2 58 34">\
               <svg:a><svg:path d="M 4.00, 29.00 Q 2.60, 29.31, 1.38, 28.62 Q 0.97, 27.38, 0.43, 26.18 Q 0.43, 14.08, 0.32, 1.89 Q 0.84, 0.78, 1.67,\
                  -0.29 Q 2.27, -1.47, 3.98, -1.05 Q 16.03, -0.81, 28.00, -1.04 Q 39.98, -1.46, 52.10, -1.44 Q 52.98, -0.44, 54.04, -0.05 Q\
                  54.95, 0.66, 56.42, 1.54 Q 55.26, 13.96, 54.90, 25.98 Q 54.51, 27.00, 54.04, 28.04 Q 53.16, 28.71, 52.16, 29.51 Q 40.13, 29.84,\
                  28.02, 29.21 Q 16.00, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                  <svg:text x="27" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Вийти</svg:text>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text63815973" style="position: absolute; left: 55px; top: 225px; width: 80px; height: 18px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text63815973" data-review-reference-id="text63815973">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;">Користувач</p></span></span></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-image169066345" style="position: absolute; left: 20px; top: 40px; width: 145px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image169066345" data-review-reference-id="image169066345">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 145px;width:145px;" width="145" height="145">\
               <svg:g width="145" height="145"><svg:path id="id" d="M 2.00, 2.00 Q 12.07, 1.35, 22.14, 1.53 Q 32.21, 2.01, 42.29, 2.15 Q 52.36, 1.53, 62.43, 2.00 Q 72.50,\
                  1.70, 82.57, 2.06 Q 92.64, 1.38, 102.71, 1.51 Q 112.79, 2.37, 122.86, 2.62 Q 132.93, 2.18, 143.42, 1.58 Q 143.05, 12.05, 143.17,\
                  22.12 Q 143.29, 32.19, 143.46, 42.27 Q 143.81, 52.34, 142.87, 62.43 Q 142.58, 72.50, 142.23, 82.57 Q 144.21, 92.64, 142.51,\
                  102.71 Q 143.65, 112.79, 143.51, 122.86 Q 144.48, 132.93, 143.96, 143.96 Q 133.36, 144.28, 123.01, 144.08 Q 112.88, 144.39,\
                  102.77, 144.72 Q 92.66, 143.82, 82.58, 144.61 Q 72.51, 144.62, 62.43, 144.40 Q 52.36, 144.41, 42.29, 143.97 Q 32.21, 143.80,\
                  22.14, 143.12 Q 12.07, 144.10, 1.94, 143.06 Q 2.16, 132.87, 2.17, 122.83 Q 1.38, 112.83, 1.11, 102.74 Q 1.30, 92.65, 2.94,\
                  82.56 Q 2.30, 72.50, 0.18, 62.43 Q 0.43, 52.36, 0.30, 42.29 Q 0.18, 32.21, 0.45, 22.14 Q 2.00, 12.07, 2.00, 2.00" style="fill:white;stroke-width:1.5;"\
                  class="svg_unselected_element"/><svg:path d="M 2.00, 2.00 Q 10.20, 9.46, 17.36, 17.98 Q 25.20, 25.80, 33.03, 33.64 Q 41.80, 40.53, 49.28, 48.72 Q 56.75, 56.92,\
                  64.86, 64.48 Q 72.69, 72.31, 80.91, 79.76 Q 88.56, 87.77, 96.27, 95.73 Q 104.27, 103.39, 112.05, 111.29 Q 120.57, 118.43,\
                  128.55, 126.12 Q 135.17, 135.17, 143.00, 143.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 2.00, 143.00 Q 8.72, 135.51, 15.97, 128.57 Q 23.02, 121.41, 30.18, 114.37 Q 37.29, 107.29, 44.60, 100.39 Q\
                  51.86, 93.46, 58.78, 86.18 Q 65.69, 78.88, 73.02, 72.02 Q 80.26, 65.05, 87.45, 58.04 Q 94.32, 50.71, 101.94, 44.14 Q 108.42,\
                  36.40, 116.18, 29.98 Q 122.91, 22.50, 130.00, 15.39 Q 137.85, 9.05, 145.00, 2.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-clickArea333403901" style="position: absolute; left: 180px; top: 60px; width: 525px; height: 290px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="clickArea333403901" data-review-reference-id="clickArea333403901">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 290px; width:525px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 290px;width:525px;" width="525" height="290" viewBox="0 0 525 290">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="525" height="290" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button974177568" style="position: absolute; left: 185px; top: 10px; width: 121px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button974177568" data-review-reference-id="button974177568">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:121px;" width="121" height="30">\
               <svg:g width="121" height="30"><svg:path d="M 2.00, 2.00 Q 13.40, 0.71, 24.80, 0.86 Q 36.20, 0.72, 47.60, 0.75 Q 59.00, 0.70, 70.40, 0.28 Q 81.80, 0.63,\
                  93.20, 0.53 Q 104.60, 1.19, 116.40, 1.60 Q 117.41, 13.03, 116.77, 25.77 Q 104.96, 26.30, 93.34, 26.28 Q 81.88, 26.66, 70.43,\
                  26.30 Q 59.01, 26.13, 47.60, 25.52 Q 36.20, 26.01, 24.80, 25.58 Q 13.40, 26.69, 1.07, 25.93 Q 2.00, 13.50, 2.00, 2.00" style="\
                  fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 117.00, 4.00 Q 117.00, 16.00, 117.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 118.00, 5.00 Q 118.00, 17.00, 118.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 119.00, 6.00 Q 119.00, 18.00, 119.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 15.50, 25.53, 27.00, 25.65 Q 38.50, 26.40, 50.00, 26.13 Q 61.50, 26.02, 73.00, 27.34 Q 84.50,\
                  26.56, 96.00, 26.49 Q 107.50, 26.00, 119.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 16.50, 27.37, 28.00, 27.03 Q 39.50, 27.34, 51.00, 27.28 Q 62.50, 26.81, 74.00, 27.14 Q 85.50,\
                  27.24, 97.00, 26.88 Q 108.50, 27.00, 120.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 17.50, 25.62, 29.00, 26.14 Q 40.50, 25.82, 52.00, 26.84 Q 63.50, 26.76, 75.00, 26.36 Q 86.50,\
                  26.99, 98.00, 27.73 Q 109.50, 28.00, 121.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page942102924-layer-button974177568button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page942102924-layer-button974177568button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page942102924-layer-button974177568button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:117px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Пошта<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button780440806" style="position: absolute; left: 350px; top: 10px; width: 115px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button780440806" data-review-reference-id="button780440806">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:115px;" width="115" height="30">\
               <svg:g width="115" height="30"><svg:path d="M 2.00, 2.00 Q 12.80, -0.36, 23.60, -0.43 Q 34.40, -0.52, 45.20, -0.21 Q 56.00, 0.10, 66.80, -0.36 Q 77.60, -0.22,\
                  88.40, 0.11 Q 99.20, 0.80, 110.50, 1.50 Q 111.03, 13.16, 110.66, 25.66 Q 99.56, 26.30, 88.55, 26.34 Q 77.65, 25.95, 66.83,\
                  26.12 Q 56.01, 25.55, 45.21, 25.87 Q 34.40, 25.51, 23.60, 26.00 Q 12.80, 26.12, 1.41, 25.59 Q 2.00, 13.50, 2.00, 2.00" style="\
                  fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 111.00, 4.00 Q 111.00, 16.00, 111.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 112.00, 5.00 Q 112.00, 17.00, 112.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 113.00, 6.00 Q 113.00, 18.00, 113.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.90, 24.77, 25.80, 25.07 Q 36.70, 25.60, 47.60, 25.56 Q 58.50, 24.82, 69.40, 24.81 Q 80.30,\
                  24.96, 91.20, 24.85 Q 102.10, 26.00, 113.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.90, 24.83, 26.80, 24.75 Q 37.70, 25.10, 48.60, 25.04 Q 59.50, 25.16, 70.40, 25.46 Q 81.30,\
                  25.37, 92.20, 25.62 Q 103.10, 27.00, 114.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.90, 26.75, 27.80, 27.19 Q 38.70, 27.40, 49.60, 27.27 Q 60.50, 27.28, 71.40, 27.60 Q 82.30,\
                  27.42, 93.20, 26.85 Q 104.10, 28.00, 115.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page942102924-layer-button780440806button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page942102924-layer-button780440806button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page942102924-layer-button780440806button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:111px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Нові відгуки<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button659945242" style="position: absolute; left: 505px; top: 10px; width: 197px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button659945242" data-review-reference-id="button659945242">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:197px;" width="197" height="30">\
               <svg:g width="197" height="30"><svg:path d="M 2.00, 2.00 Q 12.56, 3.25, 23.11, 2.67 Q 33.67, 3.49, 44.22, 1.96 Q 54.78, 2.17, 65.33, 2.29 Q 75.89, 1.19,\
                  86.44, -0.29 Q 97.00, -0.31, 107.56, 0.54 Q 118.11, 2.43, 128.67, 2.23 Q 139.22, 2.72, 149.78, 1.91 Q 160.33, 1.15, 170.89,\
                  -0.29 Q 181.44, -0.06, 192.83, 1.17 Q 192.46, 13.35, 192.64, 25.64 Q 181.68, 25.85, 170.96, 25.61 Q 160.37, 25.68, 149.82,\
                  26.81 Q 139.24, 26.37, 128.67, 25.72 Q 118.11, 25.84, 107.56, 26.55 Q 97.00, 27.04, 86.45, 26.66 Q 75.89, 27.40, 65.33, 27.68\
                  Q 54.78, 27.46, 44.22, 26.97 Q 33.67, 26.52, 23.11, 26.36 Q 12.56, 25.30, 1.70, 25.30 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;"\
                  class="svg_unselected_element"/><svg:path d="M 193.00, 4.00 Q 193.00, 16.00, 193.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 194.00, 5.00 Q 194.00, 17.00, 194.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 195.00, 6.00 Q 195.00, 18.00, 195.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.61, 25.09, 25.22, 25.41 Q 35.83, 25.25, 46.44, 25.64 Q 57.06, 26.06, 67.67, 25.64 Q 78.28,\
                  26.50, 88.89, 26.44 Q 99.50, 27.48, 110.11, 27.12 Q 120.72, 26.76, 131.33, 26.03 Q 141.94, 25.94, 152.56, 26.76 Q 163.17,\
                  26.77, 173.78, 25.99 Q 184.39, 26.00, 195.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.61, 25.43, 26.22, 25.38 Q 36.83, 25.23, 47.44, 25.87 Q 58.06, 25.28, 68.67, 25.48 Q 79.28,\
                  25.58, 89.89, 26.37 Q 100.50, 25.72, 111.11, 25.17 Q 121.72, 25.34, 132.33, 25.47 Q 142.94, 25.70, 153.56, 25.69 Q 164.17,\
                  26.86, 174.78, 27.01 Q 185.39, 27.00, 196.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.61, 26.45, 27.22, 26.26 Q 37.83, 26.29, 48.44, 26.49 Q 59.06, 26.45, 69.67, 26.54 Q 80.28,\
                  26.88, 90.89, 26.77 Q 101.50, 26.52, 112.11, 26.44 Q 122.72, 26.41, 133.33, 26.51 Q 143.94, 26.89, 154.56, 27.43 Q 165.17,\
                  27.34, 175.78, 27.28 Q 186.39, 28.00, 197.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page942102924-layer-button659945242button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page942102924-layer-button659945242button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page942102924-layer-button659945242button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:193px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Поправки залишені читачами<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-iphoneListBackground166385015" style="position: absolute; left: 725px; top: 55px; width: 185px; height: 290px" data-interactive-element-type="static.iphoneListBackground" class="iphoneListBackground stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneListBackground166385015" data-review-reference-id="iphoneListBackground166385015">\
         <div title="" style="height: 290px;width:185px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="185" height="290" viewBox="0 0 185 290"><svg:path d="M 2.00, 278.00 Q 1.36, 267.77, 1.17, 257.54 Q 0.89, 247.31, 0.73, 237.08 Q 0.39, 226.85, 0.38, 216.62 Q 0.71,\
               206.38, 0.55, 196.15 Q 0.49, 185.92, 0.31, 175.69 Q 0.20, 165.46, 1.17, 155.23 Q 1.44, 145.00, 1.46, 134.77 Q 0.69, 124.54,\
               0.83, 114.31 Q 0.65, 104.08, 0.73, 93.85 Q 1.05, 83.62, 0.65, 73.38 Q 1.00, 63.15, 0.93, 52.92 Q 1.29, 42.69, 1.90, 32.46\
               Q 1.56, 22.23, 2.14, 12.02 Q 1.92, 10.36, 3.39, 9.14 Q 3.54, 8.02, 3.95, 6.98 Q 4.50, 6.00, 5.03, 5.03 Q 5.68, 4.05, 6.66,\
               3.43 Q 7.92, 3.36, 8.78, 2.50 Q 10.40, 2.25, 11.89, 1.41 Q 22.02, 1.57, 32.09, 1.22 Q 42.20, 2.47, 52.25, 2.26 Q 62.31, 1.24,\
               72.37, 1.89 Q 82.44, 1.34, 92.50, 2.52 Q 102.56, 3.29, 112.63, 3.60 Q 122.69, 2.86, 132.75, 2.23 Q 142.81, 2.17, 152.88, 2.51\
               Q 162.94, 1.71, 173.18, 0.91 Q 174.52, 2.40, 175.86, 3.39 Q 176.86, 3.83, 177.96, 4.09 Q 179.13, 4.23, 180.00, 5.00 Q 180.82,\
               5.77, 180.92, 7.05 Q 182.01, 7.72, 181.68, 9.14 Q 183.05, 10.29, 183.12, 11.98 Q 182.90, 22.20, 183.96, 32.34 Q 183.63, 42.56,\
               183.21, 52.77 Q 182.86, 62.96, 183.75, 73.15 Q 182.69, 83.35, 182.89, 93.54 Q 183.04, 103.73, 183.53, 113.92 Q 183.98, 124.12,\
               183.47, 134.31 Q 182.86, 144.50, 183.30, 154.69 Q 182.83, 164.88, 181.63, 175.08 Q 181.85, 185.27, 182.06, 195.46 Q 182.78,\
               205.65, 183.70, 215.85 Q 183.47, 226.04, 182.73, 236.23 Q 182.39, 246.42, 183.82, 256.62 Q 183.36, 266.81, 183.34, 277.05\
               Q 182.39, 278.47, 182.09, 280.03 Q 182.35, 281.37, 180.57, 281.80 Q 180.09, 282.80, 179.58, 283.58 Q 179.08, 284.61, 177.73,\
               284.55 Q 177.07, 285.63, 176.20, 286.46 Q 174.74, 287.13, 173.09, 287.51 Q 163.03, 288.07, 152.93, 288.22 Q 142.85, 288.46,\
               132.77, 288.77 Q 122.69, 288.18, 112.63, 287.04 Q 102.56, 286.82, 92.50, 287.54 Q 82.44, 287.87, 72.38, 287.13 Q 62.31, 286.66,\
               52.25, 286.47 Q 42.19, 286.65, 32.12, 286.47 Q 22.06, 286.23, 12.04, 286.75 Q 10.69, 285.72, 8.70, 286.80 Q 8.03, 285.42,\
               7.04, 284.92 Q 5.92, 284.66, 4.49, 284.52 Q 3.81, 283.50, 4.57, 281.66 Q 3.80, 280.83, 2.37, 280.27 Q 2.50, 278.50, 2.00,\
               277.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 1.00, 40.00 Q 11.17, 39.76, 21.33, 39.75 Q 31.50, 39.30, 41.67, 39.53 Q 51.83, 40.09, 62.00, 39.39 Q 72.17,\
               38.96, 82.33, 39.32 Q 92.50, 39.62, 102.67, 39.10 Q 112.83, 38.75, 123.00, 38.16 Q 133.17, 37.49, 143.33, 38.36 Q 153.50,\
               37.84, 163.67, 38.54 Q 173.83, 40.00, 184.00, 40.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 80.00 Q 11.17, 77.65, 21.33, 78.38 Q 31.50, 78.76, 41.67, 79.51 Q 51.83, 80.47, 62.00, 79.86 Q 72.17,\
               79.27, 82.33, 79.88 Q 92.50, 80.73, 102.67, 80.68 Q 112.83, 80.01, 123.00, 79.79 Q 133.17, 79.26, 143.33, 78.89 Q 153.50,\
               79.08, 163.67, 79.17 Q 173.83, 80.00, 184.00, 80.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 120.00 Q 11.17, 118.82, 21.33, 118.65 Q 31.50, 118.52, 41.67, 119.25 Q 51.83, 118.81, 62.00, 118.67 Q\
               72.17, 118.80, 82.33, 119.73 Q 92.50, 118.96, 102.67, 119.40 Q 112.83, 119.19, 123.00, 118.68 Q 133.17, 119.17, 143.33, 119.13\
               Q 153.50, 120.21, 163.67, 120.48 Q 173.83, 120.00, 184.00, 120.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 160.00 Q 11.17, 160.15, 21.33, 160.22 Q 31.50, 160.04, 41.67, 160.19 Q 51.83, 160.28, 62.00, 160.07 Q\
               72.17, 159.41, 82.33, 159.88 Q 92.50, 159.73, 102.67, 160.26 Q 112.83, 161.07, 123.00, 160.00 Q 133.17, 159.18, 143.33, 159.58\
               Q 153.50, 159.60, 163.67, 160.16 Q 173.83, 160.00, 184.00, 160.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 200.00 Q 11.17, 200.35, 21.33, 199.01 Q 31.50, 198.12, 41.67, 197.56 Q 51.83, 198.04, 62.00, 197.99 Q\
               72.17, 199.16, 82.33, 198.28 Q 92.50, 198.54, 102.67, 198.94 Q 112.83, 199.19, 123.00, 197.98 Q 133.17, 198.91, 143.33, 199.92\
               Q 153.50, 199.11, 163.67, 199.17 Q 173.83, 200.00, 184.00, 200.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 240.00 Q 11.17, 237.62, 21.33, 237.54 Q 31.50, 237.89, 41.67, 237.83 Q 51.83, 237.95, 62.00, 238.25 Q\
               72.17, 238.16, 82.33, 238.25 Q 92.50, 238.61, 102.67, 239.18 Q 112.83, 238.91, 123.00, 239.08 Q 133.17, 238.86, 143.33, 238.82\
               Q 153.50, 238.79, 163.67, 238.82 Q 173.83, 240.00, 184.00, 240.00" style=" fill:none;" class="svg_unselected_element"/>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-iphoneButton94330194" style="position: absolute; left: 5px; top: 380px; width: 173px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton94330194" data-review-reference-id="iphoneButton94330194">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:177px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="177" height="34" viewBox="-2 -2 177 34">\
               <svg:a><svg:path d="M 4.00, 29.00 Q 2.30, 29.91, 0.94, 29.06 Q 0.39, 27.79, -0.01, 26.32 Q -0.11, 14.16, -0.05, 1.82 Q 0.48, 0.66,\
                  1.32, -0.60 Q 2.72, -0.87, 3.77, -1.70 Q 14.35, -1.57, 24.84, -1.47 Q 35.29, -1.65, 45.74, -1.82 Q 56.19, -0.50, 66.62, -1.83\
                  Q 77.06, 0.10, 87.50, -0.12 Q 97.94, -0.65, 108.37, -1.39 Q 118.81, -1.11, 129.25, -1.49 Q 139.69, -1.48, 150.12, -1.50 Q\
                  160.56, -0.49, 171.12, -1.52 Q 172.07, -0.70, 173.67, -0.75 Q 173.58, 0.94, 173.72, 2.09 Q 175.10, 13.83, 175.34, 26.22 Q\
                  173.37, 26.96, 172.15, 27.25 Q 171.70, 28.10, 170.78, 28.30 Q 160.44, 28.20, 150.13, 29.03 Q 139.67, 28.57, 129.26, 29.36\
                  Q 118.82, 29.29, 108.38, 29.32 Q 97.94, 28.62, 87.50, 29.99 Q 77.06, 29.05, 66.63, 30.02 Q 56.19, 29.63, 45.75, 29.30 Q 35.31,\
                  28.92, 24.87, 28.34 Q 14.44, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"\
                  class="svg_unselected_element"/>\
                  <svg:text x="86.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Підписники користувача 15</svg:text>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-button611283533" style="position: absolute; left: 740px; top: 10px; width: 125px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button611283533" data-review-reference-id="button611283533">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:125px;" width="125" height="30">\
               <svg:g width="125" height="30"><svg:path d="M 2.00, 2.00 Q 13.80, 0.62, 25.60, 1.23 Q 37.40, 0.80, 49.20, 1.84 Q 61.00, 1.99, 72.80, 1.18 Q 84.60, 1.74,\
                  96.40, 3.25 Q 108.20, 3.34, 119.57, 2.43 Q 119.28, 13.74, 120.06, 25.06 Q 108.34, 25.50, 96.39, 24.92 Q 84.59, 24.88, 72.79,\
                  24.60 Q 60.99, 24.41, 49.20, 24.27 Q 37.40, 24.35, 25.60, 25.10 Q 13.80, 24.60, 2.11, 24.89 Q 2.00, 13.50, 2.00, 2.00" style="\
                  fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 121.00, 4.00 Q 121.00, 16.00, 121.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 122.00, 5.00 Q 122.00, 17.00, 122.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 123.00, 6.00 Q 123.00, 18.00, 123.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 15.90, 24.93, 27.80, 24.75 Q 39.70, 24.67, 51.60, 24.49 Q 63.50, 24.32, 75.40, 25.13 Q 87.30,\
                  24.48, 99.20, 24.44 Q 111.10, 26.00, 123.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 16.90, 26.82, 28.80, 27.94 Q 40.70, 28.21, 52.60, 28.38 Q 64.50, 28.00, 76.40, 27.95 Q 88.30,\
                  27.98, 100.20, 28.03 Q 112.10, 27.00, 124.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 17.90, 28.12, 29.80, 28.17 Q 41.70, 27.68, 53.60, 29.53 Q 65.50, 29.04, 77.40, 28.37 Q 89.30,\
                  29.29, 101.20, 29.15 Q 113.10, 28.00, 125.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page942102924-layer-button611283533button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page942102924-layer-button611283533button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page942102924-layer-button611283533button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:121px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Обране<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-clickArea349640040" style="position: absolute; left: 235px; top: 395px; width: 425px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="clickArea349640040" data-review-reference-id="clickArea349640040">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:425px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:425px;" width="425" height="60" viewBox="0 0 425 60">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="425" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text181747783" style="position: absolute; left: 225px; top: 475px; width: 63px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text181747783" data-review-reference-id="text181747783">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;">Реклама</p></span></span></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text519160798" style="position: absolute; left: 375px; top: 475px; width: 160px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text519160798" data-review-reference-id="text519160798">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;">Головна сторінка сайта</p></span></span></div>\
      </div>\
      <div id="__containerId__-page942102924-layer-text298919711" style="position: absolute; left: 620px; top: 475px; width: 70px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text298919711" data-review-reference-id="text298919711">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Допомога</span></p></span></span></div>\
      </div>\
   </div>\
</div>');