rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page585380472-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page585380472" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page585380472-layer-iphoneButton522756103" style="position: absolute; left: 900px; top: 5px; width: 54px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton522756103" data-review-reference-id="iphoneButton522756103">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:58px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="58" height="34" viewBox="-2 -2 58 34">\
               <svg:a><svg:path d="M 4.00, 29.00 Q 3.35, 27.80, 2.34, 27.66 Q 1.66, 26.89, 0.64, 26.11 Q 0.10, 14.13, -0.32, 1.78 Q 0.26, 0.59,\
                  1.42, -0.52 Q 2.32, -1.40, 3.72, -1.88 Q 15.84, -2.10, 27.86, -2.88 Q 39.93, -2.97, 52.33, -2.53 Q 53.22, -1.13, 54.13, -0.15\
                  Q 55.23, 0.45, 55.82, 1.73 Q 55.74, 13.89, 55.77, 26.13 Q 55.95, 27.48, 54.66, 28.59 Q 53.88, 29.66, 52.48, 30.49 Q 40.26,\
                  30.72, 28.13, 30.79 Q 16.00, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"\
                  class="svg_unselected_element"/>\
                  <svg:text x="27" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Вийти</svg:text>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-iphoneListBackground52355221" style="position: absolute; left: 735px; top: 55px; width: 205px; height: 300px" data-interactive-element-type="static.iphoneListBackground" class="iphoneListBackground stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneListBackground52355221" data-review-reference-id="iphoneListBackground52355221">\
         <div title="" style="height: 300px;width:205px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="205" height="300" viewBox="0 0 205 300"><svg:path d="M 2.00, 288.00 Q -0.43, 277.38, -0.12, 266.77 Q -0.03, 256.15, 0.39, 245.54 Q 0.39, 234.92, 0.45, 224.31 Q 0.88,\
               213.69, 1.51, 203.08 Q 1.52, 192.46, 1.32, 181.85 Q 1.20, 171.23, 1.26, 160.62 Q 1.30, 150.00, 1.25, 139.38 Q 1.24, 128.77,\
               1.66, 118.15 Q 1.56, 107.54, 1.75, 96.92 Q 1.43, 86.31, 1.28, 75.69 Q 1.23, 65.08, 1.29, 54.46 Q 1.16, 43.85, 1.52, 33.23\
               Q 1.68, 22.62, 1.62, 11.94 Q 2.82, 10.58, 2.12, 8.67 Q 3.17, 7.86, 3.79, 6.90 Q 4.30, 5.90, 5.14, 5.14 Q 5.70, 4.09, 7.18,\
               4.30 Q 8.00, 3.50, 9.09, 3.22 Q 10.81, 3.32, 12.06, 2.34 Q 22.07, 2.21, 32.11, 1.89 Q 42.16, 1.70, 52.22, 1.72 Q 62.27, 1.25,\
               72.33, 1.78 Q 82.39, 2.87, 92.44, 1.21 Q 102.50, 2.95, 112.56, 2.00 Q 122.61, 1.60, 132.67, 1.91 Q 142.72, 1.87, 152.78, 2.59\
               Q 162.83, 2.37, 172.89, 3.07 Q 182.94, 2.23, 193.15, 1.09 Q 194.64, 1.92, 196.01, 2.96 Q 196.92, 3.68, 197.75, 4.53 Q 199.29,\
               3.90, 200.04, 4.96 Q 200.08, 6.30, 201.42, 6.75 Q 202.56, 7.42, 203.29, 8.44 Q 203.18, 10.24, 202.72, 12.05 Q 202.95, 22.58,\
               203.36, 33.14 Q 203.49, 43.72, 203.70, 54.30 Q 203.35, 64.88, 202.75, 75.46 Q 202.96, 86.04, 202.86, 96.62 Q 202.39, 107.19,\
               202.71, 117.77 Q 203.00, 128.35, 203.46, 138.92 Q 202.83, 149.50, 203.77, 160.08 Q 203.43, 170.65, 203.36, 181.23 Q 203.91,\
               191.81, 203.97, 202.38 Q 203.88, 212.96, 203.28, 223.54 Q 202.27, 234.12, 201.23, 244.69 Q 202.89, 255.27, 204.10, 265.85\
               Q 203.45, 276.42, 202.35, 286.89 Q 201.40, 288.23, 202.32, 290.12 Q 202.30, 291.35, 201.32, 292.15 Q 200.73, 293.11, 200.76,\
               294.75 Q 199.86, 295.70, 198.73, 296.21 Q 197.43, 296.28, 195.98, 295.95 Q 194.49, 296.47, 193.05, 297.30 Q 182.97, 297.24,\
               172.87, 296.47 Q 162.84, 297.09, 152.79, 297.76 Q 142.73, 298.42, 132.67, 299.00 Q 122.61, 298.30, 112.56, 297.20 Q 102.50,\
               297.66, 92.44, 297.18 Q 82.39, 295.42, 72.33, 297.09 Q 62.28, 295.85, 52.22, 296.47 Q 42.17, 297.73, 32.11, 297.87 Q 22.06,\
               296.96, 12.08, 296.51 Q 10.71, 295.64, 9.54, 294.54 Q 8.00, 295.49, 6.75, 295.55 Q 5.45, 295.63, 3.60, 295.42 Q 2.57, 294.38,\
               1.86, 293.29 Q 1.28, 292.22, 1.11, 290.82 Q 2.50, 288.50, 2.00, 287.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 1.00, 40.00 Q 11.15, 39.50, 21.30, 39.32 Q 31.45, 39.24, 41.60, 39.07 Q 51.75, 38.86, 61.90, 39.06 Q 72.05,\
               39.29, 82.20, 39.40 Q 92.35, 38.91, 102.50, 38.57 Q 112.65, 39.20, 122.80, 38.78 Q 132.95, 39.13, 143.10, 39.06 Q 153.25,\
               39.48, 163.40, 39.79 Q 173.55, 39.19, 183.70, 39.00 Q 193.85, 40.00, 204.00, 40.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 80.00 Q 11.15, 78.67, 21.30, 78.82 Q 31.45, 78.68, 41.60, 78.64 Q 51.75, 78.65, 61.90, 78.24 Q 72.05,\
               78.87, 82.20, 78.69 Q 92.35, 78.94, 102.50, 79.18 Q 112.65, 78.06, 122.80, 77.91 Q 132.95, 78.32, 143.10, 78.83 Q 153.25,\
               78.42, 163.40, 78.91 Q 173.55, 78.91, 183.70, 79.16 Q 193.85, 80.00, 204.00, 80.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 120.00 Q 11.15, 119.54, 21.30, 118.93 Q 31.45, 119.17, 41.60, 119.38 Q 51.75, 119.74, 61.90, 119.96 Q\
               72.05, 120.06, 82.20, 119.90 Q 92.35, 119.70, 102.50, 119.95 Q 112.65, 118.75, 122.80, 119.27 Q 132.95, 118.38, 143.10, 119.34\
               Q 153.25, 120.50, 163.40, 120.84 Q 173.55, 120.97, 183.70, 121.06 Q 193.85, 120.00, 204.00, 120.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 160.00 Q 11.15, 158.12, 21.30, 158.47 Q 31.45, 159.14, 41.60, 158.72 Q 51.75, 158.53, 61.90, 159.36 Q\
               72.05, 158.66, 82.20, 158.57 Q 92.35, 158.11, 102.50, 158.55 Q 112.65, 159.34, 122.80, 159.67 Q 132.95, 159.41, 143.10, 159.51\
               Q 153.25, 160.60, 163.40, 159.46 Q 173.55, 158.95, 183.70, 158.93 Q 193.85, 160.00, 204.00, 160.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 200.00 Q 11.15, 199.61, 21.30, 199.43 Q 31.45, 199.26, 41.60, 199.95 Q 51.75, 200.53, 61.90, 199.12 Q\
               72.05, 199.76, 82.20, 200.70 Q 92.35, 201.35, 102.50, 200.75 Q 112.65, 199.23, 122.80, 198.67 Q 132.95, 199.47, 143.10, 200.08\
               Q 153.25, 200.24, 163.40, 201.23 Q 173.55, 200.74, 183.70, 200.93 Q 193.85, 200.00, 204.00, 200.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 1.00, 240.00 Q 11.15, 238.91, 21.30, 239.11 Q 31.45, 239.25, 41.60, 238.40 Q 51.75, 238.27, 61.90, 239.18 Q\
               72.05, 238.85, 82.20, 238.05 Q 92.35, 237.83, 102.50, 237.66 Q 112.65, 238.08, 122.80, 238.71 Q 132.95, 237.50, 143.10, 237.87\
               Q 153.25, 238.72, 163.40, 237.77 Q 173.55, 237.98, 183.70, 237.94 Q 193.85, 240.00, 204.00, 240.00" style=" fill:none;" class="svg_unselected_element"/>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button19245637" style="position: absolute; left: 735px; top: 15px; width: 120px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button19245637" data-review-reference-id="button19245637">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:120px;" width="120" height="30">\
               <svg:g width="120" height="30"><svg:path d="M 2.00, 2.00 Q 13.30, 0.85, 24.60, 1.68 Q 35.90, 2.48, 47.20, 2.39 Q 58.50, 2.39, 69.80, 3.48 Q 81.10, 3.04,\
                  92.40, 2.85 Q 103.70, 1.67, 115.27, 1.73 Q 114.44, 13.69, 114.98, 24.98 Q 103.65, 24.83, 92.41, 25.06 Q 81.09, 24.73, 69.79,\
                  24.68 Q 58.49, 24.42, 47.20, 25.20 Q 35.90, 24.60, 24.60, 25.11 Q 13.30, 24.29, 2.26, 24.74 Q 2.00, 13.50, 2.00, 2.00" style="\
                  fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 116.00, 4.00 Q 116.00, 16.00, 116.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 117.00, 5.00 Q 117.00, 17.00, 117.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 118.00, 6.00 Q 118.00, 18.00, 118.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 15.40, 25.13, 26.80, 24.45 Q 38.20, 24.61, 49.60, 24.67 Q 61.00, 25.25, 72.40, 25.52 Q 83.80,\
                  26.06, 95.20, 25.38 Q 106.60, 26.00, 118.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 16.40, 26.51, 27.80, 26.70 Q 39.20, 26.45, 50.60, 27.21 Q 62.00, 27.10, 73.40, 26.84 Q 84.80,\
                  26.75, 96.20, 27.46 Q 107.60, 27.00, 119.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 17.40, 25.74, 28.80, 26.03 Q 40.20, 26.97, 51.60, 26.59 Q 63.00, 27.13, 74.40, 28.03 Q 85.80,\
                  28.13, 97.20, 27.39 Q 108.60, 28.00, 120.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button19245637button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button19245637button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button19245637button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:116px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Обране<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button821046572" style="position: absolute; left: 490px; top: 15px; width: 228px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button821046572" data-review-reference-id="button821046572">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:228px;" width="228" height="30">\
               <svg:g width="228" height="30"><svg:path d="M 2.00, 2.00 Q 12.05, 0.48, 22.09, 1.46 Q 32.14, 1.47, 42.18, 2.58 Q 52.23, 1.92, 62.27, 1.51 Q 72.32, 1.43,\
                  82.36, 1.95 Q 92.41, 1.25, 102.45, 0.92 Q 112.50, 1.77, 122.55, 1.95 Q 132.59, 1.63, 142.64, 0.94 Q 152.68, 2.02, 162.73,\
                  1.17 Q 172.77, 1.05, 182.82, 0.57 Q 192.86, 0.52, 202.91, 1.22 Q 212.95, 1.75, 222.93, 2.07 Q 224.06, 13.15, 223.21, 25.21\
                  Q 213.00, 25.18, 203.01, 25.95 Q 192.95, 26.75, 182.87, 26.99 Q 172.79, 26.27, 162.73, 25.76 Q 152.69, 26.59, 142.64, 27.20\
                  Q 132.59, 27.15, 122.55, 27.08 Q 112.50, 26.87, 102.45, 27.06 Q 92.41, 26.89, 82.36, 26.65 Q 72.32, 27.15, 62.27, 26.22 Q\
                  52.23, 26.63, 42.18, 25.85 Q 32.14, 25.39, 22.09, 24.55 Q 12.05, 25.32, 1.37, 25.63 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;"\
                  class="svg_unselected_element"/><svg:path d="M 224.00, 4.00 Q 224.00, 16.00, 224.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 225.00, 5.00 Q 225.00, 17.00, 225.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 226.00, 6.00 Q 226.00, 18.00, 226.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.09, 25.03, 24.18, 25.01 Q 34.27, 24.86, 44.36, 24.83 Q 54.45, 24.66, 64.55, 24.37 Q 74.64,\
                  24.36, 84.73, 25.31 Q 94.82, 25.13, 104.91, 24.69 Q 115.00, 24.19, 125.09, 24.11 Q 135.18, 24.77, 145.27, 24.00 Q 155.36,\
                  24.35, 165.45, 25.67 Q 175.55, 24.66, 185.64, 25.26 Q 195.73, 24.87, 205.82, 24.65 Q 215.91, 26.00, 226.00, 26.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.09, 25.59, 25.18, 25.49 Q 35.27, 25.39, 45.36, 25.20 Q 55.45, 25.87, 65.55, 25.38 Q 75.64,\
                  25.04, 85.73, 25.38 Q 95.82, 25.27, 105.91, 26.22 Q 116.00, 26.70, 126.09, 25.67 Q 136.18, 25.39, 146.27, 25.26 Q 156.36,\
                  25.86, 166.45, 25.25 Q 176.55, 24.95, 186.64, 25.44 Q 196.73, 26.80, 206.82, 27.18 Q 216.91, 27.00, 227.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.09, 28.58, 26.18, 28.28 Q 36.27, 27.02, 46.36, 28.24 Q 56.45, 28.94, 66.55, 27.03 Q 76.64,\
                  28.03, 86.73, 29.08 Q 96.82, 29.44, 106.91, 28.87 Q 117.00, 27.44, 127.09, 26.52 Q 137.18, 26.86, 147.27, 27.41 Q 157.36,\
                  27.90, 167.45, 28.06 Q 177.55, 28.85, 187.64, 29.04 Q 197.73, 27.71, 207.82, 27.20 Q 217.91, 28.00, 228.00, 28.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button821046572button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button821046572button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button821046572button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:224px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Поправки залишені користувачами<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button154936559" style="position: absolute; left: 370px; top: 15px; width: 96px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button154936559" data-review-reference-id="button154936559">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:96px;" width="96" height="30">\
               <svg:g width="96" height="30"><svg:path d="M 2.00, 2.00 Q 13.12, -0.32, 24.25, -0.37 Q 35.38, -0.03, 46.50, -0.11 Q 57.62, 0.25, 68.75, 0.32 Q 79.88, 0.27,\
                  91.85, 1.15 Q 92.02, 13.16, 91.25, 25.25 Q 80.02, 25.54, 68.82, 25.67 Q 57.66, 25.65, 46.52, 25.72 Q 35.39, 26.20, 24.26,\
                  25.88 Q 13.13, 25.47, 1.72, 25.28 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 92.00, 4.00 Q 92.00, 16.00, 92.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 93.00, 5.00 Q 93.00, 17.00, 93.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 94.00, 6.00 Q 94.00, 18.00, 94.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 15.25, 25.72, 26.50, 25.68 Q 37.75, 25.56, 49.00, 25.83 Q 60.25, 25.23, 71.50, 25.50 Q 82.75,\
                  26.00, 94.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 16.25, 24.97, 27.50, 24.91 Q 38.75, 24.76, 50.00, 25.10 Q 61.25, 25.12, 72.50, 24.90 Q 83.75,\
                  27.00, 95.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 17.25, 27.56, 28.50, 27.82 Q 39.75, 27.77, 51.00, 27.87 Q 62.25, 28.00, 73.50, 27.62 Q 84.75,\
                  28.00, 96.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button154936559button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button154936559button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button154936559button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:92px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Нові відгуки<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button701267870" style="position: absolute; left: 260px; top: 15px; width: 68px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button701267870" data-review-reference-id="button701267870">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:68px;" width="68" height="30">\
               <svg:g width="68" height="30"><svg:path d="M 2.00, 2.00 Q 12.17, 1.28, 22.33, 1.11 Q 32.50, 1.21, 42.67, 1.38 Q 52.83, 1.62, 63.16, 1.84 Q 63.47, 13.34,\
                  63.09, 25.09 Q 52.99, 25.56, 42.66, 24.98 Q 32.51, 25.15, 22.33, 25.00 Q 12.16, 24.33, 1.66, 25.34 Q 2.00, 13.50, 2.00, 2.00"\
                  style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 64.00, 4.00 Q 64.00, 16.00, 64.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 65.00, 5.00 Q 65.00, 17.00, 65.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 66.00, 6.00 Q 66.00, 18.00, 66.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.33, 24.93, 24.67, 25.42 Q 35.00, 25.68, 45.33, 25.71 Q 55.67, 26.00, 66.00, 26.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.33, 27.20, 25.67, 25.84 Q 36.00, 24.96, 46.33, 25.29 Q 56.67, 27.00, 67.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.33, 28.25, 26.67, 28.00 Q 37.00, 27.64, 47.33, 27.47 Q 57.67, 28.00, 68.00, 28.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button701267870button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button701267870button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button701267870button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:64px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Пошта<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-textinput56959620" style="position: absolute; left: 15px; top: 70px; width: 210px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput56959620" data-review-reference-id="textinput56959620">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:210px;" width="210" height="30">\
               <svg:g id="__containerId__-page585380472-layer-textinput56959620svg" width="210" height="30"><svg:path id="__containerId__-page585380472-layer-textinput56959620_input_svg_border" d="M 2.00, 2.00 Q 12.30, 3.30, 22.60,\
                  2.27 Q 32.90, 1.51, 43.20, 0.66 Q 53.50, 0.22, 63.80, 0.35 Q 74.10, 0.67, 84.40, 0.52 Q 94.70, 0.46, 105.00, 0.28 Q 115.30,\
                  0.18, 125.60, 0.77 Q 135.90, 1.11, 146.20, 1.06 Q 156.50, 1.21, 166.80, 0.81 Q 177.10, 0.31, 187.40, 0.18 Q 197.70, 0.21,\
                  208.84, 1.16 Q 209.01, 14.66, 208.66, 28.66 Q 197.88, 28.65, 187.49, 28.84 Q 177.13, 28.61, 166.82, 28.64 Q 156.51, 28.57,\
                  146.20, 28.31 Q 135.90, 28.30, 125.60, 28.04 Q 115.30, 28.63, 105.00, 27.96 Q 94.70, 28.76, 84.40, 29.03 Q 74.10, 29.42, 63.80,\
                  29.33 Q 53.50, 29.49, 43.20, 29.44 Q 32.90, 29.27, 22.60, 29.28 Q 12.30, 29.11, 1.73, 28.27 Q 2.00, 15.00, 2.00, 2.00" style="\
                  fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page585380472-layer-textinput56959620_line1" d="M 3.00, 3.00 Q 13.20, 0.56, 23.40, 1.37 Q 33.60,\
                  2.55, 43.80, 2.62 Q 54.00, 3.25, 64.20, 3.59 Q 74.40, 3.08, 84.60, 2.68 Q 94.80, 2.33, 105.00, 2.26 Q 115.20, 2.69, 125.40,\
                  2.04 Q 135.60, 1.86, 145.80, 1.79 Q 156.00, 1.85, 166.20, 1.96 Q 176.40, 2.49, 186.60, 2.76 Q 196.80, 3.00, 207.00, 3.00"\
                  style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page585380472-layer-textinput56959620_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page585380472-layer-textinput56959620_line3" d="M 3.00, 3.00 Q 13.20, 3.67, 23.40, 3.05 Q 33.60,\
                  2.98, 43.80, 2.80 Q 54.00, 3.34, 64.20, 2.99 Q 74.40, 2.63, 84.60, 2.36 Q 94.80, 2.82, 105.00, 2.71 Q 115.20, 2.32, 125.40,\
                  2.34 Q 135.60, 2.14, 145.80, 2.98 Q 156.00, 3.18, 166.20, 2.90 Q 176.40, 2.96, 186.60, 3.08 Q 196.80, 3.00, 207.00, 3.00"\
                  style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page585380472-layer-textinput56959620_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page585380472-layer-textinput56959620input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page585380472-layer-textinput56959620_input_svg_border\',\'__containerId__-page585380472-layer-textinput56959620_line1\',\'__containerId__-page585380472-layer-textinput56959620_line2\',\'__containerId__-page585380472-layer-textinput56959620_line3\',\'__containerId__-page585380472-layer-textinput56959620_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page585380472-layer-textinput56959620_input_svg_border\',\'__containerId__-page585380472-layer-textinput56959620_line1\',\'__containerId__-page585380472-layer-textinput56959620_line2\',\'__containerId__-page585380472-layer-textinput56959620_line3\',\'__containerId__-page585380472-layer-textinput56959620_line4\'))" value="Назва статті" style="width:203px;height:28px;padding: 0px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button501595982" style="position: absolute; left: 35px; top: 15px; width: 175px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button501595982" data-review-reference-id="button501595982">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:175px;" width="175" height="30">\
               <svg:g width="175" height="30"><svg:path d="M 2.00, 2.00 Q 12.50, 2.00, 23.00, 1.51 Q 33.50, 1.24, 44.00, 1.04 Q 54.50, 1.97, 65.00, 1.32 Q 75.50, 1.40,\
                  86.00, 0.57 Q 96.50, 0.74, 107.00, 0.75 Q 117.50, 0.44, 128.00, 0.46 Q 138.50, 0.62, 149.00, 2.07 Q 159.50, 0.90, 170.57,\
                  1.43 Q 171.06, 13.15, 170.74, 25.74 Q 159.85, 26.28, 149.16, 26.40 Q 138.56, 26.25, 128.03, 26.14 Q 117.51, 25.53, 107.01,\
                  25.96 Q 96.50, 26.19, 86.00, 26.82 Q 75.50, 25.88, 65.00, 25.06 Q 54.50, 24.97, 44.00, 26.02 Q 33.50, 25.84, 23.00, 25.61\
                  Q 12.50, 25.33, 1.46, 25.54 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 171.00, 4.00 Q 171.00, 16.00, 171.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 172.00, 5.00 Q 172.00, 17.00, 172.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 173.00, 6.00 Q 173.00, 18.00, 173.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.56, 25.10, 25.12, 25.06 Q 35.69, 24.90, 46.25, 24.77 Q 56.81, 24.54, 67.38, 24.42 Q 77.94,\
                  24.42, 88.50, 24.79 Q 99.06, 24.43, 109.62, 24.36 Q 120.19, 24.18, 130.75, 24.15 Q 141.31, 24.02, 151.88, 24.18 Q 162.44,\
                  26.00, 173.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.56, 26.75, 26.12, 26.81 Q 36.69, 26.49, 47.25, 26.55 Q 57.81, 27.42, 68.38, 26.01 Q 78.94,\
                  25.84, 89.50, 26.26 Q 100.06, 27.56, 110.62, 27.78 Q 121.19, 27.24, 131.75, 26.12 Q 142.31, 26.14, 152.88, 25.18 Q 163.44,\
                  27.00, 174.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.56, 28.21, 27.12, 27.42 Q 37.69, 25.99, 48.25, 26.69 Q 58.81, 26.18, 69.38, 25.93 Q 79.94,\
                  27.42, 90.50, 27.49 Q 101.06, 27.98, 111.62, 26.59 Q 122.19, 26.28, 132.75, 26.62 Q 143.31, 27.83, 153.88, 27.94 Q 164.44,\
                  28.00, 175.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button501595982button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button501595982button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button501595982button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:171px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Основні вимоги до статті<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button304101873" style="position: absolute; left: 755px; top: 455px; width: 174px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button304101873" data-review-reference-id="button304101873">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:174px;" width="174" height="30">\
               <svg:g width="174" height="30"><svg:path d="M 2.00, 2.00 Q 12.44, 1.14, 22.88, 1.04 Q 33.31, 0.95, 43.75, 1.49 Q 54.19, 1.29, 64.62, 1.04 Q 75.06, 1.89,\
                  85.50, 1.90 Q 95.94, 1.03, 106.38, 1.98 Q 116.81, 1.74, 127.25, 1.45 Q 137.69, 2.10, 148.12, 2.51 Q 158.56, 2.92, 168.74,\
                  2.26 Q 169.28, 13.41, 169.27, 25.27 Q 158.55, 24.95, 147.99, 23.81 Q 137.64, 24.08, 127.23, 24.09 Q 116.81, 25.17, 106.38,\
                  25.26 Q 95.94, 24.64, 85.50, 24.53 Q 75.06, 25.64, 64.63, 25.25 Q 54.19, 25.13, 43.75, 25.97 Q 33.31, 24.97, 22.88, 25.66\
                  Q 12.44, 25.00, 1.82, 25.18 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 170.00, 4.00 Q 170.00, 16.00, 170.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 171.00, 5.00 Q 171.00, 17.00, 171.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 172.00, 6.00 Q 172.00, 18.00, 172.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.50, 24.46, 25.00, 24.11 Q 35.50, 23.97, 46.00, 23.93 Q 56.50, 24.18, 67.00, 24.34 Q 77.50,\
                  24.17, 88.00, 24.28 Q 98.50, 24.30, 109.00, 24.10 Q 119.50, 24.96, 130.00, 24.52 Q 140.50, 24.41, 151.00, 24.77 Q 161.50,\
                  26.00, 172.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.50, 26.48, 26.00, 26.00 Q 36.50, 26.52, 47.00, 25.86 Q 57.50, 27.15, 68.00, 27.30 Q 78.50,\
                  27.11, 89.00, 26.61 Q 99.50, 26.95, 110.00, 26.53 Q 120.50, 26.61, 131.00, 26.41 Q 141.50, 26.53, 152.00, 27.48 Q 162.50,\
                  27.00, 173.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.50, 29.27, 27.00, 28.42 Q 37.50, 27.93, 48.00, 27.92 Q 58.50, 27.82, 69.00, 27.78 Q 79.50,\
                  27.37, 90.00, 27.54 Q 100.50, 27.03, 111.00, 27.68 Q 121.50, 28.68, 132.00, 27.83 Q 142.50, 27.67, 153.00, 26.99 Q 163.50,\
                  28.00, 174.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button304101873button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button304101873button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button304101873button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:170px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Відправити статтю адміну<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button334392168" style="position: absolute; left: 515px; top: 455px; width: 226px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button334392168" data-review-reference-id="button334392168">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:226px;" width="226" height="30">\
               <svg:g width="226" height="30"><svg:path d="M 2.00, 2.00 Q 12.95, 0.93, 23.90, 1.39 Q 34.85, 2.05, 45.80, 1.71 Q 56.75, 1.12, 67.70, 1.21 Q 78.65, 0.69,\
                  89.60, 0.77 Q 100.55, 1.51, 111.50, 1.72 Q 122.45, 1.71, 133.40, 1.85 Q 144.35, 2.70, 155.30, 1.29 Q 166.25, 0.95, 177.20,\
                  0.82 Q 188.15, 2.25, 199.10, 2.47 Q 210.05, 1.88, 220.67, 2.33 Q 220.41, 13.70, 220.96, 24.96 Q 210.26, 25.79, 199.21, 25.98\
                  Q 188.18, 25.60, 177.19, 24.51 Q 166.26, 25.51, 155.31, 25.86 Q 144.35, 25.45, 133.40, 25.99 Q 122.45, 26.41, 111.50, 26.18\
                  Q 100.55, 24.94, 89.60, 24.81 Q 78.65, 25.10, 67.70, 24.53 Q 56.75, 25.47, 45.80, 25.89 Q 34.85, 26.68, 23.90, 25.32 Q 12.95,\
                  24.38, 2.45, 24.55 Q 2.00, 13.50, 2.00, 2.00" style=" fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 222.00, 4.00 Q 222.00, 16.00, 222.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 223.00, 5.00 Q 223.00, 17.00, 223.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 224.00, 6.00 Q 224.00, 18.00, 224.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 14.00, 26.86, 24.00, 25.92 Q 34.00, 26.02, 44.00, 25.15 Q 54.00, 26.87, 64.00, 26.75 Q 74.00,\
                  26.03, 84.00, 25.29 Q 94.00, 25.88, 104.00, 26.02 Q 114.00, 25.71, 124.00, 25.80 Q 134.00, 25.51, 144.00, 26.32 Q 154.00,\
                  26.61, 164.00, 26.36 Q 174.00, 26.24, 184.00, 26.41 Q 194.00, 26.48, 204.00, 25.22 Q 214.00, 26.00, 224.00, 26.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 15.00, 24.47, 25.00, 24.52 Q 35.00, 24.46, 45.00, 25.36 Q 55.00, 24.98, 65.00, 24.76 Q 75.00,\
                  24.96, 85.00, 26.07 Q 95.00, 25.74, 105.00, 25.83 Q 115.00, 26.01, 125.00, 25.41 Q 135.00, 25.00, 145.00, 25.37 Q 155.00,\
                  26.62, 165.00, 26.93 Q 175.00, 26.52, 185.00, 26.34 Q 195.00, 26.04, 205.00, 25.95 Q 215.00, 27.00, 225.00, 27.00" style="\
                  fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 16.00, 27.76, 26.00, 27.17 Q 36.00, 27.14, 46.00, 26.27 Q 56.00, 26.80, 66.00, 27.50 Q 76.00,\
                  27.02, 86.00, 26.49 Q 96.00, 27.28, 106.00, 27.49 Q 116.00, 27.57, 126.00, 27.82 Q 136.00, 27.63, 146.00, 26.84 Q 156.00,\
                  26.60, 166.00, 26.29 Q 176.00, 27.33, 186.00, 27.64 Q 196.00, 28.06, 206.00, 27.47 Q 216.00, 28.00, 226.00, 28.00" style="\
                  fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button334392168button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button334392168button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button334392168button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:222px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Перевірити на граматичні помилки<br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-iframe65868827" style="position: absolute; left: 250px; top: 75px; width: 445px; height: 335px" data-interactive-element-type="default.iframe" class="iframe stencil mobile-interaction-potential-trigger " data-stencil-id="iframe65868827" data-review-reference-id="iframe65868827">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="height: 335px;width:445px;" width="445" height="335">\
            <svg:g id="__containerId__-page585380472-layer-iframe65868827svg" width="445" height="335"><svg:path d="M 2.00, 2.00 Q 12.02, 0.13, 22.05, 0.09 Q 32.07, -0.05, 42.09, 0.35 Q 52.11, 0.19, 62.14, 0.09 Q 72.16, 0.20,\
               82.18, 0.56 Q 92.20, 0.96, 102.23, 0.70 Q 112.25, 0.56, 122.27, 0.75 Q 132.30, 0.54, 142.32, 0.98 Q 152.34, 0.92, 162.36,\
               0.87 Q 172.39, 0.76, 182.41, 1.61 Q 192.43, 1.76, 202.45, 1.71 Q 212.48, 1.39, 222.50, 1.42 Q 232.52, 1.54, 242.55, 1.71 Q\
               252.57, 1.50, 262.59, 0.90 Q 272.61, 1.90, 282.64, 1.72 Q 292.66, 0.90, 302.68, 1.36 Q 312.70, 1.18, 322.73, 0.86 Q 332.75,\
               0.65, 342.77, 0.14 Q 352.80, 1.36, 362.82, 1.36 Q 372.84, 1.09, 382.86, 2.25 Q 392.89, 2.41, 402.91, 2.09 Q 412.93, 1.63,\
               422.95, 1.26 Q 432.98, 2.08, 443.41, 1.59 Q 443.14, 12.30, 443.37, 22.63 Q 443.00, 33.03, 442.72, 43.38 Q 442.46, 53.73, 443.68,\
               64.06 Q 444.68, 74.40, 444.45, 84.75 Q 443.90, 95.09, 442.77, 105.44 Q 442.85, 115.78, 443.00, 126.12 Q 443.52, 136.47, 444.30,\
               146.81 Q 444.41, 157.16, 443.67, 167.50 Q 443.85, 177.84, 443.72, 188.19 Q 445.01, 198.53, 443.98, 208.88 Q 444.21, 219.22,\
               444.47, 229.56 Q 444.77, 239.91, 445.35, 250.25 Q 445.01, 260.59, 444.30, 270.94 Q 443.77, 281.28, 444.36, 291.62 Q 444.67,\
               301.97, 444.22, 312.31 Q 443.09, 322.66, 442.52, 332.52 Q 432.84, 332.60, 422.93, 332.81 Q 412.95, 333.29, 402.90, 332.77\
               Q 392.88, 332.58, 382.87, 333.19 Q 372.84, 333.97, 362.82, 334.03 Q 352.80, 333.73, 342.77, 332.76 Q 332.75, 334.03, 322.73,\
               334.10 Q 312.70, 333.75, 302.68, 333.41 Q 292.66, 333.54, 282.64, 333.40 Q 272.61, 333.20, 262.59, 332.74 Q 252.57, 332.79,\
               242.55, 332.38 Q 232.52, 332.98, 222.50, 331.98 Q 212.48, 332.37, 202.45, 333.14 Q 192.43, 334.01, 182.41, 334.33 Q 172.39,\
               334.59, 162.36, 334.91 Q 152.34, 334.70, 142.32, 334.04 Q 132.30, 333.81, 122.27, 332.70 Q 112.25, 332.53, 102.23, 332.84\
               Q 92.20, 332.62, 82.18, 332.82 Q 72.16, 333.51, 62.14, 333.24 Q 52.11, 333.56, 42.09, 333.66 Q 32.07, 333.97, 22.05, 333.87\
               Q 12.02, 333.62, 1.69, 333.31 Q 1.73, 322.75, 1.23, 312.42 Q 1.38, 302.01, 1.62, 291.64 Q 0.69, 281.30, 0.40, 270.95 Q 0.90,\
               260.60, 1.67, 250.25 Q 2.31, 239.91, 1.74, 229.56 Q 0.65, 219.22, 0.22, 208.88 Q 0.63, 198.53, 0.38, 188.19 Q -0.04, 177.84,\
               -0.23, 167.50 Q 0.09, 157.16, -0.02, 146.81 Q -0.27, 136.47, -0.28, 126.12 Q 0.09, 115.78, 0.29, 105.44 Q 0.47, 95.09, 0.35,\
               84.75 Q 0.50, 74.41, 0.30, 64.06 Q 0.61, 53.72, 0.09, 43.38 Q 0.45, 33.03, 1.33, 22.69 Q 2.00, 12.34, 2.00, 2.00" style="\
               fill:white;" class="svg_unselected_element"/>\
            </svg:g>\
         </svg:svg>\
         <div class="renderEmptyPage" style="position:absolute;left:4px;top:4px;width:435px;height:325px;overflow:auto;border:none;">Frame without target</div>\
      </div>\
      <div id="__containerId__-page585380472-layer-combobox462708196" style="position: absolute; left: 15px; top: 115px; width: 210px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox462708196" data-review-reference-id="combobox462708196">\
         <div style="position:absolute;left:2px;top:0px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:210px;" width="210" height="30">\
               <svg:g id="__containerId__-page585380472-layer-combobox462708196" width="210" height="30"><svg:path id="__containerId__-page585380472-layer-combobox462708196_input_svg_border" d="M 2.00, 2.00 Q 12.30, 2.76, 22.60,\
                  2.09 Q 32.90, 2.18, 43.20, 1.61 Q 53.50, 2.43, 63.80, 2.58 Q 74.10, 2.41, 84.40, 1.72 Q 94.70, 1.21, 105.00, 1.98 Q 115.30,\
                  1.68, 125.60, 1.86 Q 135.90, 2.22, 146.20, 3.15 Q 156.50, 2.61, 166.80, 2.80 Q 177.10, 1.95, 187.40, 1.44 Q 197.70, 2.85,\
                  208.00, 2.00 Q 207.90, 15.03, 208.27, 28.27 Q 197.79, 28.32, 187.45, 28.41 Q 177.06, 27.24, 166.78, 27.27 Q 156.49, 27.31,\
                  146.19, 26.88 Q 135.90, 27.10, 125.60, 28.61 Q 115.30, 29.35, 105.00, 27.91 Q 94.70, 27.66, 84.40, 26.99 Q 74.10, 28.15, 63.80,\
                  28.54 Q 53.50, 27.16, 43.20, 27.90 Q 32.90, 29.24, 22.60, 29.44 Q 12.30, 28.94, 1.70, 28.30 Q 2.00, 15.00, 2.00, 2.00" style="\
                  fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div title="" style="position:absolute"><select id="__containerId__-page585380472-layer-combobox462708196select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page585380472-layer-combobox462708196_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page585380472-layer-combobox462708196_input_svg_border\')" style="width:206px; height:26px;" title="">\
                  <option title="">Тематика</option>\
                  <option title="">статті</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-button222799341" style="position: absolute; left: 355px; top: 455px; width: 118px; height: 30px" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button222799341" data-review-reference-id="button222799341">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" style="position:absolute; left:0; top:-2px;" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:118px;" width="118" height="30">\
               <svg:g width="118" height="30"><svg:path d="M 2.00, 2.00 Q 13.10, 1.86, 24.20, 1.88 Q 35.30, 1.83, 46.40, 1.48 Q 57.50, 2.01, 68.60, 2.05 Q 79.70, 1.43,\
                  90.80, 1.34 Q 101.90, 1.31, 112.92, 2.08 Q 113.22, 13.43, 112.75, 24.75 Q 101.89, 24.96, 90.80, 25.04 Q 79.71, 25.25, 68.62,\
                  25.65 Q 57.51, 26.07, 46.40, 25.57 Q 35.30, 24.46, 24.20, 24.50 Q 13.10, 23.88, 2.20, 24.80 Q 2.00, 13.50, 2.00, 2.00" style="\
                  fill:#d9d9d9;" class="svg_unselected_element"/><svg:path d="M 114.00, 4.00 Q 114.00, 16.00, 114.00, 28.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 115.00, 5.00 Q 115.00, 17.00, 115.00, 29.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 116.00, 6.00 Q 116.00, 18.00, 116.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 26.00 Q 15.20, 27.32, 26.40, 27.34 Q 37.60, 26.99, 48.80, 26.56 Q 60.00, 25.48, 71.20, 25.90 Q 82.40,\
                  26.08, 93.60, 26.47 Q 104.80, 26.00, 116.00, 26.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 5.00, 27.00 Q 16.20, 26.33, 27.40, 26.69 Q 38.60, 27.15, 49.80, 26.71 Q 61.00, 27.21, 72.20, 26.96 Q 83.40,\
                  26.43, 94.60, 26.38 Q 105.80, 27.00, 117.00, 27.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 6.00, 28.00 Q 17.20, 26.98, 28.40, 25.98 Q 39.60, 25.60, 50.80, 25.77 Q 62.00, 25.62, 73.20, 25.79 Q 84.40,\
                  25.62, 95.60, 25.89 Q 106.80, 28.00, 118.00, 28.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg><button id="__containerId__-page585380472-layer-button222799341button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-page585380472-layer-button222799341button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-page585380472-layer-button222799341button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:114px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">\
               				Зберегти зміни <br />  \
               			</button></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-combobox576400449" style="position: absolute; left: 15px; top: 165px; width: 210px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox576400449" data-review-reference-id="combobox576400449">\
         <div style="position:absolute;left:2px;top:0px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:210px;" width="210" height="30">\
               <svg:g id="__containerId__-page585380472-layer-combobox576400449" width="210" height="30"><svg:path id="__containerId__-page585380472-layer-combobox576400449_input_svg_border" d="M 2.00, 2.00 Q 12.30, 1.53, 22.60,\
                  1.28 Q 32.90, 1.15, 43.20, 1.11 Q 53.50, 1.17, 63.80, 0.78 Q 74.10, 0.60, 84.40, 1.08 Q 94.70, 1.12, 105.00, 1.20 Q 115.30,\
                  1.55, 125.60, 1.19 Q 135.90, 1.33, 146.20, 0.47 Q 156.50, 0.38, 166.80, 1.01 Q 177.10, 0.92, 187.40, 1.28 Q 197.70, 1.49,\
                  208.03, 1.97 Q 208.28, 14.91, 208.03, 28.03 Q 197.82, 28.44, 187.46, 28.51 Q 177.13, 28.57, 166.80, 27.92 Q 156.51, 28.81,\
                  146.21, 29.72 Q 135.90, 29.02, 125.60, 29.59 Q 115.30, 28.75, 105.00, 28.35 Q 94.70, 28.32, 84.40, 28.22 Q 74.10, 27.93, 63.80,\
                  27.83 Q 53.50, 28.60, 43.20, 28.06 Q 32.90, 28.68, 22.60, 27.77 Q 12.30, 27.89, 1.88, 28.12 Q 2.00, 15.00, 2.00, 2.00" style="\
                  fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div title="" style="position:absolute"><select id="__containerId__-page585380472-layer-combobox576400449select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page585380472-layer-combobox576400449_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page585380472-layer-combobox576400449_input_svg_border\')" style="width:206px; height:26px;" title="">\
                  <option title="">Жанр</option>\
                  <option title="">статті</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-combobox792497376" style="position: absolute; left: 15px; top: 215px; width: 210px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox792497376" data-review-reference-id="combobox792497376">\
         <div style="position:absolute;left:2px;top:0px;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:210px;" width="210" height="30">\
               <svg:g id="__containerId__-page585380472-layer-combobox792497376" width="210" height="30"><svg:path id="__containerId__-page585380472-layer-combobox792497376_input_svg_border" d="M 2.00, 2.00 Q 12.30, 1.19, 22.60,\
                  1.06 Q 32.90, 1.50, 43.20, 1.91 Q 53.50, 2.85, 63.80, 2.76 Q 74.10, 2.83, 84.40, 1.90 Q 94.70, 2.21, 105.00, 2.62 Q 115.30,\
                  2.47, 125.60, 2.44 Q 135.90, 2.46, 146.20, 2.77 Q 156.50, 2.12, 166.80, 1.52 Q 177.10, 1.25, 187.40, 1.47 Q 197.70, 2.18,\
                  207.90, 2.10 Q 207.69, 15.10, 207.65, 27.65 Q 197.34, 26.68, 187.38, 27.86 Q 177.12, 28.33, 166.80, 28.14 Q 156.51, 28.73,\
                  146.20, 28.25 Q 135.90, 29.15, 125.60, 29.42 Q 115.30, 29.59, 105.00, 30.18 Q 94.70, 30.47, 84.40, 30.12 Q 74.10, 30.15, 63.80,\
                  29.75 Q 53.50, 29.17, 43.20, 28.73 Q 32.90, 28.75, 22.60, 28.56 Q 12.30, 27.44, 1.92, 28.08 Q 2.00, 15.00, 2.00, 2.00" style="\
                  fill:white;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div title="" style="position:absolute"><select id="__containerId__-page585380472-layer-combobox792497376select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page585380472-layer-combobox792497376_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page585380472-layer-combobox792497376_input_svg_border\')" style="width:206px; height:26px;" title="">\
                  <option title="">Співавтори</option>\
                  <option title="">статті</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-text330417925" style="position: absolute; left: 285px; top: 120px; width: 280px; height: 240px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text330417925" data-review-reference-id="text330417925">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, ased diam nonumy eirmod tempor invidunt\
                  ut labore et adolore magna aliquyam erat, sed diam voluptua. At avero eos et accusam et justo duo dolores et ea rebum. aStet\
                  clita kasd gubergren, no sea takimata sanctus est aLorem ipsum dolor sit amet. Lorem ipsum dolor sit aamet, consetetur sadipscing\
                  elitr, sed diam nonumy aeirmod tempor invidunt ut labore et dolore magna aaliquyam erat, sed diam voluptua. At vero eos et\
                  aaccusam et justo duo dolores et ea rebum. Stet clita akasd gubergren, no sea takimata sanctus est Lorem aipsum dolor sit\
                  amet.</p></span></span></div>\
      </div>\
      <div id="__containerId__-page585380472-layer-comment726409066" style="position: absolute; left: 15px; top: 435px; width: 200px; height: 40px" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment726409066" data-review-reference-id="comment726409066">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 41px;width:200px;" width="200" height="41">\
               <svg:g width="200" height="40"><svg:path d="M 2.00, 2.00 Q 12.06, 1.55, 22.11, 1.26 Q 32.17, 1.41, 42.22, 0.79 Q 52.28, 1.23, 62.33, 1.44 Q 72.39, 1.03,\
                  82.44, 0.72 Q 92.50, 0.92, 102.56, 1.10 Q 112.61, 0.97, 122.67, 0.98 Q 132.72, 1.07, 142.78, 1.07 Q 152.83, 0.19, 162.89,\
                  1.81 Q 172.94, 1.47, 183.14, 1.68 Q 190.85, 9.51, 198.73, 17.64 Q 198.94, 27.80, 198.34, 38.31 Q 187.29, 38.55, 176.28, 38.46\
                  Q 165.39, 39.02, 154.47, 38.99 Q 143.57, 39.28, 132.67, 38.93 Q 121.78, 39.45, 110.89, 39.62 Q 100.00, 38.69, 89.11, 37.18\
                  Q 78.22, 37.83, 67.33, 37.68 Q 56.44, 37.81, 45.56, 37.86 Q 34.67, 38.35, 23.78, 38.69 Q 12.89, 38.87, 1.77, 38.23 Q 2.00,\
                  19.50, 2.00, 1.00" style=" fill:#FFFFCC;" class="svg_unselected_element"/><svg:path d="M 182.00, 2.00 Q 184.09, 9.50, 182.79, 16.21 Q 189.50, 17.00, 197.00, 17.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
            <div style="position: absolute; left: 4px; top: 2px; height: 36px;width:196px;font-size:1em;line-height:1.2em;" xml:space="preserve">Звертання автора<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-checkbox42302449" style="position: absolute; left: 730px; top: 380px; width: 225px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox42302449" data-review-reference-id="checkbox42302449">\
         <div style="font-size:1.17em;">\
            <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page585380472-layer-checkbox42302449_input\');">\
               				\
               <nobr><input id="__containerId__-page585380472-layer-checkbox42302449_input" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page585380472-layer-checkbox42302449_input\', \'__containerId__-page585380472-layer-checkbox42302449_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page585380472-layer-checkbox42302449_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page585380472-layer-checkbox42302449_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page585380472-layer-checkbox42302449_input\', \'__containerId__-page585380472-layer-checkbox42302449_input_svgChecked\')" checked="true" />Дозволити коментувати статтю\
                  				\
               </nobr>\
               			\
            </div>\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:225px;" width="225" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page585380472-layer-checkbox42302449_input\');">\
                  <svg:g id="__containerId__-page585380472-layer-checkbox42302449_input_svg" x="0" y="1.0199999999999996" width="225" height="20"><svg:path id="__containerId__-page585380472-layer-checkbox42302449_input_svg_border" d="M 5.00, 5.00 Q 10.00, 2.52, 16.09,\
                     3.91 Q 16.52, 9.49, 15.63, 15.63 Q 10.38, 16.40, 4.38, 15.53 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g id="__containerId__-page585380472-layer-checkbox42302449_input_svgChecked" x="0" y="1.0199999999999996" width="225" height="20" visibility="inherit"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-checkbox990487334" style="position: absolute; left: 730px; top: 405px; width: 188px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox990487334" data-review-reference-id="checkbox990487334">\
         <div style="font-size:1.17em;">\
            <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page585380472-layer-checkbox990487334_input\');">\
               				\
               <nobr><input id="__containerId__-page585380472-layer-checkbox990487334_input" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page585380472-layer-checkbox990487334_input\', \'__containerId__-page585380472-layer-checkbox990487334_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page585380472-layer-checkbox990487334_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page585380472-layer-checkbox990487334_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page585380472-layer-checkbox990487334_input\', \'__containerId__-page585380472-layer-checkbox990487334_input_svgChecked\')" checked="true" />Дозволити зміни читачам\
                  				\
               </nobr>\
               			\
            </div>\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:188px;" width="188" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page585380472-layer-checkbox990487334_input\');">\
                  <svg:g id="__containerId__-page585380472-layer-checkbox990487334_input_svg" x="0" y="1.0199999999999996" width="188" height="20"><svg:path id="__containerId__-page585380472-layer-checkbox990487334_input_svg_border" d="M 5.00, 5.00 Q 10.00, 2.58, 16.00,\
                     4.00 Q 16.22, 9.59, 15.56, 15.56 Q 10.25, 15.91, 4.57, 15.36 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g id="__containerId__-page585380472-layer-checkbox990487334_input_svgChecked" x="0" y="1.0199999999999996" width="188" height="20" visibility="inherit"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page585380472-layer-iframe498176699" style="position: absolute; left: 15px; top: 300px; width: 210px; height: 100px" data-interactive-element-type="default.iframe" class="iframe stencil mobile-interaction-potential-trigger " data-stencil-id="iframe498176699" data-review-reference-id="iframe498176699">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="height: 100px;width:210px;" width="210" height="100">\
            <svg:g id="__containerId__-page585380472-layer-iframe498176699svg" width="210" height="100"><svg:path d="M 2.00, 2.00 Q 12.30, 1.05, 22.60, 0.98 Q 32.90, 0.89, 43.20, 0.72 Q 53.50, 0.94, 63.80, 0.82 Q 74.10, 0.93,\
               84.40, 0.82 Q 94.70, 0.70, 105.00, 1.28 Q 115.30, 1.47, 125.60, 1.40 Q 135.90, 1.51, 146.20, 1.52 Q 156.50, 0.82, 166.80,\
               1.19 Q 177.10, 0.83, 187.40, 1.16 Q 197.70, 1.56, 207.76, 2.24 Q 207.69, 14.10, 207.63, 26.05 Q 207.61, 38.03, 208.03, 50.00\
               Q 207.90, 62.00, 207.73, 74.00 Q 208.00, 86.00, 207.72, 97.72 Q 197.71, 98.03, 187.42, 98.16 Q 177.10, 97.99, 166.81, 98.24\
               Q 156.50, 98.02, 146.20, 98.63 Q 135.90, 98.41, 125.60, 98.60 Q 115.30, 98.15, 105.00, 98.53 Q 94.70, 98.83, 84.40, 97.86\
               Q 74.10, 96.74, 63.80, 96.92 Q 53.50, 97.08, 43.20, 96.83 Q 32.90, 97.28, 22.60, 97.45 Q 12.30, 97.54, 1.94, 98.06 Q 2.42,\
               85.86, 2.20, 73.97 Q 2.17, 61.99, 2.11, 50.00 Q 1.88, 38.00, 1.59, 26.00 Q 2.00, 14.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
            </svg:g>\
         </svg:svg>\
         <div class="renderEmptyPage" style="position:absolute;left:4px;top:4px;width:200px;height:90px;overflow:auto;border:none;">Frame without target</div>\
      </div>\
      <div id="__containerId__-page585380472-layer-text360507682" style="position: absolute; left: 15px; top: 275px; width: 90px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text360507682" data-review-reference-id="text360507682">\
         <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;">Сюжет статті</p></span></span></div>\
      </div>\
   </div>\
</div>');